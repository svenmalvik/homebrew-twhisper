import { ITranscriptionService } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
import { LocalWhisperService } from './streaming/LocalWhisperService.js';
/**
 * Local transcription service for batch mode using whisper.cpp
 * Provides offline transcription without requiring Azure OpenAI
 */
export class LocalTranscriptionService extends ITranscriptionService {
    constructor() {
        super();
        this.isInitialized = false;
        this.localWhisper = new LocalWhisperService();
        this.isInitialized = true;
    }
    async transcribe(audioBuffer, options = {}) {
        if (!this.isInitialized) {
            throw new AppError('LocalTranscriptionService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        const startTime = Date.now();
        this.emit('transcription:started', { bufferSize: audioBuffer.length });
        try {
            this.emit('transcription:progress', { stage: 'processing', progress: 0.5 });
            // Use LocalWhisperService for transcription
            const result = await this.localWhisper.transcribe(audioBuffer, options);
            this.emit('transcription:progress', { stage: 'completed', progress: 1.0 });
            const transcriptionResult = {
                text: result.text,
                confidence: result.confidence,
                language: result.language || options.language || 'en',
                duration: Date.now() - startTime,
                wordCount: result.wordCount,
            };
            this.emit('transcription:completed', transcriptionResult);
            return transcriptionResult;
        }
        catch (error) {
            const appError = this.handleTranscriptionError(error);
            this.emit('transcription:error', appError);
            throw appError;
        }
    }
    handleTranscriptionError(error) {
        if (error instanceof AppError) {
            return error;
        }
        if (error instanceof Error) {
            if (error.message.includes('whisper.cpp not found')) {
                return new AppError('whisper.cpp not installed. Please install with: brew install whisper-cpp', ErrorCode.SERVICE_NOT_INITIALIZED, { originalError: error.message });
            }
            if (error.message.includes('model not found')) {
                return new AppError('Whisper model not found. Please download a model first.', ErrorCode.SERVICE_NOT_INITIALIZED, { originalError: error.message });
            }
            if (error.message.includes('timeout')) {
                return new AppError('Local transcription timeout', ErrorCode.NETWORK_ERROR, { originalError: error.message });
            }
        }
        return new AppError('Local transcription failed', ErrorCode.TRANSCRIPTION_FAILED, { originalError: error instanceof Error ? error.message : 'Unknown error' });
    }
    async checkAvailability() {
        try {
            // Check if local whisper is ready
            return this.localWhisper.isReady();
        }
        catch (error) {
            this.emit('availability:check:failed', error);
            return false;
        }
    }
    getSupportedFormats() {
        return ['wav', 'mp3', 'mp4', 'mpeg', 'mpga', 'm4a', 'ogg', 'flac', 'webm'];
    }
    /**
     * Implement retry logic for transcription with exponential backoff
     */
    async transcribeWithRetry(audioBuffer, options = {}, maxRetries = 3) {
        let lastError;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return await this.transcribe(audioBuffer, options);
            }
            catch (error) {
                lastError = error instanceof AppError ? error : new AppError('Transcription attempt failed', ErrorCode.TRANSCRIPTION_FAILED, { attempt, error: error instanceof Error ? error.message : 'Unknown error' });
                // Don't retry on configuration errors
                if (lastError.code === ErrorCode.SERVICE_NOT_INITIALIZED ||
                    lastError.code === ErrorCode.CONFIGURATION_ERROR) {
                    throw lastError;
                }
                // Wait before retry with exponential backoff
                if (attempt < maxRetries) {
                    const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
                    this.emit('transcription:retry', { attempt, delay, error: lastError });
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError || new AppError('All transcription attempts failed', ErrorCode.TRANSCRIPTION_FAILED, { maxRetries });
    }
    /**
     * Get model information
     */
    getModelInfo() {
        return this.localWhisper.getModelInfo();
    }
}
//# sourceMappingURL=LocalTranscriptionService.js.map