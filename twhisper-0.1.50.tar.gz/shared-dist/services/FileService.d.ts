import { IFileService } from '../interfaces/interfaces.js';
export declare class FileService extends IFileService {
    private tempFiles;
    private readonly tempDir;
    constructor(customTempDir?: string);
    private ensureTempDirExists;
    createTempFile(extension: string, data?: Buffer): Promise<string>;
    deleteTempFile(filePath: string): Promise<boolean>;
    cleanupTempFiles(): Promise<number>;
    exists(filePath: string): Promise<boolean>;
    readFile(filePath: string): Promise<Buffer>;
    writeFile(filePath: string, data: Buffer): Promise<boolean>;
    /**
     * Get the current temporary directory path
     */
    getTempDir(): string;
    /**
     * Get the number of tracked temporary files
     */
    getTempFileCount(): number;
    /**
     * Get all tracked temporary file paths
     */
    getTempFilePaths(): string[];
    /**
     * Clean up old temporary files based on age
     */
    cleanupOldTempFiles(maxAgeMs?: number): Promise<number>;
    /**
     * Create a temporary WAV file with proper audio headers
     */
    createTempWavFile(audioBuffer: Buffer, sampleRate?: number, channels?: number): Promise<string>;
    private createWavHeader;
}
//# sourceMappingURL=FileService.d.ts.map