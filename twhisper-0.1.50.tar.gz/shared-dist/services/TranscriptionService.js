import { ITranscriptionService } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
import fs from 'fs/promises';
export class TranscriptionService extends ITranscriptionService {
    constructor(apiKey, endpoint, apiVersion, whisperDeployment, fileService, configuration) {
        super();
        this.apiKey = apiKey;
        this.endpoint = endpoint;
        this.apiVersion = apiVersion;
        this.whisperDeployment = whisperDeployment;
        this.isInitialized = false;
        if (!apiKey || !endpoint || !apiVersion || !whisperDeployment) {
            throw new AppError('Missing required Azure OpenAI configuration', ErrorCode.CONFIGURATION_ERROR, { apiKey: !!apiKey, endpoint: !!endpoint, apiVersion: !!apiVersion, deployment: !!whisperDeployment });
        }
        this.fileService = fileService;
        this.configuration = configuration;
        this.isInitialized = true;
    }
    extractResourceName(endpoint) {
        try {
            const url = new URL(endpoint);
            return url.hostname.split('.')[0];
        }
        catch (error) {
            throw new AppError('Invalid Azure OpenAI endpoint URL', ErrorCode.CONFIGURATION_ERROR, { endpoint, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    async callWhisperAPI(file, options) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('model', this.whisperDeployment);
        // Get language from configuration, fallback to options
        const configLanguage = this.configuration?.whisper?.language;
        const language = configLanguage || options.language;
        if (language && language !== 'auto') {
            formData.append('language', language);
        }
        if (options.temperature !== undefined) {
            formData.append('temperature', options.temperature.toString());
        }
        if (options.prompt) {
            formData.append('prompt', options.prompt);
        }
        const resourceName = this.extractResourceName(this.endpoint);
        const url = `https://${resourceName}.openai.azure.com/openai/deployments/${this.whisperDeployment}/audio/transcriptions?api-version=${this.apiVersion}`;
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'api-key': this.apiKey,
            },
            body: formData,
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        const result = await response.json();
        return {
            text: result.text || '',
            language: result.language,
        };
    }
    async transcribe(audioBuffer, options = {}) {
        if (!this.isInitialized) {
            throw new AppError('TranscriptionService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        const startTime = Date.now();
        this.emit('transcription:started', { bufferSize: audioBuffer.length });
        try {
            // Create temporary file for audio data
            const tempFile = await this.createTempAudioFile(audioBuffer);
            try {
                this.emit('transcription:progress', { stage: 'uploading', progress: 0.1 });
                // Create file for the AI SDK
                const audioFile = await fs.readFile(tempFile);
                const file = new File([audioFile], 'audio.wav', { type: 'audio/wav' });
                this.emit('transcription:progress', { stage: 'processing', progress: 0.5 });
                // Call Azure OpenAI Whisper API directly
                const response = await this.callWhisperAPI(file, options);
                this.emit('transcription:progress', { stage: 'processing', progress: 0.8 });
                this.emit('transcription:progress', { stage: 'completed', progress: 1.0 });
                const processingTime = Date.now() - startTime;
                const wordCount = response.text.split(/\s+/).filter(word => word.length > 0).length;
                const transcriptionResult = {
                    text: response.text,
                    confidence: response.confidence,
                    language: response.language || options.language,
                    duration: processingTime,
                    wordCount,
                };
                this.emit('transcription:completed', transcriptionResult);
                return transcriptionResult;
            }
            finally {
                // Clean up temporary file
                await this.fileService.deleteTempFile(tempFile);
            }
        }
        catch (error) {
            if (process.env.DEBUG) {
                console.log('🔍 DEBUG: Transcription error caught:');
                console.log(`   Error type: ${error?.constructor?.name || 'Unknown'}`);
                console.log(`   Error message: ${error instanceof Error ? error.message : 'Unknown error'}`);
                console.log(`   Error stack:`, error instanceof Error ? error.stack : 'No stack');
                if (error && typeof error === 'object' && 'response' in error) {
                    const errorWithResponse = error;
                    console.log(`   HTTP status: ${errorWithResponse.response?.status}`);
                    console.log(`   HTTP statusText: ${errorWithResponse.response?.statusText}`);
                    console.log(`   HTTP data:`, errorWithResponse.response?.data);
                }
            }
            const appError = this.handleTranscriptionError(error);
            this.emit('transcription:error', appError);
            throw appError;
        }
    }
    async createTempAudioFile(audioBuffer) {
        try {
            return await this.fileService.createTempWavFile(audioBuffer, 16000, 1);
        }
        catch (error) {
            throw new AppError('Failed to create temporary audio file', ErrorCode.FILE_OPERATION_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    handleTranscriptionError(error) {
        if (error instanceof AppError) {
            return error;
        }
        if (error instanceof Error) {
            // Check for specific Azure OpenAI errors
            if (error.message.includes('401') || error.message.includes('unauthorized')) {
                return new AppError('Invalid Azure OpenAI API key or insufficient permissions', ErrorCode.AUTHENTICATION_ERROR, { originalError: error.message });
            }
            if (error.message.includes('404') || error.message.includes('not found')) {
                return new AppError('Azure OpenAI Whisper deployment not found', ErrorCode.SERVICE_UNAVAILABLE, { deployment: this.whisperDeployment, originalError: error.message });
            }
            if (error.message.includes('429') || error.message.includes('rate limit')) {
                return new AppError('Azure OpenAI rate limit exceeded', ErrorCode.RATE_LIMIT_EXCEEDED, { originalError: error.message });
            }
            if (error.message.includes('timeout') || error.message.includes('network')) {
                return new AppError('Network error during transcription', ErrorCode.NETWORK_ERROR, { originalError: error.message });
            }
        }
        return new AppError('Transcription failed', ErrorCode.TRANSCRIPTION_FAILED, { originalError: error instanceof Error ? error.message : 'Unknown error' });
    }
    async checkAvailability() {
        if (!this.isInitialized) {
            return false;
        }
        try {
            // Create a minimal test audio buffer (1 second of silence)
            const testBuffer = Buffer.alloc(16000 * 2); // 1 second at 16kHz, 16-bit
            // Try a minimal transcription to test availability
            await this.transcribe(testBuffer, { temperature: 0 });
            return true;
        }
        catch (error) {
            this.emit('availability:check:failed', error);
            return false;
        }
    }
    getSupportedFormats() {
        return ['wav', 'mp3', 'mp4', 'mpeg', 'mpga', 'm4a', 'ogg', 'flac', 'webm'];
    }
    /**
     * Implement retry logic for transcription with exponential backoff
     */
    async transcribeWithRetry(audioBuffer, options = {}, maxRetries = 3) {
        let lastError;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return await this.transcribe(audioBuffer, options);
            }
            catch (error) {
                lastError = error instanceof AppError ? error : new AppError('Transcription attempt failed', ErrorCode.TRANSCRIPTION_FAILED, { attempt, error: error instanceof Error ? error.message : 'Unknown error' });
                // Don't retry on authentication or configuration errors
                if (lastError.code === ErrorCode.AUTHENTICATION_ERROR ||
                    lastError.code === ErrorCode.CONFIGURATION_ERROR ||
                    lastError.code === ErrorCode.SERVICE_NOT_INITIALIZED) {
                    throw lastError;
                }
                // Wait before retry with exponential backoff
                if (attempt < maxRetries) {
                    const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
                    this.emit('transcription:retry', { attempt, delay, error: lastError });
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError || new AppError('All transcription attempts failed', ErrorCode.TRANSCRIPTION_FAILED, { maxRetries });
    }
}
//# sourceMappingURL=TranscriptionService.js.map