import { EventEmitter } from 'events';
import { PartialTranscriptionResult, StreamingTranscriptionOptions, WordTimestamp } from '../../interfaces/interfaces.js';
/**
 * Progressive Transcription Manager
 *
 * Manages progressive transcription results and provides:
 * 1. Real-time result streaming with confidence filtering
 * 2. Text consolidation and overlap detection
 * 3. Progressive result buffering and emission
 * 4. Context-aware result refinement
 */
export declare class ProgressiveTranscriptionManager extends EventEmitter {
    private readonly CONFIDENCE_SMOOTHING_FACTOR;
    private readonly OVERLAP_DETECTION_THRESHOLD;
    private readonly PROGRESSIVE_EMIT_INTERVAL;
    private progressiveResults;
    private emitIntervals;
    /**
     * Initialize progressive transcription for a session
     */
    initializeSession(sessionId: string, options: StreamingTranscriptionOptions): void;
    /**
     * Add a partial result to the progressive stream
     */
    addPartialResult(sessionId: string, partialResult: PartialTranscriptionResult): void;
    /**
     * Refine partial result using context and previous results
     */
    private refinePartialResult;
    /**
     * Detect and resolve text overlap between consecutive results
     */
    private detectAndResolveOverlap;
    /**
     * Find text overlap between two strings
     */
    private findTextOverlap;
    /**
     * Apply contextual refinement to improve accuracy
     */
    private applyContextualRefinement;
    /**
     * Apply semantically aware text smoothing
     */
    private applySemanticallyAwareSmoothening;
    /**
     * Calculate context score based on consistency with previous results
     */
    private calculateContextScore;
    /**
     * Smooth confidence scores over time
     */
    private smoothConfidenceScore;
    /**
     * Update consolidated text for the session
     */
    private updateConsolidatedText;
    /**
     * Emit progressive result if conditions are met
     */
    private emitProgressiveResult;
    /**
     * Get consolidated result for a session
     */
    getConsolidatedResult(sessionId: string): ConsolidatedResult | null;
    /**
     * Calculate average processing latency
     */
    private calculateAverageLatency;
    /**
     * Generate consolidated word timestamps
     */
    private generateConsolidatedWordTimestamps;
    /**
     * Cleanup session resources
     */
    cleanupSession(sessionId: string): void;
    /**
     * Get session statistics
     */
    getSessionStats(sessionId: string): ProgressiveSessionStats | null;
}
export interface ConsolidatedResult {
    text: string;
    confidence: number;
    wordCount: number;
    chunkCount: number;
    averageLatency: number;
    wordTimestamps: WordTimestamp[];
}
export interface ProgressiveSessionStats {
    sessionId: string;
    chunkCount: number;
    wordCount: number;
    averageConfidence: number;
    totalTextLength: number;
    lastUpdateTime: number;
    sessionDuration: number;
}
//# sourceMappingURL=ProgressiveTranscriptionManager.d.ts.map