import { IStreamingTranscriptionService } from '../../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../../types/index.js';
import { TranscriptionService } from '../TranscriptionService.js';
import { ProgressiveTranscriptionManager } from './ProgressiveTranscriptionManager.js';
import { LocalWhisperService } from './LocalWhisperService.js';
import { v4 as uuidv4 } from 'uuid';
/**
 * StreamingTranscriptionService - Local-only streaming transcription service
 *
 * Uses ONLY local whisper.cpp for streaming (fast, no rate limits, offline).
 * Azure OpenAI is reserved for batch processing only.
 * This service provides streaming transcription capabilities by:
 * 1. Managing streaming sessions with context preservation
 * 2. Processing audio chunks using local Whisper with Apple Silicon GPU acceleration
 * 3. Providing progressive results with confidence scoring
 * 4. Maintaining backward compatibility with Azure OpenAI for batch processing only
 */
export class StreamingTranscriptionService extends IStreamingTranscriptionService {
    constructor(apiKey, endpoint, apiVersion, whisperDeployment, fileService, configuration) {
        super();
        this.activeSessions = new Map();
        // Configuration constants
        this.DEFAULT_CONTEXT_WINDOW = 3; // Number of previous chunks to include
        this.DEFAULT_MIN_CONFIDENCE = 0.3;
        this.DEFAULT_CHUNK_OVERLAP = 0.5; // Seconds of overlap between chunks
        this.configuration = configuration;
        this.fileService = fileService;
        // Initialize batch transcription service for actual Whisper API calls
        this.batchTranscriptionService = new TranscriptionService(apiKey, endpoint, apiVersion, whisperDeployment, fileService, configuration);
        // Initialize local Whisper service for streaming
        this.localWhisperService = new LocalWhisperService(configuration);
        // Pre-initialize LocalWhisperService to avoid concurrent initialization issues
        this.initializeLocalWhisperService();
        // Initialize progressive transcription manager
        this.progressiveManager = new ProgressiveTranscriptionManager();
        // Forward events from batch service
        this.batchTranscriptionService.on('transcription:started', (data) => this.emit('streaming:chunk:started', data));
        this.batchTranscriptionService.on('transcription:progress', (data) => this.emit('streaming:chunk:progress', data));
        this.batchTranscriptionService.on('transcription:completed', (data) => this.emit('streaming:chunk:completed', data));
        this.batchTranscriptionService.on('transcription:error', (data) => this.emit('streaming:chunk:error', data));
        // Forward progressive events
        this.progressiveManager.on('progressive:result:updated', (data) => this.emit('streaming:progressive:update', data));
        this.progressiveManager.on('progressive:overlap:detected', (data) => this.emit('streaming:overlap:detected', data));
        this.progressiveManager.on('progressive:result:filtered', (data) => this.emit('streaming:result:filtered', data));
    }
    /**
     * Pre-initialize LocalWhisperService to avoid concurrent initialization issues during streaming
     */
    async initializeLocalWhisperService() {
        try {
            // Trigger initialization by creating a small dummy buffer and calling transcribe
            const dummyBuffer = Buffer.alloc(1024); // 1KB of silence
            // This will trigger LocalWhisperService.initializeModel() and set up whisper paths
            await this.localWhisperService.transcribe(dummyBuffer, { language: 'en' });
        }
        catch (error) {
            console.error('⚠️ [StreamingTranscriptionService] LocalWhisperService pre-initialization failed:', error);
            // Don't throw - allow the service to start but streaming may fail
        }
    }
    /**
     * Start a new streaming transcription session
     */
    async startStreamingSession(options = {}) {
        const sessionId = uuidv4();
        const context = {
            sessionId,
            startTime: Date.now(),
            lastChunkTime: Date.now(),
            processedChunks: 0,
            accumulatedText: '',
            averageConfidence: 0,
            contextWindow: [],
            options: {
                ...options,
                contextWindow: options.contextWindow ?? this.DEFAULT_CONTEXT_WINDOW,
                minConfidenceThreshold: options.minConfidenceThreshold ?? this.DEFAULT_MIN_CONFIDENCE,
                enablePartialResults: options.enablePartialResults ?? true,
                enableWordTimestamps: options.enableWordTimestamps ?? false
            }
        };
        this.activeSessions.set(sessionId, context);
        // Initialize progressive transcription for this session
        this.progressiveManager.initializeSession(sessionId, context.options);
        this.emit('streaming:session:started', { sessionId, options: context.options });
        return sessionId;
    }
    /**
     * End a streaming session and return final consolidated result
     */
    async endStreamingSession(sessionId) {
        const context = this.activeSessions.get(sessionId);
        if (!context) {
            // Session already ended or not found - return empty result (idempotent behavior)
            // This prevents race conditions when multiple processes try to end the same session
            return {
                text: '',
                language: 'en',
                duration: 0,
                confidence: 0,
                wordCount: 0
            };
        }
        // Get consolidated result from progressive manager
        const consolidatedResult = this.progressiveManager.getConsolidatedResult(sessionId);
        const endTime = Date.now();
        const totalDuration = endTime - context.startTime;
        const finalResult = {
            text: consolidatedResult?.text || context.accumulatedText.trim(),
            confidence: consolidatedResult?.confidence || context.averageConfidence,
            duration: totalDuration,
            wordCount: consolidatedResult?.wordCount || context.accumulatedText.split(/\s+/).filter(word => word.length > 0).length,
            language: context.options.language
        };
        // Clean up sessions (but NOT local whisper - it's shared across all sessions)
        this.progressiveManager.cleanupSession(sessionId);
        // Don't cleanup localWhisperService here - it's shared and needed for other sessions
        this.activeSessions.delete(sessionId);
        this.emit('streaming:session:ended', {
            sessionId,
            result: finalResult,
            chunksProcessed: context.processedChunks,
            consolidatedStats: consolidatedResult
        });
        return finalResult;
    }
    /**
     * Process a single audio chunk within a streaming session
     */
    async processChunk(audioChunk, options = {}) {
        // For standalone chunk processing, create temporary session
        const sessionId = await this.startStreamingSession(options);
        try {
            const results = await this.processChunkSequence([audioChunk], sessionId);
            await this.endStreamingSession(sessionId);
            return results[0];
        }
        catch (error) {
            // Clean up temporary session on error
            this.activeSessions.delete(sessionId);
            throw error;
        }
    }
    /**
     * Process multiple chunks in sequence with context preservation
     */
    async processChunkSequence(chunks, sessionId) {
        const context = this.activeSessions.get(sessionId);
        if (!context) {
            throw new AppError(`Streaming session not found: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        const results = [];
        for (const chunk of chunks) {
            try {
                const result = await this.processIndividualChunk(chunk, context);
                results.push(result);
                // Update context
                context.lastChunkTime = chunk.timestamp;
                context.processedChunks++;
                // Add to context window (maintain sliding window)
                context.contextWindow.push(chunk);
                if (context.contextWindow.length > context.options.contextWindow) {
                    context.contextWindow.shift();
                }
                // Add result to progressive manager for refinement and progressive emission (if session still exists)
                try {
                    this.progressiveManager.addPartialResult(sessionId, result);
                }
                catch {
                    // Session may have been cleaned up - ignore progressive update errors
                }
            }
            catch (error) {
                this.emit('streaming:chunk:error', { sessionId, chunkId: chunk.sequenceId, error });
                throw error;
            }
        }
        return results;
    }
    /**
     * Process an individual chunk with context
     */
    async processIndividualChunk(chunk, context) {
        try {
            // Create combined audio buffer with context window for better accuracy
            const combinedBuffer = await this.createContextualBuffer(chunk, context);
            // Debug: Check if combined buffer is empty or invalid
            if (!combinedBuffer || combinedBuffer.length === 0) {
                console.error(`❌ [StreamingTranscription] [${chunk.sequenceId}] Combined buffer is empty! This will cause LocalWhisper to fail`);
                throw new AppError('Audio buffer is empty - cannot transcribe', ErrorCode.TRANSCRIPTION_FAILED, { chunkId: chunk.sequenceId, mode: 'streaming' });
            }
            // Try to use local Whisper service for streaming transcription (no rate limits!)
            const transcriptionOptions = {
                language: context.options.language,
                temperature: context.options.temperature,
                prompt: this.buildContextualPrompt(context)
            };
            let batchResult;
            try {
                // Use local Whisper for streaming ONLY - no cloud fallback for streaming mode
                batchResult = await this.localWhisperService.transcribe(combinedBuffer, transcriptionOptions);
            }
            catch (error) {
                // For streaming mode, we fail fast if local whisper is unavailable - no cloud fallback
                console.error(`❌ [StreamingTranscription] [${chunk.sequenceId}] Local Whisper failed in streaming mode (no fallback):`, error);
                throw new AppError('Streaming transcription failed: Local whisper service unavailable', ErrorCode.TRANSCRIPTION_FAILED, {
                    localWhisperError: error instanceof Error ? error.message : 'Unknown local error',
                    chunkId: chunk.sequenceId,
                    mode: 'streaming'
                });
            }
            // Extract new content by removing context overlap
            const newText = this.extractNewContent(batchResult.text, context);
            // Calculate confidence (simplified approach - could be enhanced with word-level analysis)
            const confidence = this.calculateChunkConfidence(batchResult, newText);
            // Update accumulated text if confidence meets threshold
            if (confidence >= context.options.minConfidenceThreshold) {
                context.accumulatedText += (context.accumulatedText ? ' ' : '') + newText;
                context.averageConfidence = this.updateAverageConfidence(context.averageConfidence, confidence, context.processedChunks);
            }
            // Generate word timestamps if enabled (simplified implementation)
            const wordTimestamps = context.options.enableWordTimestamps ?
                this.generateWordTimestamps(newText, chunk.timestamp, chunk.duration) : undefined;
            const partialResult = {
                text: newText,
                confidence,
                isComplete: false, // Always false for chunk results
                timestamp: chunk.timestamp,
                sequenceId: chunk.sequenceId,
                wordTimestamps
            };
            this.emit('streaming:partial:result', { sessionId: context.sessionId, result: partialResult });
            return partialResult;
        }
        catch (error) {
            console.error(`❌ [StreamingTranscription] [${chunk.sequenceId}] FATAL ERROR in processIndividualChunk:`, error);
            console.error(`❌ [StreamingTranscription] [${chunk.sequenceId}] Error stack:`, error instanceof Error ? error.stack : 'No stack trace');
            throw error; // Re-throw the error after logging
        }
    }
    /**
     * Create combined buffer with context window for improved accuracy
     */
    async createContextualBuffer(currentChunk, context) {
        // Validate current chunk data
        if (!currentChunk.data || !Buffer.isBuffer(currentChunk.data)) {
            return Buffer.alloc(0); // Return empty buffer for invalid data
        }
        if (context.contextWindow.length === 0) {
            return currentChunk.data;
        }
        // Combine previous chunks with current chunk
        // Note: This is a simplified implementation. In production, proper audio mixing would be needed
        const buffers = [];
        // Add recent context chunks (validate each chunk)
        const recentChunks = context.contextWindow.slice(-Math.min(2, context.contextWindow.length));
        for (const chunk of recentChunks) {
            if (chunk.data && Buffer.isBuffer(chunk.data)) {
                buffers.push(chunk.data);
            }
        }
        // Add current chunk
        buffers.push(currentChunk.data);
        return Buffer.concat(buffers);
    }
    /**
     * Build contextual prompt to improve transcription accuracy
     */
    buildContextualPrompt(context) {
        if (!context.accumulatedText) {
            return context.options.prompt || '';
        }
        // Use recent text as context for better continuity
        const recentText = context.accumulatedText.split(' ').slice(-10).join(' ');
        const basePrompt = context.options.prompt || '';
        return basePrompt ? `${basePrompt}\n\nPrevious context: "${recentText}"` : `Previous context: "${recentText}"`;
    }
    /**
     * Extract new content from transcription result by removing overlap
     */
    extractNewContent(fullText, context) {
        if (!context.accumulatedText) {
            return fullText;
        }
        // Simple approach: try to find where new content starts
        // This could be enhanced with more sophisticated overlap detection
        const words = fullText.split(' ');
        const contextWords = context.accumulatedText.split(' ');
        // Find potential overlap
        let startIndex = 0;
        for (let i = Math.max(0, contextWords.length - 5); i < contextWords.length; i++) {
            const contextWord = contextWords[i]?.toLowerCase();
            for (let j = 0; j < Math.min(5, words.length); j++) {
                if (words[j]?.toLowerCase() === contextWord) {
                    startIndex = j + 1;
                    break;
                }
            }
        }
        return words.slice(startIndex).join(' ').trim();
    }
    /**
     * Calculate confidence score for chunk (simplified implementation)
     */
    calculateChunkConfidence(batchResult, newText) {
        // Use batch result confidence if available, otherwise estimate based on text quality
        if (batchResult.confidence !== undefined) {
            return batchResult.confidence;
        }
        // Simple heuristic: longer text with common words gets higher confidence
        const wordCount = newText.split(' ').length;
        const hasCommonWords = /\b(the|and|is|in|to|of|a|that|it|with|for|as|was|on|are|you|they|be|at|one|have|this|from|or|had|by|but|not|what|all|can|her|were|there|we|when|your|said)\b/i.test(newText);
        let confidence = Math.min(0.9, 0.5 + (wordCount * 0.1));
        if (hasCommonWords)
            confidence += 0.1;
        return Math.max(0.1, confidence);
    }
    /**
     * Update running average confidence
     */
    updateAverageConfidence(currentAverage, newConfidence, chunkCount) {
        if (chunkCount === 0)
            return newConfidence;
        return ((currentAverage * chunkCount) + newConfidence) / (chunkCount + 1);
    }
    /**
     * Generate word-level timestamps (simplified implementation)
     */
    generateWordTimestamps(text, chunkStart, chunkDuration) {
        const words = text.split(' ').filter(word => word.length > 0);
        const wordTimestamps = [];
        const avgWordDuration = chunkDuration / words.length;
        words.forEach((word, index) => {
            const start = chunkStart + (index * avgWordDuration);
            const end = start + avgWordDuration;
            wordTimestamps.push({
                word,
                start,
                end,
                confidence: 0.8 // Simplified confidence
            });
        });
        return wordTimestamps;
    }
    /**
     * Get streaming context for a session
     */
    getStreamingContext(sessionId) {
        return this.activeSessions.get(sessionId) || null;
    }
    /**
     * Update streaming configuration during active session
     */
    async updateStreamingConfig(sessionId, config) {
        const context = this.activeSessions.get(sessionId);
        if (!context) {
            throw new AppError(`Streaming session not found: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        // Update options
        context.options = { ...context.options, ...config };
        this.emit('streaming:config:updated', { sessionId, config });
    }
    // Implement base ITranscriptionService methods by delegating to batch service
    async transcribe(audioBuffer, options = {}) {
        // Use local whisper for batch transcription if enabled in configuration (default: true)
        if (this.configuration.app.useLocalWhisper !== false) {
            try {
                return await this.localWhisperService.transcribe(audioBuffer, options);
            }
            catch (error) {
                console.error('⚠️ [StreamingTranscriptionService] Local Whisper failed for batch mode:', error);
                // If local whisper fails and Azure is configured, fall back to Azure
                if (this.configuration.azureOpenAI.apiKey && this.configuration.azureOpenAI.endpoint) {
                    return this.batchTranscriptionService.transcribe(audioBuffer, options);
                }
                // Re-throw if no Azure fallback available
                throw error;
            }
        }
        // Use Azure OpenAI batch transcription when explicitly disabled
        return this.batchTranscriptionService.transcribe(audioBuffer, options);
    }
    async checkAvailability() {
        // Check local whisper service if enabled in configuration (default: true)
        if (this.configuration.app.useLocalWhisper !== false) {
            try {
                // For local whisper, ensure it's initialized first, then check if ready
                await this.initializeLocalWhisperService();
                return this.localWhisperService.isReady();
            }
            catch (error) {
                console.error('⚠️ [StreamingTranscriptionService] Local Whisper availability check failed:', error);
                // If local whisper fails but Azure is configured, check Azure as fallback
                if (this.configuration.azureOpenAI.apiKey && this.configuration.azureOpenAI.endpoint) {
                    return this.batchTranscriptionService.checkAvailability();
                }
                return false;
            }
        }
        // Use Azure OpenAI availability check when local whisper is explicitly disabled
        return this.batchTranscriptionService.checkAvailability();
    }
    getSupportedFormats() {
        return this.batchTranscriptionService.getSupportedFormats();
    }
    async transcribeWithRetry(audioBuffer, options = {}, maxRetries = 3) {
        // Use local whisper for batch transcription if enabled in configuration (default: true)
        if (this.configuration.app.useLocalWhisper !== false) {
            try {
                // Local whisper is more reliable, usually doesn't need retries
                return await this.localWhisperService.transcribe(audioBuffer, options);
            }
            catch (error) {
                console.error('⚠️ [StreamingTranscriptionService] Local Whisper failed for batch mode with retry:', error);
                // If local whisper fails and Azure is configured, fall back to Azure with retry
                if (this.configuration.azureOpenAI.apiKey && this.configuration.azureOpenAI.endpoint) {
                    return this.batchTranscriptionService.transcribeWithRetry(audioBuffer, options, maxRetries);
                }
                // Re-throw if no Azure fallback available
                throw error;
            }
        }
        // Use Azure OpenAI batch transcription with retry when explicitly disabled
        return this.batchTranscriptionService.transcribeWithRetry(audioBuffer, options, maxRetries);
    }
}
//# sourceMappingURL=StreamingTranscriptionService.js.map