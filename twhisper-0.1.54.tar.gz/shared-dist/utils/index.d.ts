export * from './debug.js';
//# sourceMappingURL=index.d.ts.map