export interface LocalizedContent {
    systemPrompt: string;
    examples: string[];
    userPromptTemplate: string;
    description?: string;
}
export interface Mode {
    id?: string;
    name: string;
    description: string;
    prompt?: string;
    systemPrompt: string;
    examples: string[];
    settings?: ModeSettings;
    active?: boolean;
    localizedContent?: {
        [language: string]: LocalizedContent;
    };
}
export interface ModeSettings {
    temperature: number;
    maxTokens: number;
    systemPrompt: string;
    userPromptTemplate: string;
    outputFormat: OutputFormat;
    postProcessing: PostProcessingOptions;
}
export interface OutputFormat {
    preserveLineBreaks: boolean;
    addParagraphBreaks: boolean;
    capitalizeFirst: boolean;
    addPunctuation: boolean;
    removeFillerWords: boolean;
    correctGrammar: boolean;
}
export interface PostProcessingOptions {
    trimWhitespace: boolean;
    removeExtraSpaces: boolean;
    normalizeQuotes: boolean;
    fixCommonTypos: boolean;
}
export interface ModeRegistry {
    modes: Map<string, Mode>;
    defaultMode: string;
    currentMode: string;
}
export declare class ModeRegistryImpl implements ModeRegistry {
    modes: Map<string, Mode>;
    defaultMode: string;
    currentMode: string;
    constructor();
    /**
     * Initialize default modes
     */
    private initializeDefaultModes;
    /**
     * Add a mode to the registry
     */
    addMode(mode: Mode): void;
    /**
     * Get a mode by ID
     */
    getMode(id: string): Mode | undefined;
    /**
     * Get all active modes
     */
    getActiveModes(): Mode[];
    /**
     * Get mode IDs in order
     */
    getModeIds(): string[];
    /**
     * Set current mode
     */
    setCurrentMode(modeId: string): boolean;
    /**
     * Get current mode
     */
    getCurrentMode(): Mode | undefined;
    /**
     * Get localized content for a mode based on language
     */
    getLocalizedContent(modeId: string, language: string): LocalizedContent | undefined;
    /**
     * Get mode with localized content applied
     */
    getModeWithLocalization(modeId: string, language?: string): Mode | undefined;
    /**
     * Cycle to next mode
     */
    cycleToNextMode(): Mode | undefined;
}
//# sourceMappingURL=modes.d.ts.map