// Settings UI types and interfaces
export var SettingsCategory;
(function (SettingsCategory) {
    SettingsCategory["AZURE_OPENAI"] = "azureOpenAI";
    SettingsCategory["APPLICATION"] = "app";
    SettingsCategory["AUDIO"] = "audio";
    SettingsCategory["UI"] = "ui";
    SettingsCategory["SECURITY"] = "security";
    SettingsCategory["ADVANCED"] = "advanced";
})(SettingsCategory || (SettingsCategory = {}));
// Security and storage types
export var SecurityLevel;
(function (SecurityLevel) {
    SecurityLevel["PLAINTEXT"] = "plaintext";
    SecurityLevel["ENCRYPTED_FILE"] = "encrypted_file";
    SecurityLevel["SYSTEM_KEYCHAIN"] = "system_keychain";
    SecurityLevel["MEMORY_ONLY"] = "memory_only";
})(SecurityLevel || (SecurityLevel = {}));
//# sourceMappingURL=settings.js.map