import { IFileService } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
import fs from 'fs/promises';
import path from 'path';
import { tmpdir } from 'os';
import { randomBytes } from 'crypto';
export class FileService extends IFileService {
    constructor(customTempDir) {
        super();
        this.tempFiles = new Set();
        this.tempDir = customTempDir || path.join(tmpdir(), 'Twhisper-cli');
        this.ensureTempDirExists();
    }
    async ensureTempDirExists() {
        try {
            await fs.access(this.tempDir);
        }
        catch {
            try {
                await fs.mkdir(this.tempDir, { recursive: true });
            }
            catch (error) {
                throw new AppError('Failed to create temporary directory', ErrorCode.FILE_OPERATION_ERROR, { tempDir: this.tempDir, error: error instanceof Error ? error.message : 'Unknown error' });
            }
        }
    }
    async createTempFile(extension, data) {
        await this.ensureTempDirExists();
        const timestamp = Date.now();
        const randomSuffix = randomBytes(8).toString('hex');
        const fileName = `temp_${timestamp}_${randomSuffix}.${extension.replace(/^\./, '')}`;
        const filePath = path.join(this.tempDir, fileName);
        try {
            if (data) {
                await fs.writeFile(filePath, data);
            }
            else {
                // Create empty file
                await fs.writeFile(filePath, Buffer.alloc(0));
            }
            // Track the temporary file for cleanup
            this.tempFiles.add(filePath);
            return filePath;
        }
        catch (error) {
            throw new AppError('Failed to create temporary file', ErrorCode.FILE_OPERATION_ERROR, {
                filePath,
                extension,
                hasData: !!data,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    async deleteTempFile(filePath) {
        try {
            await fs.unlink(filePath);
            this.tempFiles.delete(filePath);
            return true;
        }
        catch (error) {
            // If file doesn't exist, consider it successfully deleted
            if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
                this.tempFiles.delete(filePath);
                return true;
            }
            throw new AppError('Failed to delete temporary file', ErrorCode.FILE_OPERATION_ERROR, { filePath, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    async cleanupTempFiles() {
        let deletedCount = 0;
        const failures = [];
        for (const filePath of this.tempFiles) {
            try {
                await fs.unlink(filePath);
                deletedCount++;
            }
            catch (error) {
                // File might not exist, which is fine
                if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) {
                    failures.push(`${filePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
                }
                else {
                    deletedCount++; // Count non-existent files as successfully cleaned
                }
            }
        }
        // Clear the tracking set
        this.tempFiles.clear();
        if (failures.length > 0) {
            throw new AppError('Some temporary files could not be deleted', ErrorCode.FILE_OPERATION_ERROR, { deletedCount, failures });
        }
        return deletedCount;
    }
    async exists(filePath) {
        try {
            await fs.access(filePath);
            return true;
        }
        catch {
            return false;
        }
    }
    async readFile(filePath) {
        try {
            return await fs.readFile(filePath);
        }
        catch (error) {
            throw new AppError('Failed to read file', ErrorCode.FILE_OPERATION_ERROR, { filePath, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    async writeFile(filePath, data) {
        try {
            await fs.writeFile(filePath, data);
            return true;
        }
        catch (error) {
            throw new AppError('Failed to write file', ErrorCode.FILE_OPERATION_ERROR, { filePath, dataSize: data.length, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Get the current temporary directory path
     */
    getTempDir() {
        return this.tempDir;
    }
    /**
     * Get the number of tracked temporary files
     */
    getTempFileCount() {
        return this.tempFiles.size;
    }
    /**
     * Get all tracked temporary file paths
     */
    getTempFilePaths() {
        return Array.from(this.tempFiles);
    }
    /**
     * Clean up old temporary files based on age
     */
    async cleanupOldTempFiles(maxAgeMs = 3600000) {
        await this.ensureTempDirExists();
        let deletedCount = 0;
        const now = Date.now();
        try {
            const entries = await fs.readdir(this.tempDir, { withFileTypes: true });
            for (const entry of entries) {
                if (!entry.isFile() || !entry.name.startsWith('temp_')) {
                    continue;
                }
                const filePath = path.join(this.tempDir, entry.name);
                try {
                    const stats = await fs.stat(filePath);
                    const age = now - stats.mtime.getTime();
                    if (age > maxAgeMs) {
                        await fs.unlink(filePath);
                        this.tempFiles.delete(filePath);
                        deletedCount++;
                    }
                }
                catch {
                    // Skip files that can't be accessed or deleted
                    continue;
                }
            }
        }
        catch (error) {
            throw new AppError('Failed to cleanup old temporary files', ErrorCode.FILE_OPERATION_ERROR, { tempDir: this.tempDir, maxAgeMs, error: error instanceof Error ? error.message : 'Unknown error' });
        }
        return deletedCount;
    }
    /**
     * Create a temporary WAV file with proper audio headers
     */
    async createTempWavFile(audioBuffer, sampleRate = 16000, channels = 1) {
        const wavHeader = this.createWavHeader(audioBuffer.length, sampleRate, channels);
        const wavBuffer = Buffer.concat([wavHeader, audioBuffer]);
        return await this.createTempFile('wav', wavBuffer);
    }
    createWavHeader(audioDataLength, sampleRate, channels) {
        const header = Buffer.alloc(44);
        // RIFF chunk descriptor
        header.write('RIFF', 0);
        header.writeUInt32LE(36 + audioDataLength, 4); // ChunkSize
        header.write('WAVE', 8);
        // fmt sub-chunk
        header.write('fmt ', 12);
        header.writeUInt32LE(16, 16); // Subchunk1Size (PCM)
        header.writeUInt16LE(1, 20); // AudioFormat (PCM)
        header.writeUInt16LE(channels, 22); // NumChannels
        header.writeUInt32LE(sampleRate, 24); // SampleRate
        header.writeUInt32LE(sampleRate * channels * 2, 28); // ByteRate (SampleRate * NumChannels * BitsPerSample/8)
        header.writeUInt16LE(channels * 2, 32); // BlockAlign (NumChannels * BitsPerSample/8)
        header.writeUInt16LE(16, 34); // BitsPerSample
        // data sub-chunk
        header.write('data', 36);
        header.writeUInt32LE(audioDataLength, 40); // Subchunk2Size
        return header;
    }
}
//# sourceMappingURL=FileService.js.map