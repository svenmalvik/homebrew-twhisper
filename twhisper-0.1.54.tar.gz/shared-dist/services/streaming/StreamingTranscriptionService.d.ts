import { IStreamingTranscriptionService, AudioChunk, PartialTranscriptionResult, StreamingTranscriptionOptions, TranscriptionResult, StreamingContext, TranscriptionOptions, Configuration } from '../../interfaces/interfaces.js';
import { IFileService } from '../../interfaces/interfaces.js';
/**
 * StreamingTranscriptionService - Local-only streaming transcription service
 *
 * Uses ONLY local whisper.cpp for streaming (fast, no rate limits, offline).
 * Azure OpenAI is reserved for batch processing only.
 * This service provides streaming transcription capabilities by:
 * 1. Managing streaming sessions with context preservation
 * 2. Processing audio chunks using local Whisper with Apple Silicon GPU acceleration
 * 3. Providing progressive results with confidence scoring
 * 4. Maintaining backward compatibility with Azure OpenAI for batch processing only
 */
export declare class StreamingTranscriptionService extends IStreamingTranscriptionService {
    private batchTranscriptionService;
    private localWhisperService;
    private activeSessions;
    private progressiveManager;
    private fileService;
    private configuration;
    private readonly DEFAULT_CONTEXT_WINDOW;
    private readonly DEFAULT_MIN_CONFIDENCE;
    private readonly DEFAULT_CHUNK_OVERLAP;
    constructor(apiKey: string, endpoint: string, apiVersion: string, whisperDeployment: string, fileService: IFileService, configuration: Configuration);
    /**
     * Pre-initialize LocalWhisperService to avoid concurrent initialization issues during streaming
     */
    private initializeLocalWhisperService;
    /**
     * Start a new streaming transcription session
     */
    startStreamingSession(options?: StreamingTranscriptionOptions): Promise<string>;
    /**
     * End a streaming session and return final consolidated result
     */
    endStreamingSession(sessionId: string): Promise<TranscriptionResult>;
    /**
     * Process a single audio chunk within a streaming session
     */
    processChunk(audioChunk: AudioChunk, options?: StreamingTranscriptionOptions): Promise<PartialTranscriptionResult>;
    /**
     * Process multiple chunks in sequence with context preservation
     */
    processChunkSequence(chunks: AudioChunk[], sessionId: string): Promise<PartialTranscriptionResult[]>;
    /**
     * Process an individual chunk with context
     */
    private processIndividualChunk;
    /**
     * Create combined buffer with context window for improved accuracy
     */
    private createContextualBuffer;
    /**
     * Build contextual prompt to improve transcription accuracy
     */
    private buildContextualPrompt;
    /**
     * Extract new content from transcription result by removing overlap
     */
    private extractNewContent;
    /**
     * Calculate confidence score for chunk (simplified implementation)
     */
    private calculateChunkConfidence;
    /**
     * Update running average confidence
     */
    private updateAverageConfidence;
    /**
     * Generate word-level timestamps (simplified implementation)
     */
    private generateWordTimestamps;
    /**
     * Get streaming context for a session
     */
    getStreamingContext(sessionId: string): StreamingContext | null;
    /**
     * Update streaming configuration during active session
     */
    updateStreamingConfig(sessionId: string, config: Partial<StreamingTranscriptionOptions>): Promise<void>;
    transcribe(audioBuffer: Buffer, options?: TranscriptionOptions): Promise<TranscriptionResult>;
    checkAvailability(): Promise<boolean>;
    getSupportedFormats(): string[];
    transcribeWithRetry(audioBuffer: Buffer, options?: TranscriptionOptions, maxRetries?: number): Promise<TranscriptionResult>;
}
//# sourceMappingURL=StreamingTranscriptionService.d.ts.map