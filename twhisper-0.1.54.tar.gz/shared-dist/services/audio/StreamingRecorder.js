import { EventEmitter } from 'events';
import { CircularBuffer } from './CircularBuffer.js';
export class StreamingRecorder extends EventEmitter {
    constructor(options = {}) {
        super();
        this.recorder = null;
        this.circularBuffer = null;
        this.isActive = false;
        this.startTime = null;
        this.sequenceId = 0;
        this.monitoringInterval = null;
        this.qualityHistory = [];
        this.latencyHistory = [];
        this.lastChunkTime = 0;
        this.adaptiveAdjustmentCount = 0;
        // Audio processing parameters
        this.config = {
            sampleRate: 16000,
            channels: 1,
            encoding: 'signed-integer',
            silence: '1.0',
            endOnSilence: false,
            thresholdStart: 0.5,
            thresholdEnd: 0.5,
            verbose: false
        };
        this.options = {
            bufferDuration: options.bufferDuration ?? 5,
            chunkSize: options.chunkSize ?? 4096,
            overlapDuration: options.overlapDuration ?? 0,
            sampleRate: options.sampleRate ?? 16000,
            channels: options.channels ?? 1,
            maxDuration: options.maxDuration ?? undefined,
            minDuration: options.minDuration ?? undefined,
            continuousMode: options.continuousMode ?? true,
            adaptiveChunkSize: options.adaptiveChunkSize ?? true,
            qualityMonitoring: options.qualityMonitoring ?? true,
            minChunkSize: options.minChunkSize ?? 1024,
            maxChunkSize: options.maxChunkSize ?? 8192
        };
        this.initializeMetrics();
    }
    /**
     * Start streaming audio capture with enhanced capabilities
     */
    async start() {
        if (this.isActive) {
            throw new Error('StreamingRecorder is already active');
        }
        try {
            // Initialize streaming components
            this.initializeCircularBuffer();
            this.initializeMetrics();
            this.resetCounters();
            // Dynamic import for audio recording
            const { createRequire } = await import('module');
            const require = createRequire(import.meta.url);
            const record = require('node-record-lpcm16');
            // Update config with current options
            this.config.sampleRate = this.options.sampleRate;
            this.config.channels = this.options.channels;
            this.recorder = record.record(this.config);
            if (!this.recorder) {
                throw new Error('Failed to initialize streaming recorder');
            }
            this.isActive = true;
            this.startTime = Date.now();
            this.lastChunkTime = this.startTime;
            // Set up event handlers
            this.recorder.stream().on('data', (chunk) => {
                this.handleAudioChunk(chunk);
            });
            this.recorder.stream().on('error', (error) => {
                this.handleError(error);
            });
            // Start monitoring if enabled
            if (this.options.qualityMonitoring) {
                this.startQualityMonitoring();
            }
            this.emit('started', {
                timestamp: this.startTime,
                options: this.options,
                config: this.config
            });
        }
        catch (error) {
            this.handleError(error);
        }
    }
    /**
     * Stop streaming audio capture
     */
    async stop() {
        if (!this.isActive || !this.recorder) {
            return;
        }
        try {
            this.recorder.stop();
            this.isActive = false;
            const finalStatus = this.getStatus();
            this.emit('stopped', {
                timestamp: Date.now(),
                finalStatus,
                summary: this.generateSessionSummary()
            });
            this.cleanup();
        }
        catch (error) {
            this.handleError(error);
        }
    }
    /**
     * Get current streaming status
     */
    getStatus() {
        const bufferStatus = this.circularBuffer?.getStatus();
        const duration = this.getDuration();
        return {
            isActive: this.isActive,
            duration,
            chunksProcessed: this.sequenceId,
            bytesProcessed: bufferStatus?.totalBytesProcessed ?? 0,
            bufferUtilization: bufferStatus?.utilization ?? 0,
            currentSampleRate: this.config.sampleRate,
            currentChunkSize: this.options.chunkSize,
            qualityMetrics: { ...this.qualityMetrics },
            streamingMetrics: { ...this.streamingMetrics }
        };
    }
    /**
     * Get audio buffer for processing
     */
    getAudioBuffer(chunkCount) {
        if (!this.circularBuffer) {
            return Buffer.alloc(0);
        }
        return this.circularBuffer.getAudioBuffer(chunkCount);
    }
    /**
     * Get recent audio chunks
     */
    getRecentChunks(count) {
        if (!this.circularBuffer) {
            return [];
        }
        return this.circularBuffer.getRecentChunks(count);
    }
    /**
     * Update streaming options dynamically
     */
    updateOptions(newOptions) {
        if (this.isActive && (newOptions.sampleRate || newOptions.channels)) {
            throw new Error('Cannot change audio parameters while streaming is active');
        }
        // Update options
        Object.assign(this.options, newOptions);
        // Reconfigure buffer if needed
        if (this.circularBuffer && (newOptions.bufferDuration || newOptions.chunkSize)) {
            const bufferOptions = {
                maxSizeSeconds: this.options.bufferDuration,
                chunkSizeBytes: this.options.chunkSize,
                sampleRate: this.options.sampleRate,
                channels: this.options.channels,
                autoResize: true
            };
            if (!this.circularBuffer.configure(bufferOptions)) {
                // Buffer has data, need to restart for changes to take effect
                this.emit('configurationPending', {
                    reason: 'Buffer contains data',
                    newOptions
                });
            }
        }
        this.emit('optionsUpdated', newOptions);
    }
    /**
     * Handle incoming audio chunk with enhanced processing
     */
    handleAudioChunk(chunk) {
        const now = Date.now();
        const latency = now - this.lastChunkTime;
        // Create audio chunk with metadata
        const audioChunk = {
            data: chunk,
            timestamp: now,
            sequenceId: this.sequenceId++,
            sampleRate: this.config.sampleRate,
            channels: this.config.channels,
            duration: chunk.length / (this.config.sampleRate * 2 * this.config.channels)
        };
        // Quality monitoring
        if (this.options.qualityMonitoring) {
            this.updateQualityMetrics(chunk);
        }
        // Performance metrics
        this.updateStreamingMetrics(latency);
        // Adaptive chunk size adjustment
        if (this.options.adaptiveChunkSize) {
            this.adjustChunkSizeIfNeeded();
        }
        // Add to circular buffer
        if (this.circularBuffer) {
            const success = this.circularBuffer.push(audioChunk);
            if (!success) {
                this.emit('bufferOverflow', {
                    sequenceId: audioChunk.sequenceId,
                    timestamp: now,
                    bufferStatus: this.circularBuffer.getStatus()
                });
            }
        }
        // Emit streaming events
        this.emit('chunk', {
            chunk: audioChunk,
            qualityMetrics: this.qualityMetrics,
            streamingMetrics: this.streamingMetrics,
            status: this.getStatus()
        });
        this.lastChunkTime = now;
    }
    /**
     * Update audio quality metrics
     */
    updateQualityMetrics(chunk) {
        const samples = this.bufferToSamples(chunk);
        // Calculate signal strength (RMS)
        let sumSquares = 0;
        let maxSample = 0;
        let clippedSamples = 0;
        for (const sample of samples) {
            const absValue = Math.abs(sample);
            sumSquares += sample * sample;
            maxSample = Math.max(maxSample, absValue);
            // Check for clipping (near maximum 16-bit value)
            if (absValue > 30000) {
                clippedSamples++;
            }
        }
        const rms = Math.sqrt(sumSquares / samples.length);
        const normalizedRms = rms / 32768;
        // Estimate noise level (lower percentile of samples)
        const sortedSamples = samples.map(Math.abs).sort((a, b) => a - b);
        const noiseLevel = sortedSamples[Math.floor(sortedSamples.length * 0.1)] / 32768;
        // Update metrics
        this.qualityMetrics = {
            signalStrength: normalizedRms,
            noiseLevel,
            clippingRate: clippedSamples / samples.length,
            dynamicRange: maxSample / 32768,
            snr: normalizedRms > 0 ? Math.max(0, 20 * Math.log10(normalizedRms / Math.max(noiseLevel, 0.001))) : 0
        };
        this.qualityHistory.push(this.qualityMetrics.snr);
        if (this.qualityHistory.length > 100) {
            this.qualityHistory.shift();
        }
    }
    /**
     * Update streaming performance metrics
     */
    updateStreamingMetrics(latency) {
        this.latencyHistory.push(latency);
        if (this.latencyHistory.length > 50) {
            this.latencyHistory.shift();
        }
        const duration = this.getDuration();
        const chunksPerSecond = duration > 0 ? this.sequenceId / duration : 0;
        const avgLatency = this.latencyHistory.reduce((a, b) => a + b, 0) / this.latencyHistory.length;
        const avgQuality = this.qualityHistory.reduce((a, b) => a + b, 0) / Math.max(this.qualityHistory.length, 1);
        const bufferHealth = this.circularBuffer?.getStatus().utilization ?? 0;
        this.streamingMetrics = {
            chunksPerSecond,
            averageLatency: avgLatency,
            bufferHealth,
            qualityScore: Math.min(100, Math.max(0, avgQuality)),
            adaptiveAdjustments: this.adaptiveAdjustmentCount
        };
    }
    /**
     * Adjust chunk size based on performance metrics
     */
    adjustChunkSizeIfNeeded() {
        const { averageLatency, bufferHealth } = this.streamingMetrics;
        // Increase chunk size if latency is high or buffer is underutilized
        if (averageLatency > 100 && bufferHealth < 0.3 && this.options.chunkSize < this.options.maxChunkSize) {
            this.options.chunkSize = Math.min(this.options.maxChunkSize, this.options.chunkSize * 1.2);
            this.adaptiveAdjustmentCount++;
            this.emit('chunkSizeAdjusted', {
                newSize: this.options.chunkSize,
                reason: 'High latency, low buffer utilization'
            });
        }
        // Decrease chunk size if buffer is overutilized
        if (bufferHealth > 0.8 && this.options.chunkSize > this.options.minChunkSize) {
            this.options.chunkSize = Math.max(this.options.minChunkSize, this.options.chunkSize * 0.8);
            this.adaptiveAdjustmentCount++;
            this.emit('chunkSizeAdjusted', {
                newSize: this.options.chunkSize,
                reason: 'High buffer utilization'
            });
        }
    }
    /**
     * Convert buffer to 16-bit signed integer samples
     */
    bufferToSamples(buffer) {
        const samples = [];
        for (let i = 0; i < buffer.length; i += 2) {
            samples.push(buffer.readInt16LE(i));
        }
        return samples;
    }
    /**
     * Start quality monitoring interval
     */
    startQualityMonitoring() {
        this.monitoringInterval = setInterval(() => {
            if (!this.isActive) {
                if (this.monitoringInterval) {
                    clearInterval(this.monitoringInterval);
                    this.monitoringInterval = null;
                }
                return;
            }
            const status = this.getStatus();
            // Emit periodic status updates
            this.emit('qualityReport', {
                timestamp: Date.now(),
                status,
                recommendations: this.generateRecommendations(status)
            });
            // Check for quality issues
            if (this.qualityMetrics.clippingRate > 0.05) {
                this.emit('qualityWarning', {
                    type: 'clipping',
                    severity: this.qualityMetrics.clippingRate > 0.1 ? 'high' : 'medium',
                    message: `Audio clipping detected: ${(this.qualityMetrics.clippingRate * 100).toFixed(1)}%`
                });
            }
            if (this.qualityMetrics.snr < 10) {
                this.emit('qualityWarning', {
                    type: 'noise',
                    severity: this.qualityMetrics.snr < 5 ? 'high' : 'medium',
                    message: `Low signal-to-noise ratio: ${this.qualityMetrics.snr.toFixed(1)} dB`
                });
            }
        }, 5000); // Every 5 seconds
    }
    /**
     * Generate performance recommendations
     */
    generateRecommendations(status) {
        const recommendations = [];
        if (status.qualityMetrics.clippingRate > 0.02) {
            recommendations.push('Reduce microphone input gain to prevent clipping');
        }
        if (status.qualityMetrics.snr < 15) {
            recommendations.push('Improve microphone positioning or reduce background noise');
        }
        if (status.streamingMetrics.averageLatency > 150) {
            recommendations.push('Consider increasing buffer size or chunk size for better performance');
        }
        if (status.bufferUtilization > 0.9) {
            recommendations.push('Buffer utilization high - consider increasing buffer duration');
        }
        return recommendations;
    }
    /**
     * Generate session summary
     */
    generateSessionSummary() {
        const status = this.getStatus();
        const totalDuration = this.getDuration();
        return {
            duration: totalDuration,
            totalChunks: this.sequenceId,
            averageQuality: this.qualityHistory.reduce((a, b) => a + b, 0) / Math.max(this.qualityHistory.length, 1),
            averageLatency: this.latencyHistory.reduce((a, b) => a + b, 0) / Math.max(this.latencyHistory.length, 1),
            adaptiveAdjustments: this.adaptiveAdjustmentCount,
            finalBufferUtilization: status.bufferUtilization,
            recommendations: this.generateRecommendations(status)
        };
    }
    /**
     * Initialize circular buffer
     */
    initializeCircularBuffer() {
        const bufferOptions = {
            maxSizeSeconds: this.options.bufferDuration,
            chunkSizeBytes: this.options.chunkSize,
            sampleRate: this.options.sampleRate,
            channels: this.options.channels,
            autoResize: true
        };
        this.circularBuffer = new CircularBuffer(bufferOptions);
    }
    /**
     * Initialize metrics
     */
    initializeMetrics() {
        this.qualityMetrics = {
            signalStrength: 0,
            noiseLevel: 0,
            clippingRate: 0,
            dynamicRange: 0,
            snr: 0
        };
        this.streamingMetrics = {
            chunksPerSecond: 0,
            averageLatency: 0,
            bufferHealth: 0,
            qualityScore: 0,
            adaptiveAdjustments: 0
        };
    }
    /**
     * Reset counters
     */
    resetCounters() {
        this.sequenceId = 0;
        this.adaptiveAdjustmentCount = 0;
        this.qualityHistory = [];
        this.latencyHistory = [];
    }
    /**
     * Get streaming duration in seconds
     */
    getDuration() {
        if (!this.startTime)
            return 0;
        return (Date.now() - this.startTime) / 1000;
    }
    /**
     * Handle errors
     */
    handleError(error) {
        this.isActive = false;
        this.cleanup();
        this.emit('error', error);
    }
    /**
     * Clean up resources
     */
    cleanup() {
        this.recorder = null;
        this.startTime = null;
        if (this.circularBuffer) {
            this.circularBuffer.clear();
        }
        // Clean up monitoring interval
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
    }
}
//# sourceMappingURL=StreamingRecorder.js.map