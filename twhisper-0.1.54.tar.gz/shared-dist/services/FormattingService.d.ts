import { IFormattingService, FormattingOptions, FormattingResult } from '../interfaces/interfaces.js';
import { Mode } from '../types/modes.js';
export declare class FormattingService extends IFormattingService {
    private gptDeployment;
    private apiKey;
    private endpoint;
    private apiVersion;
    private resourceName;
    private isInitialized;
    constructor(apiKey: string, endpoint: string, apiVersion: string, gptDeployment: string);
    private extractResourceName;
    format(text: string, mode: Mode, options?: FormattingOptions): Promise<FormattingResult>;
    private getModePrompt;
    private handleFormattingError;
    checkAvailability(): Promise<boolean>;
    getAvailableModels(): string[];
    /**
     * Format text with retry logic and exponential backoff
     */
    formatWithRetry(text: string, mode: Mode, options?: FormattingOptions, maxRetries?: number): Promise<FormattingResult>;
    /**
     * Get formatting statistics for monitoring
     */
    getFormattingStats(): {
        totalRequests: number;
        successRate: number;
        averageProcessingTime: number;
        totalTokensUsed: number;
    };
}
//# sourceMappingURL=FormattingService.d.ts.map