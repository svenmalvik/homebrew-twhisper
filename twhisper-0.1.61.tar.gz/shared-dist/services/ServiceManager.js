import { IServiceManager } from '../interfaces/interfaces.js';
import { RecordingService } from './RecordingService.js';
import { StreamingTranscriptionService } from './streaming/StreamingTranscriptionService.js';
import { FormattingService } from './FormattingService.js';
import { ClipboardService } from './ClipboardService.js';
import { ConfigurationService } from './ConfigurationService.js';
import { debugLog, infoLog } from '../utils/debug.js';
import { FileService } from './FileService.js';
import { SubscriptionService } from './SubscriptionService.js';
import { AppError, ErrorCode } from '../types/index.js';
import { ModeRegistryImpl } from '../types/modes.js';
export class ServiceManager extends IServiceManager {
    constructor() {
        super();
        this.services = null;
        this.isInitialized = false;
        this.modeRegistry = new ModeRegistryImpl();
    }
    async initialize() {
        try {
            debugLog('🚀 Initializing Twhisper CLI services...');
            // Initialize configuration service first
            const configService = new ConfigurationService();
            const config = await configService.load();
            debugLog('✅ Configuration loaded successfully');
            // Initialize file service
            const fileService = new FileService();
            debugLog('✅ File service initialized');
            // Initialize recording service
            const recordingService = new RecordingService();
            debugLog('✅ Recording service initialized');
            // Initialize transcription service - always use StreamingTranscriptionService
            // It handles both streaming mode (local whisper) and batch mode (local or Azure based on config)
            debugLog('🔧 Initializing streaming transcription service...');
            const transcriptionService = new StreamingTranscriptionService(config.azureOpenAI.apiKey, config.azureOpenAI.endpoint, config.azureOpenAI.apiVersion, config.azureOpenAI.whisperDeployment, fileService, config);
            debugLog('✅ Streaming transcription service initialized (handles both streaming and batch modes)');
            // Initialize formatting service
            const formattingService = new FormattingService(config.azureOpenAI.apiKey, config.azureOpenAI.endpoint, config.azureOpenAI.apiVersion, config.azureOpenAI.gptDeployment);
            debugLog('✅ Formatting service initialized');
            // Initialize clipboard service
            const clipboardService = new ClipboardService();
            debugLog('✅ Clipboard service initialized');
            // Initialize subscription service
            const subscriptionService = new SubscriptionService(configService);
            await subscriptionService.initialize();
            debugLog('✅ Subscription service initialized');
            // Set the current mode
            this.modeRegistry.setCurrentMode(config.app.defaultMode);
            debugLog(`✅ Mode registry initialized with default mode: ${config.app.defaultMode}`);
            // Create service container
            this.services = {
                recording: recordingService,
                transcription: transcriptionService,
                formatting: formattingService,
                clipboard: clipboardService,
                configuration: configService,
                file: fileService,
                subscription: subscriptionService,
            };
            // Verify all services are available
            debugLog('🔍 Checking service availability...');
            const healthStatus = await this.healthCheck();
            if (healthStatus.overall === 'unhealthy') {
                throw new AppError('Some critical services are unavailable', ErrorCode.SERVICE_UNAVAILABLE, { healthStatus });
            }
            this.isInitialized = true;
            debugLog('🎉 All services initialized successfully!');
            if (healthStatus.overall === 'degraded') {
                console.warn('⚠️  Some services are degraded but the application can still function');
            }
            return this.services;
        }
        catch (error) {
            // Preserve isFirstRun flag if it exists in the original error
            const details = { error: error instanceof Error ? error.message : 'Unknown error' };
            if (error instanceof AppError && error.details?.isFirstRun) {
                details.isFirstRun = true;
            }
            throw new AppError('Failed to initialize services', ErrorCode.SERVICE_NOT_INITIALIZED, details);
        }
    }
    async shutdown() {
        if (!this.services) {
            return;
        }
        infoLog('🛑 Shutting down services...');
        try {
            // Clean up temporary files
            if (this.services.file) {
                const deletedCount = await this.services.file.cleanupTempFiles();
                debugLog(`🗑️  Cleaned up ${deletedCount} temporary files`);
            }
            // Additional cleanup for recording service if needed
            if (this.services.recording && this.services.recording.getIsRecording()) {
                this.services.recording.cancel();
                debugLog('🎙️  Recording cancelled during shutdown');
            }
            infoLog('✅ Services shut down successfully');
        }
        catch (error) {
            console.error('❌ Error during shutdown:', error);
        }
        this.services = null;
        this.isInitialized = false;
    }
    async healthCheck() {
        if (!this.services) {
            return {
                overall: 'unhealthy',
                services: {
                    manager: {
                        status: 'unhealthy',
                        message: 'Services not initialized',
                        lastCheck: new Date(),
                    },
                },
            };
        }
        const serviceChecks = await Promise.allSettled([
            this.checkRecordingService(),
            this.checkTranscriptionService(),
            this.checkFormattingService(),
            this.checkClipboardService(),
            this.checkFileService(),
        ]);
        const services = {};
        let healthyCount = 0;
        let totalCount = 0;
        serviceChecks.forEach((result, index) => {
            const serviceNames = ['recording', 'transcription', 'formatting', 'clipboard', 'file'];
            const serviceName = serviceNames[index];
            totalCount++;
            if (result.status === 'fulfilled') {
                services[serviceName] = result.value;
                debugLog(`🔍 Health check - ${serviceName}: ${result.value.status} - ${result.value.message}`);
                if (result.value.status === 'healthy') {
                    healthyCount++;
                }
            }
            else {
                services[serviceName] = {
                    status: 'unhealthy',
                    message: result.reason?.message || 'Health check failed',
                    lastCheck: new Date(),
                };
                debugLog(`❌ Health check - ${serviceName}: unhealthy - ${result.reason?.message || 'Health check failed'}`);
            }
        });
        let overall;
        if (healthyCount === totalCount) {
            overall = 'healthy';
        }
        else if (healthyCount > totalCount / 2) {
            overall = 'degraded';
        }
        else {
            overall = 'unhealthy';
        }
        debugLog(`📊 Health summary: ${healthyCount}/${totalCount} services healthy, overall status: ${overall}`);
        return { overall, services };
    }
    async checkRecordingService() {
        try {
            // Test if recording service can initialize (without actually recording)
            const isHealthy = !this.services.recording.getIsRecording(); // Should not be recording initially
            return {
                status: isHealthy ? 'healthy' : 'degraded',
                message: isHealthy ? 'Recording service ready' : 'Recording service busy',
                lastCheck: new Date(),
            };
        }
        catch (error) {
            return {
                status: 'unhealthy',
                message: error instanceof Error ? error.message : 'Recording service check failed',
                lastCheck: new Date(),
            };
        }
    }
    async checkTranscriptionService() {
        try {
            const isAvailable = await this.services.transcription.checkAvailability();
            return {
                status: isAvailable ? 'healthy' : 'unhealthy',
                message: isAvailable ? 'Transcription service ready' : 'Transcription service unavailable',
                lastCheck: new Date(),
            };
        }
        catch (error) {
            return {
                status: 'unhealthy',
                message: error instanceof Error ? error.message : 'Transcription service check failed',
                lastCheck: new Date(),
            };
        }
    }
    async checkFormattingService() {
        try {
            const isAvailable = await this.services.formatting.checkAvailability();
            return {
                status: isAvailable ? 'healthy' : 'unhealthy',
                message: isAvailable ? 'Formatting service ready' : 'Formatting service unavailable',
                lastCheck: new Date(),
            };
        }
        catch (error) {
            return {
                status: 'unhealthy',
                message: error instanceof Error ? error.message : 'Formatting service check failed',
                lastCheck: new Date(),
            };
        }
    }
    async checkClipboardService() {
        try {
            const isAvailable = await this.services.clipboard.isAvailable();
            return {
                status: isAvailable ? 'healthy' : 'degraded',
                message: isAvailable ? 'Clipboard service ready' : 'Clipboard access limited',
                lastCheck: new Date(),
            };
        }
        catch {
            return {
                status: 'degraded',
                message: 'Clipboard service check failed but app can continue',
                lastCheck: new Date(),
            };
        }
    }
    async checkFileService() {
        try {
            // Test file service by checking temp directory access
            const testFile = await this.services.file.createTempFile('test');
            await this.services.file.deleteTempFile(testFile);
            return {
                status: 'healthy',
                message: 'File service ready',
                lastCheck: new Date(),
            };
        }
        catch (error) {
            return {
                status: 'unhealthy',
                message: error instanceof Error ? error.message : 'File service check failed',
                lastCheck: new Date(),
            };
        }
    }
    getServices() {
        if (!this.services || !this.isInitialized) {
            throw new AppError('Services not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        return this.services;
    }
    /**
     * Get the mode registry for managing modes
     */
    getModeRegistry() {
        return this.modeRegistry;
    }
    /**
     * Check if services are initialized
     */
    isReady() {
        return this.isInitialized && this.services !== null;
    }
}
//# sourceMappingURL=ServiceManager.js.map