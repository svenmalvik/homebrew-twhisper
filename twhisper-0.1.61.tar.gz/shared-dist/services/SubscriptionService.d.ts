import { EventEmitter } from 'events';
import { ISubscriptionService, ServiceStatus, SubscriptionStatus, SubscriptionUpgradeResult } from '../interfaces/interfaces.js';
export declare class SubscriptionService extends EventEmitter implements ISubscriptionService {
    readonly name = "SubscriptionService";
    private status;
    private currentUser;
    private configService;
    private supabaseUrl;
    private supabaseKey;
    constructor(configService: {
        getConfiguration(): unknown;
    });
    initialize(): Promise<void>;
    shutdown(): Promise<void>;
    getStatus(): ServiceStatus;
    isHealthy(): Promise<boolean>;
    setCurrentUser(user: {
        id: string;
        email: string;
        name: string;
    } | null): void;
    /**
     * Get current user's subscription status using cached API with fallback
     */
    getSubscriptionStatus(): Promise<SubscriptionStatus>;
    /**
     * Get subscription status from the cached API endpoint
     */
    private getSubscriptionStatusFromAPI;
    /**
     * Direct database query fallback (legacy method)
     */
    private getSubscriptionStatusDirect;
    /**
     * Check if user can use professional features with server-side validation
     */
    canUseProfessionalFeatures(): Promise<boolean>;
    /**
     * Check if user can use streaming mode
     */
    canUseStreamingMode(): Promise<boolean>;
    /**
     * Get maximum recording duration for current user
     */
    getMaxRecordingDuration(): Promise<number>;
    /**
     * Upgrade user to professional tier instantly (no payment required during free period)
     */
    upgradeToProfessionalTier(): Promise<void>;
    /**
     * Generate session token and initiate subscription upgrade flow (for future paid tiers)
     */
    initiateSubscriptionUpgrade(): Promise<string>;
    /**
     * Create customer portal session for subscription management
     */
    openCustomerPortal(): Promise<void>;
    /**
     * Open URL in default browser
     */
    private openBrowser;
    /**
     * Get default starter subscription status
     */
    private getStarterSubscriptionStatus;
    /**
     * Get maximum recording minutes for a tier
     */
    private getMaxRecordingMinutesForTier;
    /**
     * Force refresh subscription status from Stripe API
     */
    refreshSubscriptionStatus(): Promise<SubscriptionStatus>;
    /**
     * Get subscription status with smart cache strategy
     * - For premium feature checks: always check fresh if user is currently free
     * - For display: use cache if recent enough
     */
    getSubscriptionStatusForFeatureCheck(): Promise<SubscriptionStatus>;
    /**
     * Validate subscription before professional feature use with smart refresh
     */
    validateProfessionalFeatureAccess(feature: string): Promise<boolean>;
    /**
     * Handle inactive subscription with appropriate messaging
     */
    private handleInactiveSubscription;
    /**
     * Get user-friendly subscription info for display with cache information
     */
    getSubscriptionDisplayInfo(): Promise<{
        plan: string;
        status: string;
        features: string[];
        nextAction?: string;
        cacheInfo?: string;
    }>;
    /**
     * Upgrade subscription to a specific plan
     */
    upgradeSubscription(plan: string): Promise<SubscriptionUpgradeResult>;
    /**
     * Cancel subscription
     */
    cancelSubscription(): Promise<void>;
}
//# sourceMappingURL=SubscriptionService.d.ts.map