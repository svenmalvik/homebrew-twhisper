export interface SettingsSection {
    id: string;
    title: string;
    description?: string;
    icon?: string;
    order: number;
    fields: SettingsField[];
}
export interface SettingsField {
    key: string;
    label: string;
    description?: string;
    type: FieldType;
    category: SettingsCategory;
    section: string;
    required: boolean;
    secure?: boolean;
    placeholder?: string;
    validation?: FieldValidation;
    options?: FieldOption[];
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    helpText?: string;
}
export type FieldType = 'text' | 'password' | 'number' | 'boolean' | 'select' | 'url' | 'multiline' | 'file' | 'slider';
export declare enum SettingsCategory {
    AZURE_OPENAI = "azureOpenAI",
    APPLICATION = "app",
    AUDIO = "audio",
    UI = "ui",
    SECURITY = "security",
    ADVANCED = "advanced"
}
export interface FieldOption {
    value: string | number | boolean;
    label: string;
    description?: string;
    disabled?: boolean;
}
export interface FieldValidation {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    pattern?: string;
    custom?: (value: unknown) => string | null;
}
export interface FieldState {
    value: unknown;
    isValid: boolean;
    isDirty: boolean;
    error?: string;
    isEditing?: boolean;
    originalValue?: unknown;
}
export interface SettingsState {
    currentSection: string;
    fields: Record<string, FieldState>;
    hasUnsavedChanges: boolean;
    isLoading: boolean;
    isSaving: boolean;
    lastSaved?: Date;
    errors: Record<string, string>;
    warnings: Record<string, string>;
}
export interface SettingsNavigationState {
    currentSection: string;
    sections: SettingsSection[];
    canNavigateAway: boolean;
    hasUnsavedChanges: boolean;
}
export interface SettingsUIProps {
    visible: boolean;
    onClose: () => void;
    onSave: (changes: Record<string, unknown>) => Promise<void>;
    onReset?: () => void;
    initialValues?: Record<string, unknown>;
}
export interface SettingsFieldProps {
    field: SettingsField;
    state: FieldState;
    onValueChange: (key: string, value: unknown) => void;
    onEditStart: (key: string) => void;
    onEditEnd: (key: string, save: boolean) => void;
    disabled?: boolean;
    autoFocus?: boolean;
}
export interface SettingsValidationResult {
    isValid: boolean;
    errors: Record<string, string>;
    warnings: Record<string, string>;
    canSave: boolean;
}
export interface KeyboardNavigationState {
    focusedSection: number;
    focusedField: number;
    isInEditMode: boolean;
    editingField?: string;
}
export interface KeyboardShortcut {
    key: string;
    modifiers?: ('ctrl' | 'alt' | 'shift' | 'meta')[];
    description: string;
    action: () => void;
}
export declare enum SecurityLevel {
    PLAINTEXT = "plaintext",
    ENCRYPTED_FILE = "encrypted_file",
    SYSTEM_KEYCHAIN = "system_keychain",
    MEMORY_ONLY = "memory_only"
}
export interface SecuritySettings {
    credentialStorage: SecurityLevel;
    encryptConfig: boolean;
    sessionOnly: boolean;
    auditLogging: boolean;
    autoLock?: number;
}
export interface SecureConfiguration {
    credentials: Record<string, string>;
    encryptedFields: string[];
    metadata: {
        created: Date;
        modified: Date;
        version: string;
        checksum?: string;
    };
}
export interface ConfigurationExport {
    version: string;
    timestamp: Date;
    settings: Record<string, unknown>;
    excludeSensitive: boolean;
    metadata: {
        appVersion: string;
        platform: string;
        exported: Date;
    };
}
export interface ConfigurationImport {
    data: ConfigurationExport;
    validation: SettingsValidationResult;
    conflicts: string[];
    preview: Record<string, {
        current: unknown;
        imported: unknown;
    }>;
}
export interface SettingsSearchState {
    query: string;
    filters: {
        categories: SettingsCategory[];
        sections: string[];
        types: FieldType[];
        requiresRestart?: boolean;
        hasErrors?: boolean;
    };
    results: SettingsField[];
}
export interface SettingsHelpContent {
    field: string;
    title: string;
    description: string;
    examples?: string[];
    troubleshooting?: string[];
    links?: Array<{
        text: string;
        url: string;
    }>;
}
export interface ConnectionTestResult {
    success: boolean;
    message: string;
    details?: Record<string, unknown>;
    latency?: number;
    timestamp: Date;
}
export interface HealthCheckStatus {
    service: string;
    status: 'healthy' | 'warning' | 'error';
    message: string;
    lastCheck: Date;
    details?: Record<string, unknown>;
}
//# sourceMappingURL=settings.d.ts.map