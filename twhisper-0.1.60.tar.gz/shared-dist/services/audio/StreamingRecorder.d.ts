import { EventEmitter } from 'events';
import { AudioChunk, StreamingOptions } from '../../interfaces/interfaces.js';
export interface StreamingRecorderOptions extends StreamingOptions {
    continuousMode?: boolean;
    adaptiveChunkSize?: boolean;
    qualityMonitoring?: boolean;
    minChunkSize?: number;
    maxChunkSize?: number;
}
export interface AudioQualityMetrics {
    signalStrength: number;
    noiseLevel: number;
    clippingRate: number;
    dynamicRange: number;
    snr: number;
}
export interface StreamingMetrics {
    chunksPerSecond: number;
    averageLatency: number;
    bufferHealth: number;
    qualityScore: number;
    adaptiveAdjustments: number;
}
export interface StreamingStatus {
    isActive: boolean;
    duration: number;
    chunksProcessed: number;
    bytesProcessed: number;
    bufferUtilization: number;
    currentSampleRate: number;
    currentChunkSize: number;
    qualityMetrics: AudioQualityMetrics;
    streamingMetrics: StreamingMetrics;
}
export declare class StreamingRecorder extends EventEmitter {
    private recorder;
    private circularBuffer;
    private isActive;
    private startTime;
    private sequenceId;
    private monitoringInterval;
    private options;
    private qualityMetrics;
    private streamingMetrics;
    private qualityHistory;
    private latencyHistory;
    private lastChunkTime;
    private adaptiveAdjustmentCount;
    private config;
    constructor(options?: StreamingRecorderOptions);
    /**
     * Start streaming audio capture with enhanced capabilities
     */
    start(): Promise<void>;
    /**
     * Stop streaming audio capture
     */
    stop(): Promise<void>;
    /**
     * Get current streaming status
     */
    getStatus(): StreamingStatus;
    /**
     * Get audio buffer for processing
     */
    getAudioBuffer(chunkCount?: number): Buffer;
    /**
     * Get recent audio chunks
     */
    getRecentChunks(count: number): AudioChunk[];
    /**
     * Update streaming options dynamically
     */
    updateOptions(newOptions: Partial<StreamingRecorderOptions>): void;
    /**
     * Handle incoming audio chunk with enhanced processing
     */
    private handleAudioChunk;
    /**
     * Update audio quality metrics
     */
    private updateQualityMetrics;
    /**
     * Update streaming performance metrics
     */
    private updateStreamingMetrics;
    /**
     * Adjust chunk size based on performance metrics
     */
    private adjustChunkSizeIfNeeded;
    /**
     * Convert buffer to 16-bit signed integer samples
     */
    private bufferToSamples;
    /**
     * Start quality monitoring interval
     */
    private startQualityMonitoring;
    /**
     * Generate performance recommendations
     */
    private generateRecommendations;
    /**
     * Generate session summary
     */
    private generateSessionSummary;
    /**
     * Initialize circular buffer
     */
    private initializeCircularBuffer;
    /**
     * Initialize metrics
     */
    private initializeMetrics;
    /**
     * Reset counters
     */
    private resetCounters;
    /**
     * Get streaming duration in seconds
     */
    private getDuration;
    /**
     * Handle errors
     */
    private handleError;
    /**
     * Clean up resources
     */
    private cleanup;
}
//# sourceMappingURL=StreamingRecorder.d.ts.map