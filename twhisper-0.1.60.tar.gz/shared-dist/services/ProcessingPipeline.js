import { EventEmitter } from 'events';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { spawn } from 'child_process';
import { promisify } from 'util';
import { ProcessingMode } from '../interfaces/interfaces.js';
import { AppState, AppError, ErrorCode } from '../types/index.js';
import { debugLog as utilDebugLog } from '../utils/debug.js';
import { AuthenticationService } from './AuthenticationService.js';
// Override console methods to also log to file
const originalConsoleLog = console.log;
const originalConsoleWarn = console.warn;
const originalConsoleError = console.error;
function setupGlobalLogging() {
    console.log = (...args) => {
        const timestamp = new Date().toLocaleString('en-GB', {
            timeZone: 'Europe/Oslo',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });
        const message = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ');
        const logMessage = `[${timestamp}] [LOG] ${message}\n`;
        try {
            const logPath = path.join(process.cwd(), 'debug-streaming.log');
            fs.appendFileSync(logPath, logMessage);
        }
        catch {
            // Ignore file errors
        }
        // Call original console.log only if stdout is writable
        try {
            if (process.stdout && process.stdout.writable && !process.stdout.destroyed) {
                originalConsoleLog(...args);
            }
        }
        catch (error) {
            // Ignore EPIPE and other stream errors during shutdown
        }
    };
    console.warn = (...args) => {
        const timestamp = new Date().toLocaleString('en-GB', {
            timeZone: 'Europe/Oslo',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });
        const message = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ');
        const logMessage = `[${timestamp}] [WARN] ${message}\n`;
        try {
            const logPath = path.join(process.cwd(), 'debug-streaming.log');
            fs.appendFileSync(logPath, logMessage);
        }
        catch {
            // Ignore file errors
        }
        // Call original console.warn only if stderr is writable
        try {
            if (process.stderr && process.stderr.writable && !process.stderr.destroyed) {
                originalConsoleWarn(...args);
            }
        }
        catch (error) {
            // Ignore EPIPE and other stream errors during shutdown
        }
    };
    console.error = (...args) => {
        const timestamp = new Date().toLocaleString('en-GB', {
            timeZone: 'Europe/Oslo',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });
        const message = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ');
        const logMessage = `[${timestamp}] [ERROR] ${message}\n`;
        try {
            const logPath = path.join(process.cwd(), 'debug-streaming.log');
            fs.appendFileSync(logPath, logMessage);
        }
        catch {
            // Ignore file errors
        }
        // Call original console.error only if stderr is writable
        try {
            if (process.stderr && process.stderr.writable && !process.stderr.destroyed) {
                originalConsoleError(...args);
            }
        }
        catch (error) {
            // Ignore EPIPE and other stream errors during shutdown
        }
    };
}
export class ProcessingPipeline extends EventEmitter {
    constructor(services, modeRegistry) {
        super();
        this.currentState = AppState.IDLE;
        this.currentRecording = null;
        this.isProcessing = false;
        // Dual-mode operation properties
        this.currentProcessingMode = ProcessingMode.BATCH;
        this.streamingSessions = new Map();
        this.currentStreamingSessionId = null;
        this.isModeSwitching = false;
        // Streaming chunk batching for better context (no rate limits with local Whisper!)
        this.chunkBatchSize = 1; // Process immediately since we're using 10-second chunks
        this.chunkBuffer = new Map(); // Buffer chunks per session
        // Circuit breaker state for error handling
        this.circuitBreakerState = 'CLOSED';
        this.consecutiveFailures = 0;
        this.lastFailureTime = 0;
        this.FAILURE_THRESHOLD = 3;
        this.CIRCUIT_TIMEOUT = 10000; // 10 seconds
        this.BACKOFF_DELAY = 2000; // 2 seconds between retries
        // Session cancellation tracking
        this.cancelledSessions = new Set();
        // Cache authentication and subscription checks to reduce startup delay
        this.authCache = null;
        this.subscriptionCache = null;
        this.CACHE_TTL_MS = 30000; // 30 seconds cache for recording limits
        this.SUBSCRIPTION_CACHE_TTL_MS = 86400000; // 24 hours for subscription features
        // Set up global logging to capture all console output
        setupGlobalLogging();
        utilDebugLog('📝 [ProcessingPipeline] Global logging initialized - all console output will be saved to debug-streaming.log');
        this.services = services;
        this.modeRegistry = modeRegistry;
        // Set initial processing mode from configuration
        const config = services.configuration.getConfiguration();
        if (config) {
            this.currentProcessingMode = config.app.defaultProcessingMode;
            utilDebugLog(`🔧 [ProcessingPipeline] Setting default processing mode to: ${this.currentProcessingMode}`);
            // Also update recording service mode to stay in sync
            if ('setProcessingMode' in this.services.recording) {
                const enhancedRecording = this.services.recording;
                // Note: setProcessingMode is async, but we can't await in constructor
                // This will be handled synchronously during service initialization
                enhancedRecording.setProcessingMode(this.currentProcessingMode).catch(error => {
                    utilDebugLog(`⚠️ [ProcessingPipeline] Failed to sync recording service mode during initialization: ${error.message}`);
                });
            }
        }
        this.setupEventListeners();
    }
    /**
     * Initialize the pipeline and check initial processing mode requirements
     */
    async initialize() {
        utilDebugLog('🔧 [ProcessingPipeline] Initializing pipeline...');
        // Validate and enforce language permissions on startup
        await this.validateAndEnforceLanguagePermissions();
        // If we start in streaming mode, ensure requirements are met
        if (this.currentProcessingMode === ProcessingMode.STREAMING) {
            utilDebugLog('🔍 [ProcessingPipeline] App started in streaming mode - checking requirements...');
            try {
                await this.checkStreamingRequirements();
            }
            catch {
                utilDebugLog('⚠️ [ProcessingPipeline] Streaming requirements check failed - switching to batch mode');
                this.currentProcessingMode = ProcessingMode.BATCH;
            }
        }
    }
    setupEventListeners() {
        // Recording service events (batch mode)
        this.services.recording.on('audioData', ({ level }) => {
            this.emit('audio:level', level);
        });
        this.services.recording.on('recordingStopped', ({ audioData }) => {
            if (this.currentProcessingMode === ProcessingMode.BATCH) {
                this.currentRecording = audioData;
                this.emit('recording:stopped', audioData);
                this.processRecording(audioData);
            }
        });
        this.services.recording.on('recordingCancelled', () => {
            this.currentRecording = null;
            this.setState(AppState.IDLE);
            this.emit('recording:cancelled');
        });
        this.services.recording.on('error', (error) => {
            this.handleError(new AppError('Recording failed', ErrorCode.RECORDING_ERROR, { originalError: error.message }));
        });
        // Handle maximum duration reached
        this.services.recording.on('maxDurationReached', async () => {
            const config = this.services.configuration.getConfiguration();
            // Check if user is authenticated to determine max duration
            let maxDuration = 60; // Default 1 minute for non-authenticated users
            if (config?.auth.enabled) {
                try {
                    const { AuthenticationService } = await import('./AuthenticationService.js');
                    const authService = new AuthenticationService(this.services.configuration);
                    const isAuthenticated = await authService.isAuthenticated();
                    if (isAuthenticated) {
                        maxDuration = 300; // 5 minutes for authenticated users
                    }
                }
                catch (error) {
                    // If auth check fails, default to 1 minute
                    console.warn('Failed to check authentication status for recording limit:', error);
                }
            }
            this.handleError(new AppError(`Recording stopped: Maximum duration of ${maxDuration} seconds reached`, ErrorCode.RECORDING_ERROR, { reason: 'max_duration_exceeded', maxDuration }));
        });
        // Streaming recording events
        utilDebugLog('🔍 [ProcessingPipeline] Setting up streaming event listeners...');
        const enhancedRecording = this.services.recording;
        // Listen for streamingData event from RecordingService
        enhancedRecording.on('streamingData', (chunk) => {
            utilDebugLog('📦 [ProcessingPipeline] Received streamingData event, chunk:', chunk.sequenceId);
            this.handleStreamingChunk(chunk);
        });
        enhancedRecording.on('streaming:chunk', (data) => {
            this.handleStreamingChunk(data.chunk);
        });
        enhancedRecording.on('streamingStarted', () => {
            utilDebugLog('📡 [ProcessingPipeline] Received streamingStarted event');
            this.setState(AppState.STREAMING);
        });
        enhancedRecording.on('streamingStopped', () => {
            utilDebugLog('📡 [ProcessingPipeline] Received streamingStopped event');
            this.handleStreamingStopped();
        });
        // Transcription service events (batch mode)
        this.services.transcription.on('transcription:started', () => {
            this.emit('transcription:started');
        });
        this.services.transcription.on('transcription:progress', (progress) => {
            this.emit('transcription:progress', progress);
        });
        this.services.transcription.on('transcription:error', (error) => {
            this.handleError(error);
        });
        // Streaming transcription events
        if ('streaming:partial:result' in this.services.transcription) {
            const streamingTranscription = this.services.transcription;
            streamingTranscription.on('streaming:partial:result', (data) => {
                this.emit('streaming:partial:result', data);
            });
            streamingTranscription.on('streaming:progressive:update', (data) => {
                this.emit('streaming:progressive:update', data);
            });
            streamingTranscription.on('streaming:session:ended', (data) => {
                this.emit('streaming:session:ended', data);
            });
        }
        // Formatting service events
        this.services.formatting.on('formatting:started', () => {
            this.emit('formatting:started');
        });
        this.services.formatting.on('formatting:progress', (progress) => {
            this.emit('formatting:progress', progress);
        });
        this.services.formatting.on('formatting:error', (error) => {
            this.handleError(error);
        });
    }
    /**
     * Start recording audio
     */
    async startRecording() {
        if (this.isProcessing || this.currentState !== AppState.IDLE) {
            throw new AppError('Cannot start recording while processing', ErrorCode.INVALID_INPUT);
        }
        try {
            this.setState(AppState.RECORDING);
            // Use cached recording limits to avoid startup delay
            const maxDuration = await this.getCachedMaxDuration();
            const minDuration = 1; // Hardcoded to 1 second minimum
            await this.services.recording.start({
                maxDuration,
                minDuration
            });
            this.emit('recording:started');
        }
        catch (error) {
            this.setState(AppState.ERROR);
            throw new AppError('Failed to start recording', ErrorCode.RECORDING_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Stop recording audio
     */
    async stopRecording() {
        if (this.currentState !== AppState.RECORDING) {
            throw new AppError('Not currently recording', ErrorCode.INVALID_INPUT);
        }
        try {
            const audioData = this.services.recording.stop();
            return audioData;
        }
        catch (error) {
            this.setState(AppState.ERROR);
            throw new AppError('Failed to stop recording', ErrorCode.RECORDING_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Cancel current recording
     */
    cancelRecording() {
        if (this.currentState === AppState.RECORDING) {
            this.services.recording.cancel();
        }
    }
    /**
     * Process recorded audio through the complete pipeline
     */
    async processRecording(audioData) {
        if (this.isProcessing) {
            console.warn('Already processing, ignoring new recording');
            return;
        }
        this.isProcessing = true;
        const startTime = Date.now();
        try {
            // Validate recording before processing
            this.validateRecording(audioData);
            // Step 1: Transcription
            this.setState(AppState.TRANSCRIBING);
            const transcriptionResult = await this.services.transcription.transcribeWithRetry(audioData, {
                temperature: 0,
            });
            this.emit('transcription:completed', transcriptionResult.text);
            // Step 2: Formatting
            this.setState(AppState.FORMATTING);
            // Get current mode with localization based on whisper language
            const currentConfig = this.services.configuration.getConfiguration();
            const currentLanguage = currentConfig?.whisper?.language || 'en';
            const currentModeId = this.modeRegistry.currentMode;
            const currentMode = this.modeRegistry.getModeWithLocalization(currentModeId, currentLanguage);
            if (!currentMode) {
                throw new AppError('No active mode selected', ErrorCode.CONFIGURATION_ERROR);
            }
            const formattingResult = await this.services.formatting.formatWithRetry(transcriptionResult.text, currentMode, {
                maxTokens: currentMode.settings?.maxTokens || 1000,
                temperature: currentMode.settings?.temperature || 0.3,
            });
            this.emit('formatting:completed', formattingResult.formattedText);
            // Step 3: Clipboard copy
            const config = this.services.configuration.getConfiguration();
            if (config?.app.autoCopy) {
                try {
                    const clipboardResult = await this.services.clipboard.writeWithConfirmation(formattingResult.formattedText);
                    this.emit('clipboard:copied', clipboardResult);
                }
                catch (error) {
                    // Clipboard failure shouldn't stop the pipeline
                    console.warn('Clipboard copy failed:', error);
                    this.emit('clipboard:copied', {
                        success: false,
                        wordCount: formattingResult.formattedText.split(/\s+/).length,
                        preview: formattingResult.formattedText.substring(0, 100)
                    });
                }
            }
            // Step 4: Complete
            const totalDuration = Date.now() - startTime;
            const result = {
                transcription: transcriptionResult.text,
                formattedText: formattingResult.formattedText,
                mode: currentMode.name,
                duration: totalDuration,
                timestamp: new Date(),
                success: true,
                wordCount: transcriptionResult.wordCount,
            };
            this.setState(AppState.COMPLETE);
            this.emit('pipeline:completed', result);
            // Auto-reset to idle after a short delay
            setTimeout(() => {
                if (this.currentState === AppState.COMPLETE) {
                    this.setState(AppState.IDLE);
                }
            }, 2000);
        }
        catch (error) {
            this.handleError(error instanceof AppError ? error : new AppError('Pipeline processing failed', ErrorCode.UNKNOWN_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' }));
        }
        finally {
            this.isProcessing = false;
        }
    }
    /**
     * Cycle to the next formatting mode
     */
    cycleMode() {
        const nextMode = this.modeRegistry.cycleToNextMode();
        if (nextMode) {
            // Persist the formatting mode change to config file using ID (config key) not display name
            if (nextMode.id) {
                this.services.configuration.persistMode(nextMode.id).catch(error => {
                    utilDebugLog(`⚠️ [ProcessingPipeline] Failed to persist formatting mode change: ${error instanceof Error ? error.message : 'Unknown error'}`);
                });
            }
            return nextMode.name;
        }
        return null;
    }
    /**
     * Get current mode name
     */
    getCurrentMode() {
        const currentMode = this.modeRegistry.getCurrentMode();
        return currentMode ? currentMode.name : null;
    }
    /**
     * Get all available mode names
     */
    getAvailableModes() {
        return this.modeRegistry.getActiveModes().map(mode => mode.name);
    }
    // === DUAL-MODE OPERATION METHODS ===
    /**
     * Set processing mode (batch or streaming)
     */
    async setProcessingMode(mode) {
        if (this.isModeSwitching) {
            throw new AppError('Mode switch already in progress', ErrorCode.INVALID_INPUT, { currentMode: this.currentProcessingMode, targetMode: mode });
        }
        if (this.currentProcessingMode === mode) {
            return; // Already in the requested mode
        }
        this.isModeSwitching = true;
        const previousMode = this.currentProcessingMode;
        try {
            this.emit('mode:switch:started', mode);
            // Check streaming requirements before switching
            if (mode === ProcessingMode.STREAMING) {
                await this.checkStreamingRequirements();
            }
            // Stop any active operations before switching modes
            await this.prepareForModeSwitch();
            // Update recording service mode if it supports enhanced features
            if ('setProcessingMode' in this.services.recording) {
                const enhancedRecording = this.services.recording;
                await enhancedRecording.setProcessingMode(mode);
            }
            this.currentProcessingMode = mode;
            // Persist the mode change to config file
            try {
                await this.services.configuration.persistProcessingMode(mode);
            }
            catch (error) {
                // Log the error but don't fail the mode switch - the mode has already been changed
                utilDebugLog(`⚠️ [ProcessingPipeline] Failed to persist processing mode change: ${error instanceof Error ? error.message : 'Unknown error'}`);
            }
            this.emit('mode:changed', { from: previousMode, to: mode });
            this.emit('mode:switch:completed', mode);
        }
        catch (error) {
            const appError = error instanceof AppError ? error : new AppError('Failed to switch processing mode', ErrorCode.CONFIGURATION_ERROR, { error: error instanceof Error ? error.message : 'Unknown error', previousMode, targetMode: mode });
            this.emit('mode:switch:failed', appError);
            throw appError;
        }
        finally {
            this.isModeSwitching = false;
        }
    }
    /**
     * Get current processing mode
     */
    getCurrentProcessingMode() {
        return this.currentProcessingMode;
    }
    /**
     * Start streaming session
     */
    async startStreamingSession(options = {}) {
        if (this.currentProcessingMode !== ProcessingMode.STREAMING) {
            throw new AppError('Cannot start streaming session in batch mode', ErrorCode.INVALID_INPUT, { currentMode: this.currentProcessingMode });
        }
        if (this.currentState !== AppState.IDLE) {
            throw new AppError('Cannot start streaming session while not idle', ErrorCode.INVALID_INPUT, { currentState: this.currentState });
        }
        try {
            utilDebugLog('🎯 [ProcessingPipeline] Starting streaming session...');
            // Ensure streaming requirements are met before starting session
            utilDebugLog('🔍 [ProcessingPipeline] About to check streaming requirements...');
            await this.checkStreamingRequirements();
            utilDebugLog('✅ [ProcessingPipeline] Streaming requirements check completed successfully');
            // Start streaming transcription session
            const streamingTranscription = this.services.transcription;
            const transcriptionSessionId = await streamingTranscription.startStreamingSession(options);
            utilDebugLog('✅ [ProcessingPipeline] Transcription session started:', transcriptionSessionId);
            // Create pipeline streaming session
            const sessionId = `pipeline_${Date.now()}`;
            const session = {
                sessionId,
                startTime: Date.now(),
                isActive: true,
                isPaused: false,
                transcriptionSessionId,
                accumulatedText: '',
                chunkCount: 0,
                lastActivity: Date.now(),
                options
            };
            this.streamingSessions.set(sessionId, session);
            this.currentStreamingSessionId = sessionId;
            // Start streaming recording - convert transcription options to streaming options
            if ('startStreaming' in this.services.recording) {
                const enhancedRecording = this.services.recording;
                const streamingOptions = {
                    bufferDuration: options.contextWindow ? options.contextWindow * 2 : 10, // Convert context window to buffer duration
                    chunkSize: 1024, // Default chunk size
                    overlapDuration: 0.5 // Default overlap
                };
                await enhancedRecording.startStreaming(streamingOptions);
            }
            this.setState(AppState.STREAMING);
            this.emit('streaming:started', sessionId);
            return sessionId;
        }
        catch (error) {
            throw new AppError('Failed to start streaming session', ErrorCode.STREAMING_CONTEXT_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Stop streaming session
     */
    async stopStreamingSession(sessionId) {
        const session = this.streamingSessions.get(sessionId);
        if (!session || !session.isActive) {
            throw new AppError(`Streaming session not found or inactive: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        try {
            // Stop streaming recording first (this may emit final/partial chunks)
            if ('stopStreaming' in this.services.recording) {
                const enhancedRecording = this.services.recording;
                await enhancedRecording.stopStreaming();
            }
            // Process any remaining buffered chunks immediately
            const bufferedChunks = this.chunkBuffer.get(sessionId);
            if (bufferedChunks && bufferedChunks.length > 0) {
                utilDebugLog(`📦 Processing ${bufferedChunks.length} remaining buffered chunks before ending session`);
                await this.processBatchedChunks(bufferedChunks, sessionId);
                this.chunkBuffer.set(sessionId, []); // Clear buffer
                // Wait for transcription to complete
                await new Promise(resolve => setTimeout(resolve, 500));
            }
            // Now mark session as cancelled to prevent further processing
            this.cancelledSessions.add(sessionId);
            utilDebugLog('🚫 [ProcessingPipeline] Marked session as cancelled:', sessionId);
            // End transcription session and get final result
            utilDebugLog('🛑 [ProcessingPipeline] Ending streaming session:', sessionId);
            utilDebugLog('📊 [ProcessingPipeline] Session stats - chunks:', session.chunkCount, 'accumulated:', session.accumulatedText?.substring(0, 100) || '(empty)');
            const streamingTranscription = this.services.transcription;
            const transcriptionResult = await streamingTranscription.endStreamingSession(session.transcriptionSessionId);
            utilDebugLog('📋 [ProcessingPipeline] Final transcription result:', transcriptionResult.text);
            // Format the transcription with GPT (just like batch mode does)
            let formattedText = transcriptionResult.text;
            if (transcriptionResult.text && transcriptionResult.text.trim().length > 0) {
                try {
                    this.emit('formatting:started');
                    // Get current mode with localization based on whisper language
                    const streamingConfig = this.services.configuration.getConfiguration();
                    const streamingLanguage = streamingConfig?.whisper?.language || 'en';
                    const streamingModeId = this.modeRegistry.currentMode;
                    const currentMode = this.modeRegistry.getModeWithLocalization(streamingModeId, streamingLanguage);
                    if (!currentMode) {
                        throw new Error('No mode selected');
                    }
                    const formattingResult = await this.services.formatting.format(transcriptionResult.text, currentMode, {} // Use default formatting options
                    );
                    formattedText = formattingResult.formattedText;
                    this.emit('formatting:completed', formattedText);
                }
                catch {
                    // Fall back to raw transcription if formatting fails
                }
            }
            const totalDuration = Date.now() - session.startTime;
            const result = {
                transcription: transcriptionResult.text,
                formattedText: formattedText, // Now properly formatted with GPT
                mode: this.getCurrentMode() || 'default',
                duration: totalDuration,
                timestamp: new Date(),
                success: true,
                wordCount: transcriptionResult.wordCount || 0,
            };
            // Copy to clipboard if auto-copy is enabled
            const config = this.services.configuration.getConfiguration();
            utilDebugLog('📋 [ProcessingPipeline] Auto-copy enabled:', config?.app.autoCopy, 'Text length:', formattedText?.length);
            if (config?.app.autoCopy && formattedText) {
                try {
                    utilDebugLog('📋 [ProcessingPipeline] Copying formatted text to clipboard:', formattedText);
                    const clipboardResult = await this.services.clipboard.writeWithConfirmation(formattedText // Use formatted text instead of raw transcription
                    );
                    utilDebugLog('✅ [ProcessingPipeline] Clipboard copy result:', clipboardResult);
                    this.emit('clipboard:copied', clipboardResult);
                }
                catch {
                    // Clipboard failure shouldn't stop the pipeline
                }
            }
            // Mark session as inactive and clean up
            session.isActive = false;
            this.streamingSessions.delete(sessionId);
            this.cancelledSessions.delete(sessionId); // Clean up cancellation tracking
            if (this.currentStreamingSessionId === sessionId) {
                this.currentStreamingSessionId = null;
            }
            this.setState(AppState.COMPLETE);
            this.emit('streaming:stopped', sessionId, result);
            // Auto-reset to idle after delay
            setTimeout(() => {
                if (this.currentState === AppState.COMPLETE) {
                    this.setState(AppState.IDLE);
                }
            }, 2000);
            return result;
        }
        catch (error) {
            const appError = new AppError('Failed to stop streaming session', ErrorCode.STREAMING_CONTEXT_ERROR, { sessionId, error: error instanceof Error ? error.message : 'Unknown error' });
            this.emit('streaming:error', { sessionId, error: appError });
            throw appError;
        }
    }
    /**
     * Stop the current active streaming session
     */
    async stopCurrentStreamingSession() {
        if (!this.currentStreamingSessionId) {
            return null; // No active session
        }
        // Check if session still exists before stopping (race condition protection)
        const session = this.streamingSessions.get(this.currentStreamingSessionId);
        if (!session || !session.isActive) {
            // Session already stopped/deleted, clean up the reference
            this.currentStreamingSessionId = null;
            return null;
        }
        // Provide immediate UI feedback that stopping is in progress
        this.setState(AppState.STREAMING_STOPPING);
        this.emit('streaming:stopping');
        // Remove artificial delay - let natural processing time determine duration
        return await this.stopStreamingSession(this.currentStreamingSessionId);
    }
    // === STREAMING CHUNK PROCESSING WORKFLOW ===
    /**
     * Process individual audio chunk (streaming mode)
     */
    async processAudioChunk(chunk, sessionId) {
        const session = this.streamingSessions.get(sessionId);
        if (!session || !session.isActive) {
            throw new AppError(`Streaming session not found or inactive: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        try {
            this.setState(AppState.PROCESSING_CHUNK);
            this.emit('streaming:chunk:received', { sessionId, chunk });
            // Process chunk through streaming transcription service
            const streamingTranscription = this.services.transcription;
            const results = await streamingTranscription.processChunkSequence([chunk], session.transcriptionSessionId);
            const result = results[0];
            // Debug: Log chunk processing result
            if (chunk.sequenceId % 10 === 0) { // Log every 10th chunk to reduce noise
                utilDebugLog(`📋 Chunk ${chunk.sequenceId} result:`, result.text?.substring(0, 50) || '(empty)');
            }
            // Update session statistics
            session.chunkCount++;
            session.lastActivity = Date.now();
            if (result.text && result.text.trim()) {
                session.accumulatedText += (session.accumulatedText ? ' ' : '') + result.text.trim();
            }
            this.emit('streaming:chunk:processed', { sessionId, result });
            // Check buffer status and emit warning if needed
            this.checkBufferStatus(sessionId);
            return result;
        }
        catch (error) {
            const appError = new AppError('Failed to process audio chunk', ErrorCode.STREAMING_CONTEXT_ERROR, { sessionId, chunkId: chunk.sequenceId, error: error instanceof Error ? error.message : 'Unknown error' });
            this.emit('streaming:error', { sessionId, error: appError });
            throw appError;
        }
        finally {
            // Return to streaming state after chunk processing, unless we're in the stopping process
            if (this.currentState === AppState.PROCESSING_CHUNK) {
                this.setState(AppState.STREAMING);
            }
            // Note: If we're in STREAMING_STOPPING, don't change state - let the stop process complete
        }
    }
    /**
     * Pause streaming session
     */
    async pauseStreamingSession(sessionId) {
        const session = this.streamingSessions.get(sessionId);
        if (!session || !session.isActive) {
            throw new AppError(`Streaming session not found or inactive: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        if (session.isPaused) {
            return; // Already paused
        }
        session.isPaused = true;
        this.setState(AppState.STREAMING_PAUSED);
        this.emit('streaming:paused', sessionId);
    }
    /**
     * Resume streaming session
     */
    async resumeStreamingSession(sessionId) {
        const session = this.streamingSessions.get(sessionId);
        if (!session || !session.isActive) {
            throw new AppError(`Streaming session not found or inactive: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        if (!session.isPaused) {
            return; // Already active
        }
        session.isPaused = false;
        session.lastActivity = Date.now();
        this.setState(AppState.STREAMING);
        this.emit('streaming:resumed', sessionId);
    }
    // === HELPER METHODS ===
    /**
     * Handle streaming chunk from recording service
     */
    async handleStreamingChunk(chunk) {
        // Find active streaming sessions and buffer chunk for each
        for (const [sessionId, session] of this.streamingSessions.entries()) {
            // Skip cancelled sessions
            if (this.cancelledSessions.has(sessionId)) {
                continue;
            }
            if (session.isActive && !session.isPaused) {
                try {
                    // Buffer chunk
                    if (!this.chunkBuffer.has(sessionId)) {
                        this.chunkBuffer.set(sessionId, []);
                    }
                    this.chunkBuffer.get(sessionId).push(chunk);
                    // Process batch when we have enough chunks (no rate limits with local Whisper!)
                    const bufferedChunks = this.chunkBuffer.get(sessionId);
                    if (bufferedChunks.length >= this.chunkBatchSize && this.shouldAllowProcessing()) {
                        utilDebugLog(`📦 Processing batch for session ${sessionId}: ${bufferedChunks.length} chunks`);
                        await this.processBatchedChunks(bufferedChunks, sessionId);
                        this.chunkBuffer.set(sessionId, []); // Clear buffer after processing
                    }
                    else if (bufferedChunks.length >= this.chunkBatchSize) {
                        utilDebugLog(`🚫 Circuit breaker preventing batch processing for session ${sessionId}`);
                    }
                }
                catch (error) {
                    utilDebugLog(`❌ Failed to process chunk for session ${sessionId}:`, error);
                    await this.handleStreamingError(error, sessionId);
                }
            }
        }
    }
    /**
     * Process multiple chunks as a batch to reduce API calls
     */
    async processBatchedChunks(chunks, sessionId) {
        // Check if session was cancelled before processing
        if (this.cancelledSessions.has(sessionId)) {
            utilDebugLog(`🚫 Skipping batch processing for cancelled session ${sessionId}`);
            return;
        }
        const session = this.streamingSessions.get(sessionId);
        if (!session || !session.isActive) {
            return;
        }
        // Check circuit breaker before processing
        if (!this.shouldAllowProcessing()) {
            utilDebugLog(`🚫 Circuit breaker preventing processing for session ${sessionId}`);
            return;
        }
        // No rate limiting needed with local Whisper - process immediately!
        try {
            // Only change state to PROCESSING_CHUNK if we're not in the stopping process
            // During stopping, we want to keep showing the "Stopping streaming..." message
            if (this.currentState !== AppState.STREAMING_STOPPING) {
                this.setState(AppState.PROCESSING_CHUNK);
            }
            // Process chunks as a batch through streaming transcription service
            const streamingTranscription = this.services.transcription;
            const results = await streamingTranscription.processChunkSequence(chunks, session.transcriptionSessionId);
            // Update session statistics for all chunks in batch
            session.chunkCount += chunks.length;
            session.lastActivity = Date.now();
            // Accumulate text from all results
            for (const result of results) {
                if (result.text && result.text.trim()) {
                    session.accumulatedText += (session.accumulatedText ? ' ' : '') + result.text.trim();
                }
            }
            // Emit events for the last (most recent) result
            const latestResult = results[results.length - 1];
            if (latestResult) {
                this.emit('streaming:chunk:processed', { sessionId, result: latestResult });
            }
            // Log batch processing result (less frequent than individual chunks)
            utilDebugLog(`📦 Batch processed ${chunks.length} chunks for session ${sessionId}, latest result:`, latestResult?.text?.substring(0, 50) || '(empty)');
            // Check buffer status
            this.checkBufferStatus(sessionId);
            // Reset circuit breaker on successful processing
            this.onProcessingSuccess();
        }
        catch (error) {
            utilDebugLog(`❌ Failed to process batch for session ${sessionId}:`, error);
            await this.handleStreamingError(error, sessionId);
        }
    }
    /**
     * Handle streaming stopped event
     */
    async handleStreamingStopped() {
        // Get active sessions before processing
        const activeSessionIds = Array.from(this.streamingSessions.keys()).filter(sessionId => this.streamingSessions.get(sessionId)?.isActive);
        // Process remaining chunks and stop sessions in correct order
        for (const sessionId of activeSessionIds) {
            try {
                const session = this.streamingSessions.get(sessionId);
                if (!session || !session.isActive) {
                    continue; // Skip if session is already inactive
                }
                // Process any remaining buffered chunks BEFORE ending the transcription session (unless cancelled)
                const remainingChunks = this.chunkBuffer.get(sessionId);
                if (remainingChunks && remainingChunks.length > 0) {
                    if (this.cancelledSessions.has(sessionId)) {
                        utilDebugLog(`🚫 Skipping ${remainingChunks.length} remaining chunks for cancelled session ${sessionId}`);
                    }
                    else {
                        utilDebugLog(`📦 Processing ${remainingChunks.length} remaining chunks for session ${sessionId}`);
                        // Process chunks directly through streaming service while session is still active
                        try {
                            const streamingTranscription = this.services.transcription;
                            const results = await streamingTranscription.processChunkSequence(remainingChunks, session.transcriptionSessionId);
                            // Update session with results
                            session.chunkCount += remainingChunks.length;
                            session.lastActivity = Date.now();
                            // Accumulate text from results
                            for (const result of results) {
                                if (result.text && result.text.trim()) {
                                    session.accumulatedText += (session.accumulatedText ? ' ' : '') + result.text.trim();
                                }
                            }
                            utilDebugLog(`📋 Processed ${results.length} remaining chunk results`);
                        }
                        catch (error) {
                            utilDebugLog(`❌ Failed to process remaining chunks for session ${sessionId}:`, error);
                        }
                    }
                    this.chunkBuffer.delete(sessionId);
                }
                // Now stop the session - check if it still exists first (race condition protection)
                const currentSession = this.streamingSessions.get(sessionId);
                if (currentSession && currentSession.isActive) {
                    await this.stopStreamingSession(sessionId);
                }
                else {
                    utilDebugLog(`⚠️ Session ${sessionId} already stopped, skipping`);
                }
            }
            catch (error) {
                utilDebugLog(`❌ Failed to stop streaming session ${sessionId}:`, error);
            }
        }
        this.setState(AppState.IDLE);
    }
    /**
     * Prepare for mode switch by stopping active operations
     */
    async prepareForModeSwitch() {
        // Stop any active recordings
        if (this.currentState === AppState.RECORDING) {
            this.cancelRecording();
        }
        // Stop active streaming sessions
        const activeStreamingSessions = Array.from(this.streamingSessions.keys()).filter(sessionId => this.streamingSessions.get(sessionId)?.isActive);
        for (const sessionId of activeStreamingSessions) {
            try {
                // Check if session still exists before stopping (race condition protection)
                const session = this.streamingSessions.get(sessionId);
                if (session && session.isActive) {
                    await this.stopStreamingSession(sessionId);
                }
            }
            catch (error) {
                console.error(`Failed to stop streaming session during mode switch: ${sessionId}`, error);
            }
        }
        // Wait for any processing to complete
        let attempts = 0;
        const maxAttempts = 10;
        while (this.isProcessing && attempts < maxAttempts) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
        // Force reset if still processing
        if (this.isProcessing) {
            this.isProcessing = false;
            console.warn('Forced reset of processing state during mode switch');
        }
        this.setState(AppState.IDLE);
    }
    /**
     * Check buffer status and emit warnings
     */
    checkBufferStatus(sessionId) {
        if ('getBufferStatus' in this.services.recording) {
            const enhancedRecording = this.services.recording;
            const bufferStatus = enhancedRecording.getBufferStatus();
            this.emit('streaming:buffer:status', {
                sessionId,
                utilization: bufferStatus.utilization,
                overflowCount: bufferStatus.overflowCount
            });
            // Warn if buffer utilization is high
            if (bufferStatus.utilization > 0.8) {
                console.warn(`High buffer utilization for session ${sessionId}: ${Math.round(bufferStatus.utilization * 100)}%`);
            }
            // Warn about buffer overflows
            if (bufferStatus.overflowCount > 0) {
                console.warn(`Buffer overflow detected for session ${sessionId}: ${bufferStatus.overflowCount} overflows`);
            }
        }
    }
    /**
     * Handle streaming errors with circuit breaker pattern
     */
    async handleStreamingError(error, sessionId) {
        this.consecutiveFailures++;
        this.lastFailureTime = Date.now();
        // Check if we should open the circuit breaker
        if (this.consecutiveFailures >= this.FAILURE_THRESHOLD) {
            this.circuitBreakerState = 'OPEN';
            utilDebugLog(`🚨 Circuit breaker opened after ${this.consecutiveFailures} consecutive failures`);
            // Pause streaming session to prevent further cascading errors
            try {
                const session = this.streamingSessions.get(sessionId);
                if (session && session.isActive && !session.isPaused) {
                    session.isPaused = true;
                    this.emit('streaming:paused', sessionId);
                    utilDebugLog(`⏸️ Streaming session ${sessionId} paused due to circuit breaker`);
                }
            }
            catch (pauseError) {
                utilDebugLog(`❌ Failed to pause session ${sessionId}:`, pauseError);
            }
            // Schedule circuit breaker reset
            setTimeout(() => {
                this.circuitBreakerState = 'HALF_OPEN';
                this.consecutiveFailures = 0;
                utilDebugLog(`🔄 Circuit breaker moved to HALF_OPEN state, will attempt to resume`);
                // Try to resume the paused session (if not cancelled)
                setTimeout(async () => {
                    // Don't try to resume cancelled sessions
                    if (this.cancelledSessions.has(sessionId)) {
                        utilDebugLog(`🚫 Skipping resume for cancelled session ${sessionId}`);
                        return;
                    }
                    // Check if session still exists before trying to resume
                    const session = this.streamingSessions.get(sessionId);
                    if (!session || !session.isActive) {
                        utilDebugLog(`⚠️ Session ${sessionId} no longer exists or is inactive, skipping resume`);
                        this.circuitBreakerState = 'CLOSED';
                        return;
                    }
                    try {
                        await this.resumeStreamingSession(sessionId);
                        this.circuitBreakerState = 'CLOSED';
                        utilDebugLog(`✅ Circuit breaker closed, streaming resumed for session ${sessionId}`);
                    }
                    catch (resumeError) {
                        utilDebugLog(`❌ Failed to resume session after circuit breaker reset:`, resumeError);
                        this.circuitBreakerState = 'OPEN';
                        this.lastFailureTime = Date.now();
                    }
                }, this.BACKOFF_DELAY);
            }, this.CIRCUIT_TIMEOUT);
        }
        // Emit the error event
        const appError = error instanceof AppError ? error : new AppError('Streaming processing failed', ErrorCode.STREAMING_CONTEXT_ERROR, { sessionId, originalError: error instanceof Error ? error.message : 'Unknown error' });
        this.emit('streaming:error', { sessionId, error: appError });
    }
    /**
     * Check if circuit breaker allows processing
     */
    shouldAllowProcessing() {
        if (this.circuitBreakerState === 'CLOSED') {
            return true;
        }
        if (this.circuitBreakerState === 'OPEN') {
            // Check if enough time has passed to try again
            const timeSinceLastFailure = Date.now() - this.lastFailureTime;
            if (timeSinceLastFailure > this.CIRCUIT_TIMEOUT) {
                this.circuitBreakerState = 'HALF_OPEN';
                return true;
            }
            return false;
        }
        // HALF_OPEN state - allow one attempt
        return true;
    }
    /**
     * Reset circuit breaker on successful processing
     */
    onProcessingSuccess() {
        if (this.consecutiveFailures > 0) {
            this.consecutiveFailures = 0;
            this.circuitBreakerState = 'CLOSED';
            utilDebugLog(`✅ Circuit breaker reset after successful processing`);
        }
    }
    /**
     * Get current application state
     */
    getCurrentState() {
        return this.currentState;
    }
    /**
     * Check if currently processing
     */
    getIsProcessing() {
        return this.isProcessing;
    }
    /**
     * Get current recording duration
     */
    getRecordingDuration() {
        return this.services.recording.getRecordingDuration();
    }
    /**
     * Validate recording duration against subscription limits
     */
    async validateRecordingDuration() {
        const currentDuration = this.getRecordingDuration();
        const subscriptionService = this.services.subscription;
        if (!subscriptionService) {
            // If no subscription service, default to 1 minute limit
            return currentDuration < 60; // 1 minute in seconds
        }
        const maxMinutes = await subscriptionService.getMaxRecordingDuration();
        const maxSeconds = maxMinutes * 60;
        return currentDuration < maxSeconds;
    }
    /**
     * Check if user can continue recording based on subscription limits
     */
    async checkRecordingLimits() {
        const isValid = await this.validateRecordingDuration();
        if (!isValid) {
            const subscriptionService = this.services.subscription;
            const maxMinutes = subscriptionService ?
                await subscriptionService.getMaxRecordingDuration() : 1;
            throw new AppError(`Recording limit reached. Your plan allows up to ${maxMinutes} minute${maxMinutes > 1 ? 's' : ''} per session.`, ErrorCode.SUBSCRIPTION_REQUIRED, {
                suggestion: maxMinutes === 1 ?
                    'Upgrade to Professional for 10-minute recordings. Run: twhisper subscribe' :
                    'Recording session limit reached. Please stop and start a new session.',
                recoverable: true,
                maxMinutes
            });
        }
    }
    /**
     * Get current recording status
     */
    getIsRecording() {
        return this.services.recording.getIsRecording();
    }
    setState(newState) {
        if (this.currentState !== newState) {
            this.currentState = newState;
            this.emit('state:changed', newState);
        }
    }
    handleError(error) {
        this.setState(AppState.ERROR);
        this.isProcessing = false;
        // Enhance error with recovery suggestions
        const enhancedError = this.enhanceErrorWithSuggestions(error);
        // Emit the traditional pipeline error event for backward compatibility
        this.emit('pipeline:error', enhancedError);
        // Emit structured error events for Electron integration
        this.emitStructuredErrorEvents(enhancedError);
        // Auto-reset to idle after error display
        const resetDelay = this.getErrorResetDelay(error);
        setTimeout(() => {
            if (this.currentState === AppState.ERROR) {
                this.setState(AppState.IDLE);
            }
        }, resetDelay);
    }
    /**
     * Enhance errors with helpful recovery suggestions
     */
    enhanceErrorWithSuggestions(error) {
        const details = error.details || {};
        switch (error.code) {
            case ErrorCode.NETWORK_ERROR:
                return new AppError(error.message, error.code, {
                    ...details,
                    suggestion: 'Check your internet connection and try again',
                    recoverable: true
                });
            case ErrorCode.AUTHENTICATION_ERROR:
                return new AppError(error.message, error.code, {
                    ...details,
                    suggestion: 'Please verify your Azure OpenAI API credentials in the .env file',
                    recoverable: false
                });
            case ErrorCode.RATE_LIMIT_EXCEEDED:
                return new AppError(error.message, error.code, {
                    ...details,
                    suggestion: 'API rate limit exceeded. Please wait a moment before trying again',
                    recoverable: true
                });
            case ErrorCode.RECORDING_ERROR:
                if (details.reason === 'recording_too_short') {
                    return new AppError(error.message, error.code, {
                        ...details,
                        suggestion: 'Press SPACE to start recording and speak for at least 1 second',
                        recoverable: true
                    });
                }
                else if (details.reason === 'silent_audio') {
                    return new AppError(error.message, error.code, {
                        ...details,
                        suggestion: 'Check your microphone settings and ensure you are speaking clearly',
                        recoverable: true
                    });
                }
                else if (details.reason === 'max_duration_exceeded') {
                    return new AppError(error.message, error.code, {
                        ...details,
                        suggestion: 'Keep recordings under the maximum duration limit',
                        recoverable: true
                    });
                }
                break;
            case ErrorCode.SERVICE_UNAVAILABLE:
                return new AppError(error.message, error.code, {
                    ...details,
                    suggestion: 'Azure OpenAI service is temporarily unavailable. Please try again later',
                    recoverable: true
                });
        }
        return error;
    }
    /**
     * Get appropriate reset delay based on error type
     */
    getErrorResetDelay(error) {
        const details = error.details || {};
        // Shorter delay for recoverable errors
        if (details.recoverable) {
            return 3000; // 3 seconds
        }
        // Longer delay for serious errors that need attention
        switch (error.code) {
            case ErrorCode.AUTHENTICATION_ERROR:
            case ErrorCode.CONFIGURATION_ERROR:
                return 10000; // 10 seconds
            default:
                return 5000; // 5 seconds
        }
    }
    /**
     * Reset pipeline to idle state
     */
    reset() {
        if (this.currentState === AppState.RECORDING) {
            this.cancelRecording();
        }
        this.currentRecording = null;
        this.isProcessing = false;
        this.setState(AppState.IDLE);
    }
    /**
     * Get processing statistics
     */
    getProcessingStats() {
        const streamingSessionStats = Array.from(this.streamingSessions.values()).map(session => ({
            sessionId: session.sessionId,
            isActive: session.isActive,
            isPaused: session.isPaused,
            chunkCount: session.chunkCount,
            duration: Date.now() - session.startTime,
            accumulatedTextLength: session.accumulatedText.length
        }));
        return {
            currentState: this.currentState,
            isProcessing: this.isProcessing,
            isRecording: this.getIsRecording(),
            recordingDuration: this.getRecordingDuration(),
            currentMode: this.getCurrentMode(),
            availableModes: this.getAvailableModes(),
            currentProcessingMode: this.currentProcessingMode,
            activeStreamingSessions: Array.from(this.streamingSessions.values()).filter(s => s.isActive).length,
            isModeSwitching: this.isModeSwitching,
            streamingSessionStats: streamingSessionStats.length > 0 ? streamingSessionStats : undefined
        };
    }
    /**
     * Check streaming requirements and offer automatic installation
     */
    async checkStreamingRequirements() {
        // Check authentication requirement first if enabled
        const config = this.services.configuration.getConfiguration();
        if (config?.auth.enabled && config?.auth.requireForStreaming) {
            const { isAuthenticated } = await this.getCachedAuthStatus();
            if (!isAuthenticated) {
                throw new AppError('Only an authenticated user is allowed to use streaming mode. Run \'twhisper login\' to authenticate.', ErrorCode.STREAMING_AUTHENTICATION_REQUIRED);
            }
            // Use cached subscription info - no more redundant API calls during mode switching!
            const { canUseStreaming } = await this.getCachedSubscriptionInfo();
            if (!canUseStreaming) {
                throw new AppError('Streaming mode requires an active Professional subscription. Upgrade to access real-time transcription.', ErrorCode.SUBSCRIPTION_REQUIRED);
            }
        }
        // Use small model for streaming mode (good balance of speed and accuracy)
        const modelSize = 'small';
        // Check if whisper.cpp is installed
        const whisperInstalled = await this.checkWhisperInstalled();
        const modelExists = await this.checkWhisperModelExists(modelSize);
        if (!whisperInstalled || !modelExists) {
            // Emit setup required event to UI
            this.emit('streaming:setup:required', {
                whisperInstalled,
                modelExists,
                modelSize,
                setupMessage: this.generateSetupMessage(whisperInstalled, modelExists, modelSize)
            });
            // Auto-download small model without user confirmation for better UX
            await this.performStreamingSetup(whisperInstalled, modelExists, modelSize);
        }
    }
    /**
     * Check if whisper.cpp is installed (not Python whisper)
     */
    async checkWhisperInstalled() {
        const possiblePaths = [
            '/opt/homebrew/bin/whisper-cli', // Homebrew whisper-cpp on Apple Silicon (new)
            '/usr/local/bin/whisper-cli', // Homebrew whisper-cpp on Intel (new)
            '/opt/homebrew/bin/whisper-cpp', // Homebrew whisper-cpp on Apple Silicon (deprecated)
            '/usr/local/bin/whisper-cpp', // Homebrew whisper-cpp on Intel (deprecated)
            '/opt/homebrew/bin/main', // whisper.cpp main binary on Apple Silicon
            '/usr/local/bin/main', // whisper.cpp main binary on Intel
            'whisper-cli', // In PATH (new)
            'whisper-cpp', // In PATH (deprecated)
            './main' // Local build
        ];
        for (const whisperPath of possiblePaths) {
            try {
                await this.testWhisperCppCommand(whisperPath, ['--help']);
                return true;
            }
            catch {
                continue;
            }
        }
        return false;
    }
    /**
     * Check if whisper model exists for the specified size
     */
    async checkWhisperModelExists(modelSize) {
        // Create model paths based on the configured size
        const possibleModelPaths = [
            `/opt/homebrew/share/whisper.cpp/ggml-${modelSize}.en.bin`,
            `/usr/local/share/whisper.cpp/ggml-${modelSize}.en.bin`,
            `./models/ggml-${modelSize}.en.bin`,
            path.join(process.env.HOME || os.homedir(), `.whisper/ggml-${modelSize}.en.bin`)
        ];
        for (const modelPath of possibleModelPaths) {
            try {
                await promisify(fs.access)(modelPath);
                return true;
            }
            catch {
                continue;
            }
        }
        return false;
    }
    /**
     * Test if a command works
     */
    async testCommand(command, args) {
        return new Promise((resolve, reject) => {
            const child = spawn(command, args, { stdio: 'pipe' });
            child.on('error', reject);
            child.on('close', (code) => {
                if (code === 0) {
                    resolve();
                }
                else {
                    reject(new Error(`Command failed with code ${code}`));
                }
            });
            // Timeout after 5 seconds
            setTimeout(() => {
                child.kill();
                reject(new Error('Command timeout'));
            }, 5000);
        });
    }
    /**
     * Test if whisper.cpp command works (not Python whisper)
     */
    async testWhisperCppCommand(command, args) {
        return new Promise((resolve, reject) => {
            const child = spawn(command, args, { stdio: 'pipe' });
            let stdout = '';
            let stderr = '';
            child.stdout?.on('data', (data) => {
                stdout += data.toString();
            });
            child.stderr?.on('data', (data) => {
                stderr += data.toString();
            });
            child.on('error', reject);
            child.on('close', (code) => {
                const output = stdout + stderr; // Combine both outputs
                // Check if this is whisper.cpp (should mention model file or have specific whisper.cpp help format)
                if (code === 0 && (output.includes('--model') || output.includes('whisper-cli') || output.includes('supported audio formats'))) {
                    resolve();
                }
                else if (output.includes('openai-whisper') || output.includes('--output_format')) {
                    // This is Python whisper, not whisper.cpp
                    reject(new Error(`Found Python whisper instead of whisper.cpp at ${command}`));
                }
                else {
                    reject(new Error(`whisper.cpp command test failed with code ${code}. stdout: ${stdout}, stderr: ${stderr}`));
                }
            });
            // Timeout after 5 seconds
            setTimeout(() => {
                child.kill();
                reject(new Error('Command timeout'));
            }, 5000);
        });
    }
    /**
     * Generate setup message for user
     */
    generateSetupMessage(whisperInstalled, modelExists, modelSize) {
        let message = '🎙️ Streaming mode requires local Whisper installation:\n\n';
        if (!whisperInstalled) {
            message += '📦 whisper.cpp needs to be installed via Homebrew\n';
        }
        else {
            message += '✅ whisper.cpp is already installed\n';
        }
        if (!modelExists) {
            const size = modelSize === 'medium' ? '~769MB' : '~244MB';
            message += `🧠 Whisper ${modelSize} model needs to be downloaded (${size})\n`;
        }
        else {
            message += `✅ Whisper ${modelSize} model is already available\n`;
        }
        message += '\nWould you like to proceed with automatic setup?';
        message += `\n\n💡 Tip: You can change the model size (small/medium) in settings`;
        return message;
    }
    /**
     * Ask user for setup confirmation
     */
    async askUserForSetupConfirmation(whisperInstalled, modelExists, modelSize) {
        // This would integrate with the UI to show a confirmation dialog
        // For now, we'll emit an event and assume confirmation
        // The UI component should handle this event and show appropriate dialog
        return new Promise((resolve) => {
            // Emit confirmation request event
            this.emit('streaming:setup:confirmation', {
                whisperInstalled,
                modelExists,
                modelSize,
                onConfirm: () => resolve(true),
                onCancel: () => resolve(false)
            });
            // Auto-confirm after 10 seconds if no response (for automated testing)
            setTimeout(() => resolve(true), 10000);
        });
    }
    /**
     * Perform automatic streaming setup
     */
    async performStreamingSetup(whisperInstalled, modelExists, modelSize) {
        this.emit('streaming:setup:started', { whisperInstalled, modelExists, modelSize });
        try {
            // Install whisper.cpp if needed
            if (!whisperInstalled) {
                this.emit('streaming:setup:progress', { stage: 'Installing whisper.cpp...', progress: 25 });
                await this.runCommand('brew', ['install', 'whisper-cpp']);
            }
            // Download model if needed
            if (!modelExists) {
                this.emit('streaming:setup:progress', { stage: `Downloading ${modelSize} model...`, progress: 50 });
                const homeDir = process.env.HOME || os.homedir();
                const whisperDir = path.join(homeDir, '.whisper');
                const modelPath = path.join(whisperDir, `ggml-${modelSize}.en.bin`);
                // Create directory
                await promisify(fs.mkdir)(whisperDir, { recursive: true });
                // Download model based on size
                const modelUrl = `https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-${modelSize}.en.bin`;
                await this.runCommand('curl', [
                    '-L',
                    modelUrl,
                    '-o',
                    modelPath
                ]);
            }
            this.emit('streaming:setup:progress', { stage: 'Setup complete!', progress: 100 });
            this.emit('streaming:setup:completed', { whisperInstalled: true, modelExists: true, modelSize });
        }
        catch (error) {
            const setupError = new AppError('Failed to setup streaming requirements', ErrorCode.SERVICE_NOT_INITIALIZED, {
                error: error instanceof Error ? error.message : 'Unknown error',
                whisperInstalled,
                modelExists,
                modelSize
            });
            this.emit('streaming:setup:failed', setupError);
            throw setupError;
        }
    }
    /**
     * Run a command and wait for completion
     */
    async runCommand(command, args) {
        return new Promise((resolve, reject) => {
            const child = spawn(command, args, {
                stdio: ['pipe', 'inherit', 'inherit'],
                shell: true
            });
            child.on('error', (error) => {
                reject(new Error(`Failed to run ${command}: ${error.message}`));
            });
            child.on('close', (code) => {
                if (code === 0) {
                    resolve();
                }
                else {
                    reject(new Error(`${command} failed with code ${code}`));
                }
            });
        });
    }
    /**
     * Validate recording data before processing
     */
    validateRecording(audioData) {
        const minDuration = 1; // Hardcoded to 1 second minimum
        // Check if audio data is empty
        if (!audioData || audioData.length === 0) {
            throw new AppError('No audio captured during recording', ErrorCode.RECORDING_ERROR, {
                reason: 'empty_recording',
                suggestion: 'Try: 1) Check microphone permissions, 2) Record for longer (speak for 2-3 seconds), 3) Check microphone is working, 4) Increase microphone volume'
            });
        }
        // Calculate approximate duration (16kHz, mono, 16-bit = 32000 bytes/second)
        const approximateDuration = audioData.length / 32000;
        // Check for recordings that are too short
        if (approximateDuration < minDuration) {
            throw new AppError(`Recording too short: ${approximateDuration.toFixed(1)}s (minimum: ${minDuration}s). Please record for longer.`, ErrorCode.RECORDING_ERROR, {
                reason: 'recording_too_short',
                duration: approximateDuration,
                minDuration
            });
        }
        // Check for silent or very quiet audio
        if (this.isSilentAudio(audioData)) {
            throw new AppError('No speech detected in recording. Please check your microphone and speak clearly.', ErrorCode.RECORDING_ERROR, { reason: 'silent_audio' });
        }
    }
    /**
     * Check if audio data is silent or very quiet
     */
    isSilentAudio(audioData) {
        if (!audioData || audioData.length === 0) {
            return true;
        }
        const samples = audioData.length / 2; // 16-bit audio = 2 bytes per sample
        let sumSquared = 0;
        let maxAmplitude = 0;
        for (let i = 0; i < audioData.length; i += 2) {
            const sample = audioData.readInt16LE(i);
            const amplitude = Math.abs(sample);
            sumSquared += sample * sample;
            maxAmplitude = Math.max(maxAmplitude, amplitude);
        }
        const rms = Math.sqrt(sumSquared / samples);
        const normalizedRMS = rms / 32768; // Normalize to 0-1
        const normalizedMax = maxAmplitude / 32768;
        // Consider audio silent if both RMS and max amplitude are very low
        const SILENCE_RMS_THRESHOLD = 0.01; // 1% of max
        const SILENCE_MAX_THRESHOLD = 0.05; // 5% of max
        return normalizedRMS < SILENCE_RMS_THRESHOLD && normalizedMax < SILENCE_MAX_THRESHOLD;
    }
    /**
     * Get current configuration values
     */
    getConfiguration() {
        return this.services.configuration.getConfiguration();
    }
    /**
     * Get cached authentication status or check fresh if cache expired
     */
    async getCachedAuthStatus() {
        const now = Date.now();
        if (this.authCache && (now - this.authCache.timestamp) < this.CACHE_TTL_MS) {
            return { isAuthenticated: this.authCache.isAuthenticated, user: this.authCache.user };
        }
        try {
            const authService = new AuthenticationService(this.services.configuration);
            const isAuthenticated = await authService.isAuthenticated();
            const user = isAuthenticated ? await authService.getCurrentUser() : null;
            this.authCache = {
                isAuthenticated,
                user: user?.user || null,
                timestamp: now
            };
            return { isAuthenticated, user: user?.user || null };
        }
        catch {
            // Return cached value if available, otherwise default to unauthenticated
            if (this.authCache) {
                return { isAuthenticated: this.authCache.isAuthenticated, user: this.authCache.user };
            }
            return { isAuthenticated: false, user: null };
        }
    }
    /**
     * Get cached subscription info (max duration and streaming access) or check fresh if cache expired
     */
    async getCachedSubscriptionInfo() {
        const now = Date.now();
        // Use longer cache for subscription features since they change less frequently
        if (this.subscriptionCache && (now - this.subscriptionCache.timestamp) < this.SUBSCRIPTION_CACHE_TTL_MS) {
            return {
                maxDuration: this.subscriptionCache.maxDuration,
                canUseStreaming: this.subscriptionCache.canUseStreaming
            };
        }
        try {
            const config = this.services.configuration.getConfiguration();
            let maxDuration = 60; // Default 1 minute
            let canUseStreaming = false; // Default no streaming
            if (config?.auth.enabled) {
                const { isAuthenticated, user } = await this.getCachedAuthStatus();
                if (isAuthenticated) {
                    const subscriptionService = this.services.subscription;
                    if (subscriptionService && user) {
                        subscriptionService.setCurrentUser(user);
                        const maxMinutes = await subscriptionService.getMaxRecordingDuration();
                        maxDuration = maxMinutes * 60;
                        // Check streaming access based on subscription
                        canUseStreaming = await subscriptionService.canUseStreamingMode();
                    }
                }
            }
            this.subscriptionCache = {
                maxDuration,
                canUseStreaming,
                timestamp: now
            };
            return { maxDuration, canUseStreaming };
        }
        catch (error) {
            console.warn('Failed to refresh subscription status:', error);
            // Security fix: If we have cached data but it's expired and API failed,
            // be more restrictive - default to starter permissions instead of
            // potentially outdated professional access
            if (this.subscriptionCache && (now - this.subscriptionCache.timestamp) >= this.SUBSCRIPTION_CACHE_TTL_MS) {
                console.warn('Subscription cache expired and API failed - defaulting to starter permissions for security');
                return { maxDuration: 60, canUseStreaming: false };
            }
            // If we have recent cached data and API temporarily failed, use it
            if (this.subscriptionCache) {
                console.warn('Using cached subscription data due to temporary API failure');
                return {
                    maxDuration: this.subscriptionCache.maxDuration,
                    canUseStreaming: this.subscriptionCache.canUseStreaming
                };
            }
            // No cached data available
            return { maxDuration: 60, canUseStreaming: false };
        }
    }
    /**
     * Get cached subscription max duration or check fresh if cache expired
     */
    async getCachedMaxDuration() {
        const { maxDuration } = await this.getCachedSubscriptionInfo();
        return maxDuration;
    }
    /**
     * Check if current user has a starter plan (for UI conditional display)
     */
    async isStarterPlan() {
        try {
            const config = this.services.configuration.getConfiguration();
            if (!config?.auth.enabled) {
                return true; // If auth is disabled, assume starter plan
            }
            const { isAuthenticated, user } = await this.getCachedAuthStatus();
            if (!isAuthenticated) {
                return true; // Unauthenticated users are treated as starter
            }
            const subscriptionService = this.services.subscription;
            if (!subscriptionService) {
                return true; // No subscription service means starter
            }
            // Set current user for subscription service
            if (user) {
                subscriptionService.setCurrentUser(user);
            }
            const subscriptionStatus = await subscriptionService.getSubscriptionStatus();
            return subscriptionStatus.tier === 'starter';
        }
        catch {
            // If we can't check subscription status, assume starter plan
            return true;
        }
    }
    /**
     * Update configuration with new values
     */
    async updateConfiguration(changes) {
        const config = this.services.configuration;
        // Apply changes to configuration
        for (const [key, value] of Object.entries(changes)) {
            config.set(key, value);
        }
        // Save configuration
        await config.save();
    }
    /**
     * Reset configuration to defaults
     */
    async resetConfiguration() {
        // This would need to be implemented based on requirements
        // For now, just reload the configuration
        await this.services.configuration.load();
    }
    /**
     * Get human-readable language name from language code
     */
    getLanguageName(languageCode) {
        const languageNames = {
            'en': 'English',
            'no': 'Norwegian',
            'da': 'Danish',
            'fi': 'Finnish'
        };
        return languageNames[languageCode] || languageCode;
    }
    /**
     * Validate language permissions on startup and enforce restrictions
     * This prevents users from bypassing subscription checks via config files
     */
    async validateAndEnforceLanguagePermissions() {
        const config = this.services.configuration;
        const currentLanguage = config.get('whisper.language') || 'en';
        // If already English, no restrictions needed
        if (currentLanguage === 'en') {
            return;
        }
        try {
            // Check if non-English language usage is allowed
            const authConfig = config.getConfiguration();
            if (!authConfig?.auth?.enabled) {
                // Auth disabled - force English and warn user
                await this.forceLanguageToEnglish(currentLanguage, 'Authentication is disabled');
                return;
            }
            const { isAuthenticated } = await this.getCachedAuthStatus();
            if (!isAuthenticated) {
                // Not authenticated - force English and warn user
                await this.forceLanguageToEnglish(currentLanguage, 'User not authenticated');
                return;
            }
            const { canUseStreaming } = await this.getCachedSubscriptionInfo();
            if (!canUseStreaming) {
                // No subscription - force English and warn user
                await this.forceLanguageToEnglish(currentLanguage, 'No active Professional subscription');
                return;
            }
            // User has permission - allow the configured language
            console.log(`✅ [ProcessingPipeline] User has permission to use ${this.getLanguageName(currentLanguage)} language`);
        }
        catch (error) {
            // Error checking permissions - default to English for security
            await this.forceLanguageToEnglish(currentLanguage, `Permission check failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Force language back to English and notify user
     */
    async forceLanguageToEnglish(attemptedLanguage, reason) {
        console.warn(`⚠️ [ProcessingPipeline] Restricting language access: ${reason}. Defaulting to English.`);
        try {
            // Update configuration to English
            await this.updateConfiguration({ 'whisper.language': 'en' });
            // Emit warning event to UI (will be displayed as a temporary message)
            this.emit('whisper:language:error', {
                currentLanguage: 'en',
                attemptedLanguage,
                error: `${this.getLanguageName(attemptedLanguage)} language requires authentication and active subscription. Defaulted to English.`
            });
        }
        catch (updateError) {
            console.error('Failed to update language configuration:', updateError);
        }
    }
    /**
     * Toggle Whisper language between English, Norwegian, Danish, and Finnish
     * Non-English languages require authentication and active subscription
     */
    async toggleWhisperModel() {
        const config = this.services.configuration;
        const currentLanguage = config.get('whisper.language') || 'en';
        const currentModel = config.get('whisper.modelSize');
        let newLanguage;
        let newModel = currentModel;
        // Cycle through: en → no → da → fi → en
        switch (currentLanguage) {
            case 'en':
                newLanguage = 'no';
                // For Norwegian, we MUST use the general model (remove .en suffix)
                if (currentModel.endsWith('.en')) {
                    newModel = currentModel.replace('.en', '');
                }
                break;
            case 'no':
                newLanguage = 'da';
                // For Danish, we MUST use the general model (remove .en suffix)
                if (currentModel.endsWith('.en')) {
                    newModel = currentModel.replace('.en', '');
                }
                break;
            case 'da':
                newLanguage = 'fi';
                // For Finnish, we MUST use the general model (remove .en suffix)
                if (currentModel.endsWith('.en')) {
                    newModel = currentModel.replace('.en', '');
                }
                break;
            case 'fi':
                newLanguage = 'en';
                // For English, we can use .en models if available
                if (!currentModel.endsWith('.en')) {
                    const englishModel = currentModel + '.en';
                    // Check if the English variant exists in valid models
                    const validModels = ['tiny.en', 'base.en', 'small.en', 'medium.en'];
                    if (validModels.includes(englishModel)) {
                        newModel = englishModel;
                    }
                }
                break;
            default:
                newLanguage = 'en';
                break;
        }
        try {
            // Check if switching to a non-English language requires authentication and subscription
            if (newLanguage !== 'en') {
                // Check authentication status
                const authConfig = config.getConfiguration();
                if (!authConfig?.auth?.enabled) {
                    throw new AppError(`${this.getLanguageName(newLanguage)} language requires authentication. Run 'twhisper login' to authenticate.`, ErrorCode.STREAMING_AUTHENTICATION_REQUIRED);
                }
                const { isAuthenticated } = await this.getCachedAuthStatus();
                if (!isAuthenticated) {
                    throw new AppError(`${this.getLanguageName(newLanguage)} language requires authentication. Run 'twhisper login' to authenticate.`, ErrorCode.STREAMING_AUTHENTICATION_REQUIRED);
                }
                // Check subscription status
                const { canUseStreaming } = await this.getCachedSubscriptionInfo();
                if (!canUseStreaming) {
                    throw new AppError(`${this.getLanguageName(newLanguage)} language requires an active Professional subscription. Upgrade to access multilingual transcription.`, ErrorCode.SUBSCRIPTION_REQUIRED);
                }
            }
            // Update the configuration
            const updates = {
                'whisper.language': newLanguage
            };
            // Only update model if it changed
            if (newModel !== currentModel) {
                updates['whisper.modelSize'] = newModel;
            }
            await this.updateConfiguration(updates);
            // Persist the language change to config file
            try {
                await this.services.configuration.persistLanguage(newLanguage);
            }
            catch (error) {
                utilDebugLog(`⚠️ [ProcessingPipeline] Failed to persist language change: ${error instanceof Error ? error.message : 'Unknown error'}`);
            }
            // Emit event to notify UI
            this.emit('whisper:language:changed', {
                from: currentLanguage,
                to: newLanguage,
                modelFrom: currentModel,
                modelTo: newModel
            });
        }
        catch (error) {
            // If update fails, emit error
            this.emit('whisper:language:error', {
                currentLanguage,
                attemptedLanguage: newLanguage,
                currentModel,
                attemptedModel: newModel,
                error: error instanceof Error ? error.message : String(error)
            });
        }
    }
    // === ENHANCED ERROR HANDLING FOR ELECTRON INTEGRATION ===
    /**
     * Emit structured error events based on error type and context
     * Provides detailed, actionable error information for Electron UI
     */
    emitStructuredErrorEvents(error) {
        const context = this.getErrorContext(error);
        switch (error.code) {
            case ErrorCode.NETWORK_ERROR:
            case ErrorCode.SERVICE_UNAVAILABLE:
                this.emit('error:network', {
                    error,
                    retryCount: error.details?.retryCount || 0,
                    nextRetryIn: this.calculateRetryDelay(error)
                });
                break;
            case ErrorCode.AUTHENTICATION_ERROR:
                this.emit('error:authentication', {
                    error,
                    setupRequired: true,
                    helpUrl: 'https://github.com/svenmalvik/Twhisper#setup'
                });
                break;
            case ErrorCode.SUBSCRIPTION_REQUIRED:
            case ErrorCode.STREAMING_AUTHENTICATION_REQUIRED:
                this.emit('error:subscription', {
                    error,
                    tierRequired: 'Professional',
                    upgradeUrl: 'https://twhisper.com/subscribe'
                });
                break;
            case ErrorCode.CONFIGURATION_ERROR:
                this.emit('error:configuration', {
                    error,
                    configPath: '.env',
                    invalidFields: this.extractInvalidFields(error)
                });
                break;
            case ErrorCode.SERVICE_NOT_INITIALIZED:
                this.emit('error:critical', {
                    error,
                    requiresRestart: true,
                    context
                });
                break;
            default:
                // For recoverable errors
                if (error.details?.recoverable) {
                    this.emit('error:recoverable', {
                        error,
                        suggestion: error.details.suggestion || 'Please try again',
                        context
                    });
                }
                else {
                    this.emit('error:critical', {
                        error,
                        requiresRestart: false,
                        context
                    });
                }
                break;
        }
    }
    /**
     * Get additional context for error reporting
     */
    getErrorContext(error) {
        return {
            timestamp: new Date(),
            state: this.currentState,
            processingMode: this.currentProcessingMode,
            isProcessing: this.isProcessing,
            isRecording: this.getIsRecording(),
            activeStreamingSessions: this.streamingSessions.size,
            currentMode: this.getCurrentMode(),
            errorDetails: error.details || {},
            userAgent: process.platform,
            version: '0.1.48' // Should come from package.json
        };
    }
    /**
     * Calculate retry delay based on error type and history
     */
    calculateRetryDelay(error) {
        const retryCount = error.details?.retryCount || 0;
        const baseDelay = 1000; // 1 second
        return Math.min(baseDelay * Math.pow(2, retryCount), 30000); // Max 30 seconds
    }
    /**
     * Extract invalid configuration fields from error details
     */
    extractInvalidFields(error) {
        if (error.details?.invalidFields) {
            return error.details.invalidFields;
        }
        // Try to infer from error message
        const message = error.message.toLowerCase();
        const fields = [];
        if (message.includes('api key') || message.includes('endpoint')) {
            fields.push('AZURE_OPENAI_API_KEY', 'AZURE_OPENAI_ENDPOINT');
        }
        if (message.includes('deployment')) {
            fields.push('AZURE_OPENAI_WHISPER_DEPLOYMENT', 'AZURE_OPENAI_GPT_DEPLOYMENT');
        }
        return fields;
    }
    /**
     * Create a detailed error report for debugging and support
     */
    createErrorReport(error) {
        const errorId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        return {
            id: errorId,
            timestamp: new Date(),
            error: {
                message: error.message,
                code: error.code,
                stack: error.stack
            },
            context: this.getErrorContext(error),
            systemInfo: {
                platform: process.platform,
                nodeVersion: process.version,
                memoryUsage: process.memoryUsage()
            }
        };
    }
    // === EVENT SUBSCRIPTION METHODS FOR ELECTRON INTEGRATION ===
    /**
     * Subscribe to events with a callback function
     * Provides a convenient way for Electron to subscribe to multiple events
     */
    subscribeToEvents(callback) {
        // Subscribe to all core pipeline events that Electron UI will need
        const coreEvents = [
            'state:changed',
            'recording:started',
            'recording:stopped',
            'recording:cancelled',
            'transcription:started',
            'transcription:progress',
            'transcription:completed',
            'formatting:started',
            'formatting:progress',
            'formatting:completed',
            'clipboard:copied',
            'pipeline:completed',
            'pipeline:error',
            'audio:level',
            'streaming:started',
            'streaming:stopping',
            'streaming:stopped',
            'streaming:paused',
            'streaming:resumed',
            'streaming:partial:result',
            'streaming:progressive:update',
            'streaming:error',
            'mode:changed',
            'mode:switch:started',
            'mode:switch:completed',
            'mode:switch:failed'
        ];
        const listeners = [];
        coreEvents.forEach(event => {
            const listener = (...args) => callback(event, ...args);
            this.on(event, listener);
            listeners.push({ event, listener });
        });
        // Return cleanup function
        return () => {
            listeners.forEach(({ event, listener }) => {
                this.removeListener(event, listener);
            });
        };
    }
    /**
     * Unsubscribe from events
     * Note: This removes ALL listeners for the specified callback
     */
    unsubscribeFromEvents() {
        // Remove all listeners that match the callback
        this.removeAllListeners();
        // Note: In a production implementation, you'd want to track specific callbacks
        // and only remove those. For now, this removes all listeners.
    }
    /**
     * Get current pipeline status for Electron integration
     * Returns comprehensive status information needed by Electron UI
     */
    getStatus() {
        const status = {
            state: this.currentState,
            isProcessing: this.isProcessing,
            isRecording: this.getIsRecording(),
            recordingDuration: this.getRecordingDuration(),
            currentMode: this.getCurrentMode(),
            availableModes: this.getAvailableModes(),
            processingMode: this.currentProcessingMode,
            isModeSwitching: this.isModeSwitching
        };
        // Add streaming information if applicable
        if (this.streamingSessions.size > 0) {
            const sessionDetails = Array.from(this.streamingSessions.values()).map(session => ({
                sessionId: session.sessionId,
                isActive: session.isActive,
                isPaused: session.isPaused,
                chunkCount: session.chunkCount,
                duration: Date.now() - session.startTime,
                accumulatedTextLength: session.accumulatedText.length
            }));
            status.streamingStats = {
                activeSessionId: this.currentStreamingSessionId,
                sessionCount: this.streamingSessions.size,
                sessionDetails
            };
        }
        return status;
    }
    /**
     * Subscribe to status polling for real-time UI updates
     * Electron can use this to get periodic status updates
     */
    subscribeToStatusPolling(callback, intervalMs = 100) {
        const interval = setInterval(() => {
            const status = this.getStatus();
            callback(status);
        }, intervalMs);
        return interval;
    }
    /**
     * Unsubscribe from status polling
     */
    unsubscribeFromStatusPolling(interval) {
        clearInterval(interval);
    }
    /**
     * Advanced status polling with change detection
     * Only calls callback when status actually changes, reducing unnecessary updates
     */
    subscribeToStatusChanges(callback, intervalMs = 100) {
        let lastStatus = this.getStatus();
        let lastStatusString = JSON.stringify(lastStatus);
        const interval = setInterval(() => {
            const currentStatus = this.getStatus();
            const currentStatusString = JSON.stringify(currentStatus);
            if (currentStatusString !== lastStatusString) {
                // Detect what changed
                const changes = this.detectStatusChanges(lastStatus, currentStatus);
                callback(currentStatus, changes);
                lastStatus = currentStatus;
                lastStatusString = currentStatusString;
            }
        }, intervalMs);
        return interval;
    }
    /**
     * Detect specific changes between status objects
     */
    detectStatusChanges(oldStatus, newStatus) {
        const changes = [];
        if (oldStatus.state !== newStatus.state) {
            changes.push(`state:${oldStatus.state}->${newStatus.state}`);
        }
        if (oldStatus.isProcessing !== newStatus.isProcessing) {
            changes.push(`processing:${oldStatus.isProcessing}->${newStatus.isProcessing}`);
        }
        if (oldStatus.isRecording !== newStatus.isRecording) {
            changes.push(`recording:${oldStatus.isRecording}->${newStatus.isRecording}`);
        }
        if (oldStatus.currentMode !== newStatus.currentMode) {
            changes.push(`mode:${oldStatus.currentMode}->${newStatus.currentMode}`);
        }
        if (oldStatus.processingMode !== newStatus.processingMode) {
            changes.push(`processingMode:${oldStatus.processingMode}->${newStatus.processingMode}`);
        }
        if (oldStatus.isModeSwitching !== newStatus.isModeSwitching) {
            changes.push(`modeSwitching:${oldStatus.isModeSwitching}->${newStatus.isModeSwitching}`);
        }
        // Check streaming session changes
        const oldSessionCount = oldStatus.streamingStats?.sessionCount || 0;
        const newSessionCount = newStatus.streamingStats?.sessionCount || 0;
        if (oldSessionCount !== newSessionCount) {
            changes.push(`streamingSessions:${oldSessionCount}->${newSessionCount}`);
        }
        return changes;
    }
    /**
     * Get performance metrics for status monitoring
     */
    getPerformanceMetrics() {
        const memoryUsage = process.memoryUsage();
        const totalMemory = memoryUsage.heapUsed + memoryUsage.external;
        return {
            memory: {
                used: totalMemory,
                total: memoryUsage.heapTotal,
                percentage: (totalMemory / memoryUsage.heapTotal) * 100
            },
            uptime: process.uptime(),
            processedSessions: this.streamingSessions.size,
            averageProcessingTime: 0, // Could be calculated from session history
            errorRate: this.consecutiveFailures > 0 ? (this.consecutiveFailures / 10) * 100 : 0, // Rough error rate
            lastErrorTime: this.lastFailureTime > 0 ? new Date(this.lastFailureTime) : undefined
        };
    }
    /**
     * Subscribe to performance monitoring with alerts
     */
    subscribeToPerformanceMonitoring(callback, thresholds = {}, intervalMs = 5000) {
        const defaultThresholds = {
            memoryThreshold: 80, // 80%
            uptimeThreshold: 86400, // 24 hours
            errorRateThreshold: 10, // 10%
            ...thresholds
        };
        const interval = setInterval(() => {
            const metrics = this.getPerformanceMetrics();
            const alerts = [];
            // Check memory usage
            if (metrics.memory.percentage > defaultThresholds.memoryThreshold) {
                alerts.push(`High memory usage: ${metrics.memory.percentage.toFixed(1)}%`);
            }
            // Check error rate
            if (metrics.errorRate > defaultThresholds.errorRateThreshold) {
                alerts.push(`High error rate: ${metrics.errorRate.toFixed(1)}%`);
            }
            // Check if running too long
            if (metrics.uptime > defaultThresholds.uptimeThreshold) {
                alerts.push(`Long uptime detected: ${Math.floor(metrics.uptime / 3600)}h`);
            }
            callback(metrics, alerts);
        }, intervalMs);
        return interval;
    }
    /**
     * Create a comprehensive health check for Electron integration
     */
    async performHealthCheck() {
        const checks = [];
        // Check service availability
        try {
            const config = this.services.configuration.getConfiguration();
            checks.push({
                name: 'Configuration Service',
                status: config ? 'pass' : 'fail',
                message: config ? 'Configuration loaded successfully' : 'Configuration not available'
            });
        }
        catch (error) {
            checks.push({
                name: 'Configuration Service',
                status: 'fail',
                message: `Configuration error: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
        }
        // Check recording service
        try {
            const isRecording = this.getIsRecording();
            checks.push({
                name: 'Recording Service',
                status: 'pass',
                message: `Recording service functional (currently ${isRecording ? 'recording' : 'idle'})`
            });
        }
        catch (error) {
            checks.push({
                name: 'Recording Service',
                status: 'fail',
                message: `Recording service error: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
        }
        // Check memory usage
        const metrics = this.getPerformanceMetrics();
        checks.push({
            name: 'Memory Usage',
            status: metrics.memory.percentage > 90 ? 'warning' : 'pass',
            message: `Memory usage: ${metrics.memory.percentage.toFixed(1)}%`,
            details: { used: metrics.memory.used, total: metrics.memory.total }
        });
        // Check error rate
        checks.push({
            name: 'Error Rate',
            status: metrics.errorRate > 20 ? 'warning' : 'pass',
            message: `Error rate: ${metrics.errorRate.toFixed(1)}%`,
            details: { consecutiveFailures: this.consecutiveFailures }
        });
        // Determine overall status
        const hasFailures = checks.some(check => check.status === 'fail');
        const hasWarnings = checks.some(check => check.status === 'warning');
        const overallStatus = hasFailures ? 'error' : hasWarnings ? 'warning' : 'healthy';
        return {
            status: overallStatus,
            checks,
            timestamp: new Date()
        };
    }
    /**
     * Create a structured event listener for specific event types
     * Useful for Electron to listen to specific categories of events
     */
    createEventListener(eventCategories) {
        return (callback) => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const listeners = [];
            // State events
            if (eventCategories.states) {
                const stateListener = (state) => {
                    callback({ type: 'state_changed', data: { state }, timestamp: new Date() });
                };
                this.on('state:changed', stateListener);
                listeners.push({ event: 'state:changed', listener: stateListener });
            }
            // Recording events
            if (eventCategories.recording) {
                const recordingStartedListener = () => {
                    callback({ type: 'recording_started', data: {}, timestamp: new Date() });
                };
                const recordingStoppedListener = (audioData) => {
                    callback({ type: 'recording_stopped', data: { audioDataLength: audioData.length }, timestamp: new Date() });
                };
                const recordingCancelledListener = () => {
                    callback({ type: 'recording_cancelled', data: {}, timestamp: new Date() });
                };
                this.on('recording:started', recordingStartedListener);
                this.on('recording:stopped', recordingStoppedListener);
                this.on('recording:cancelled', recordingCancelledListener);
                listeners.push({ event: 'recording:started', listener: recordingStartedListener }, { event: 'recording:stopped', listener: recordingStoppedListener }, { event: 'recording:cancelled', listener: recordingCancelledListener });
            }
            // Error events
            if (eventCategories.errors) {
                const errorListener = (error) => {
                    callback({
                        type: 'pipeline_error',
                        data: {
                            message: error.message,
                            code: error.code,
                            details: error.details
                        },
                        timestamp: new Date()
                    });
                };
                this.on('pipeline:error', errorListener);
                listeners.push({ event: 'pipeline:error', listener: errorListener });
            }
            // Return cleanup function
            return () => {
                listeners.forEach(({ event, listener }) => {
                    this.removeListener(event, listener);
                });
            };
        };
    }
}
//# sourceMappingURL=ProcessingPipeline.js.map