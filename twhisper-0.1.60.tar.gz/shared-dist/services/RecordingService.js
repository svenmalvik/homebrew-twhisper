import { IEnhancedRecordingService, ProcessingMode, } from '../interfaces/interfaces.js';
import { CircularBuffer } from './audio/CircularBuffer.js';
import { StreamingRecorder } from './audio/StreamingRecorder.js';
import { SequentialStreamingRecorder } from './audio/SequentialStreamingRecorder.js';
export class RecordingService extends IEnhancedRecordingService {
    constructor() {
        super();
        this.recorder = null;
        this.audioBuffer = [];
        this.isRecording = false;
        this.startTime = null;
        this.audioLevels = [];
        // Pre-loaded module for faster startup
        this.recordModule = null;
        this.moduleLoaded = false;
        // Enhanced streaming properties
        this.processingMode = ProcessingMode.BATCH;
        this.isStreaming = false;
        this.streamingRecorder = null;
        this.sequentialRecorder = null;
        this.useSequentialStreaming = true; // Use simpler sequential streaming
        this.circularBuffer = null;
        this.bufferDuration = 5; // Default 5 seconds
        this.chunkSize = 4096; // Default chunk size
        this.sequenceId = 0; // Used for tracking chunks
        this.overflowCount = 0;
        this.currentAudioLevel = 0;
        this.config = {
            sampleRate: 16000,
            channels: 1,
            encoding: 'signed-integer',
            silence: '1.0',
            endOnSilence: false,
            thresholdStart: 0.5,
            thresholdEnd: 0.5,
            verbose: false
        };
        // Pre-load the recording module for faster startup
        this.preloadRecordingModule();
    }
    /**
     * Pre-load the node-record-lpcm16 module to avoid dynamic import delay during recording
     */
    async preloadRecordingModule() {
        try {
            const { createRequire } = await import('module');
            const require = createRequire(import.meta.url);
            this.recordModule = require('node-record-lpcm16');
            this.moduleLoaded = true;
        }
        catch (error) {
            console.warn('Failed to pre-load recording module, will load dynamically:', error);
            this.moduleLoaded = false;
        }
    }
    /**
     * Start audio recording
     */
    async start(options = {}) {
        if (this.isRecording) {
            throw new Error('Recording already in progress');
        }
        try {
            // Use pre-loaded module if available, otherwise load dynamically
            let record = this.recordModule;
            if (!this.moduleLoaded || !record) {
                console.warn('Recording module not pre-loaded, loading dynamically...');
                const { createRequire } = await import('module');
                const require = createRequire(import.meta.url);
                record = require('node-record-lpcm16');
            }
            this.audioBuffer = [];
            this.audioLevels = [];
            this.isRecording = true;
            this.startTime = Date.now();
            // Optimize config for faster startup
            const optimizedConfig = {
                ...this.config,
                silence: '0.1', // Reduce silence detection time from 1.0s to 0.1s
                threshold: 0, // Disable threshold for immediate start
                endOnSilence: false
            };
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            this.recorder = record.record(optimizedConfig);
            if (!this.recorder) {
                throw new Error('Failed to initialize audio recorder');
            }
            this.recorder.stream().on('data', (chunk) => {
                this.audioBuffer.push(chunk);
                // Calculate audio level for visualization
                const level = this.calculateAmplitude(chunk);
                this.audioLevels.push(level);
                this.emit('audioData', {
                    chunk,
                    level,
                    duration: this.getRecordingDuration()
                });
            });
            if (this.recorder) {
                this.recorder.stream().on('error', (error) => {
                    this.handleRecordingError(error);
                });
            }
            this.emit('recordingStarted');
            // Set up maximum duration limit
            if (options.maxDuration) {
                setTimeout(() => {
                    if (this.isRecording) {
                        this.stop();
                        this.emit('maxDurationReached');
                    }
                }, options.maxDuration * 1000);
            }
        }
        catch (error) {
            this.handleRecordingError(error);
        }
    }
    /**
     * Stop audio recording
     */
    stop() {
        if (!this.isRecording || !this.recorder) {
            return null;
        }
        try {
            this.recorder.stop();
            this.isRecording = false;
            const audioData = Buffer.concat(this.audioBuffer);
            const duration = this.getRecordingDuration();
            this.emit('recordingStopped', {
                audioData,
                duration,
                audioLevels: this.audioLevels
            });
            this.cleanup();
            return audioData;
        }
        catch (error) {
            this.handleRecordingError(error);
            return null;
        }
    }
    /**
     * Cancel current recording
     */
    cancel() {
        if (!this.isRecording) {
            return;
        }
        try {
            if (this.recorder) {
                this.recorder.stop();
            }
            this.isRecording = false;
            this.emit('recordingCancelled');
            this.cleanup();
        }
        catch (error) {
            this.handleRecordingError(error);
        }
    }
    /**
     * Check if currently recording
     */
    getIsRecording() {
        return this.isRecording;
    }
    /**
     * Get current recording duration in seconds
     */
    getRecordingDuration() {
        if (!this.startTime)
            return 0;
        return (Date.now() - this.startTime) / 1000;
    }
    /**
     * Calculate audio amplitude for visualization (RMS calculation)
     */
    calculateAmplitude(buffer) {
        if (buffer.length === 0)
            return 0;
        let sum = 0;
        const samples = buffer.length / 2; // 16-bit audio = 2 bytes per sample
        for (let i = 0; i < buffer.length; i += 2) {
            // Read 16-bit signed integer (little endian)
            const sample = buffer.readInt16LE(i);
            sum += sample * sample;
        }
        const rms = Math.sqrt(sum / samples);
        // Improved sensitivity with balanced scaling
        // Normal speech is typically around 1000-5000 RMS, very quiet around 200-500
        const normalizedRms = rms / 32768; // 0-1 range
        // Apply moderate logarithmic scaling and amplification for better sensitivity
        const amplificationFactor = 4.0; // Moderate boost
        const logScaled = normalizedRms > 0 ? Math.log10(normalizedRms * 500 + 1) / 2.7 : 0; // Gentler log scaling
        const amplitude = Math.min(logScaled * amplificationFactor, 1.0);
        // Update current audio level for streaming mode
        this.currentAudioLevel = amplitude;
        return amplitude;
    }
    // Enhanced Recording Service Methods
    /**
     * Set the processing mode (batch or streaming)
     */
    async setProcessingMode(mode) {
        if (this.isRecording || this.isStreaming) {
            throw new Error('Cannot change processing mode while recording or streaming is active');
        }
        const previousMode = this.processingMode;
        this.processingMode = mode;
        this.emit('modeChanged', {
            previousMode,
            currentMode: mode,
            timestamp: Date.now()
        });
    }
    /**
     * Get the current processing mode
     */
    getCurrentMode() {
        return this.processingMode;
    }
    /**
     * Start streaming audio capture with enhanced capabilities
     */
    async startStreaming(options = {}) {
        if (this.processingMode !== ProcessingMode.STREAMING) {
            throw new Error('Cannot start streaming in batch mode. Switch to streaming mode first.');
        }
        if (this.isStreaming) {
            throw new Error('Streaming already in progress');
        }
        try {
            // Use sequential streaming for simpler, more reliable operation
            if (this.useSequentialStreaming) {
                // Create sequential recorder with 10-second chunks
                this.sequentialRecorder = new SequentialStreamingRecorder({
                    chunkDuration: 10000, // 10 seconds
                    sampleRate: this.config.sampleRate,
                    channels: this.config.channels
                });
                // Set up event handlers for sequential chunks
                this.sequentialRecorder.on('chunk', (chunk) => {
                    // Convert to AudioChunk format for compatibility
                    const audioChunk = {
                        data: chunk.data,
                        timestamp: chunk.startTime,
                        sequenceId: chunk.chunkNumber,
                        sampleRate: this.config.sampleRate,
                        channels: this.config.channels,
                        duration: chunk.duration
                    };
                    this.emit('streamingData', audioChunk);
                });
                this.sequentialRecorder.on('error', (error) => {
                    console.error('❌ [RecordingService] Sequential recording error:', error);
                    this.emit('streamingError', error);
                });
                // Start sequential recording
                await this.sequentialRecorder.start();
            }
            else {
                // Legacy complex streaming (keeping for backwards compatibility)
                // Apply streaming options
                if (options.bufferDuration !== undefined) {
                    this.bufferDuration = Math.max(1, Math.min(60, options.bufferDuration));
                }
                if (options.chunkSize !== undefined) {
                    this.chunkSize = options.chunkSize;
                }
                // Create enhanced streaming recorder with advanced options
                const streamingOptions = {
                    ...options,
                    bufferDuration: this.bufferDuration,
                    chunkSize: this.chunkSize,
                    sampleRate: this.config.sampleRate,
                    channels: this.config.channels,
                    continuousMode: true,
                    adaptiveChunkSize: true,
                    qualityMonitoring: true,
                    minChunkSize: 1024,
                    maxChunkSize: 8192
                };
                this.streamingRecorder = new StreamingRecorder(streamingOptions);
                // Set up enhanced event handlers
                this.setupStreamingEventHandlers();
                // Start streaming
                await this.streamingRecorder.start();
            }
            this.isStreaming = true;
            this.startTime = Date.now();
            this.sequenceId = 0;
            this.overflowCount = 0;
            this.emit('streamingStarted', {
                mode: 'streaming',
                bufferDuration: this.bufferDuration,
                chunkSize: this.chunkSize,
                enhancedFeatures: true,
                timestamp: Date.now()
            });
        }
        catch (error) {
            this.handleStreamingError(error);
        }
    }
    /**
     * Stop streaming audio capture with enhanced reporting
     */
    async stopStreaming() {
        if (!this.isStreaming) {
            return;
        }
        try {
            // Stop the appropriate recorder
            if (this.useSequentialStreaming && this.sequentialRecorder) {
                await this.sequentialRecorder.stop();
                this.sequentialRecorder = null;
            }
            else if (this.streamingRecorder) {
                // Get final status before stopping
                const finalStatus = this.streamingRecorder.getStatus();
                await this.streamingRecorder.stop();
                this.streamingRecorder = null;
                // Emit with legacy status
                this.emit('streamingStopped', {
                    duration: this.getRecordingDuration(),
                    finalStatus,
                    enhancedMetrics: true,
                    timestamp: Date.now()
                });
                return;
            }
            this.isStreaming = false;
            // Emit simplified stop event for sequential streaming
            this.emit('streamingStopped', {
                duration: this.getRecordingDuration(),
                enhancedMetrics: false,
                timestamp: Date.now()
            });
            this.cleanupStreaming();
        }
        catch (error) {
            this.handleStreamingError(error);
        }
    }
    /**
     * Check if currently streaming
     */
    getIsStreaming() {
        return this.isStreaming;
    }
    /**
     * Get streaming buffer status
     */
    getBufferStatus() {
        if (!this.circularBuffer) {
            return {
                bufferSize: 0,
                utilization: 0,
                overflowCount: this.overflowCount
            };
        }
        const status = this.circularBuffer.getStatus();
        return {
            bufferSize: status.bufferSize,
            utilization: status.utilization,
            overflowCount: status.overflowCount
        };
    }
    /**
     * Configure streaming buffer parameters
     */
    configureBuffer(bufferDuration, chunkSize) {
        if (this.isStreaming) {
            throw new Error('Cannot configure buffer while streaming is active');
        }
        this.bufferDuration = Math.max(1, Math.min(60, bufferDuration));
        if (chunkSize !== undefined) {
            this.chunkSize = chunkSize;
        }
        // Re-initialize buffer with new configuration if it exists
        if (this.circularBuffer) {
            this.initializeCircularBuffer();
        }
        this.emit('bufferConfigured', {
            bufferDuration: this.bufferDuration,
            chunkSize: this.chunkSize,
            timestamp: Date.now()
        });
    }
    /**
     * Get real-time audio level during streaming
     */
    getCurrentAudioLevel() {
        return this.currentAudioLevel;
    }
    /**
     * Get audio buffer from streaming recorder (most recent chunks)
     */
    getStreamingAudioBuffer(chunkCount) {
        if (this.streamingRecorder) {
            return this.streamingRecorder.getAudioBuffer(chunkCount);
        }
        if (this.circularBuffer) {
            return this.circularBuffer.getAudioBuffer(chunkCount);
        }
        return Buffer.alloc(0);
    }
    /**
     * Get recent audio chunks from streaming recorder
     */
    getRecentAudioChunks(count) {
        if (this.streamingRecorder) {
            return this.streamingRecorder.getRecentChunks(count);
        }
        if (this.circularBuffer) {
            return this.circularBuffer.getRecentChunks(count);
        }
        return [];
    }
    /**
     * Get all audio chunks from streaming recorder
     */
    getAllAudioChunks() {
        if (this.circularBuffer) {
            return this.circularBuffer.getAllChunks();
        }
        return [];
    }
    /**
     * Get detailed buffer statistics
     */
    getDetailedBufferStatus() {
        if (!this.circularBuffer) {
            return null;
        }
        return this.circularBuffer.getStatus();
    }
    /**
     * Get buffer memory usage in bytes
     */
    getBufferMemoryUsage() {
        if (!this.circularBuffer) {
            return 0;
        }
        return this.circularBuffer.getMemoryUsage();
    }
    /**
     * Get enhanced streaming status
     */
    getEnhancedStreamingStatus() {
        if (!this.streamingRecorder) {
            return null;
        }
        return this.streamingRecorder.getStatus();
    }
    /**
     * Update streaming options dynamically
     */
    updateStreamingOptions(options) {
        if (!this.streamingRecorder) {
            throw new Error('No active streaming recorder to update');
        }
        this.streamingRecorder.updateOptions(options);
    }
    /**
     * Setup enhanced streaming event handlers
     */
    setupStreamingEventHandlers() {
        if (!this.streamingRecorder) {
            return;
        }
        // Forward all streaming events from StreamingRecorder
        this.streamingRecorder.on('chunk', (data) => {
            this.sequenceId = data.chunk.sequenceId + 1;
            this.currentAudioLevel = data.qualityMetrics.signalStrength;
            // Emit enhanced chunk event
            this.emit('streaming:chunk', {
                chunk: data.chunk,
                level: data.qualityMetrics.signalStrength,
                qualityMetrics: data.qualityMetrics,
                streamingMetrics: data.streamingMetrics,
                bufferStatus: this.getBufferStatus(),
                duration: this.getRecordingDuration()
            });
        });
        this.streamingRecorder.on('qualityReport', (report) => {
            this.emit('streaming:qualityReport', report);
        });
        this.streamingRecorder.on('qualityWarning', (warning) => {
            this.emit('streaming:qualityWarning', warning);
        });
        this.streamingRecorder.on('chunkSizeAdjusted', (adjustment) => {
            this.chunkSize = adjustment.newSize;
            this.emit('streaming:chunkSizeAdjusted', adjustment);
        });
        this.streamingRecorder.on('bufferOverflow', (overflow) => {
            this.overflowCount++;
            this.emit('streaming:bufferOverflow', overflow);
        });
        this.streamingRecorder.on('configurationPending', (pending) => {
            this.emit('streaming:configurationPending', pending);
        });
        this.streamingRecorder.on('optionsUpdated', (options) => {
            this.emit('streaming:optionsUpdated', options);
        });
        this.streamingRecorder.on('error', (error) => {
            this.handleStreamingError(error);
        });
    }
    /**
     * Handle streaming errors
     */
    handleStreamingError(error) {
        this.isStreaming = false;
        this.cleanupStreaming();
        this.emit('streaming:error', error);
    }
    /**
     * Initialize circular buffer for streaming mode
     */
    initializeCircularBuffer() {
        const bufferOptions = {
            maxSizeSeconds: this.bufferDuration,
            chunkSizeBytes: this.chunkSize,
            sampleRate: this.config.sampleRate,
            channels: this.config.channels,
            autoResize: true
        };
        this.circularBuffer = new CircularBuffer(bufferOptions);
    }
    /**
     * Clean up streaming resources
     */
    cleanupStreaming() {
        if (this.streamingRecorder) {
            this.streamingRecorder.removeAllListeners();
            this.streamingRecorder = null;
        }
        if (this.sequentialRecorder) {
            this.sequentialRecorder.removeAllListeners();
            this.sequentialRecorder = null;
        }
        this.recorder = null;
        this.startTime = null;
        if (this.circularBuffer) {
            this.circularBuffer.clear();
        }
        this.sequenceId = 0;
        this.currentAudioLevel = 0;
    }
    /**
     * Handle recording errors
     */
    handleRecordingError(error) {
        this.isRecording = false;
        this.cleanup();
        this.emit('error', error);
    }
    /**
     * Clean up resources
     */
    cleanup() {
        this.recorder = null;
        this.startTime = null;
        // Keep audioBuffer and audioLevels for potential debugging
    }
}
//# sourceMappingURL=RecordingService.js.map