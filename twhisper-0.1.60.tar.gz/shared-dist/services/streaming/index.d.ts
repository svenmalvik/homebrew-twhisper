/**
 * Streaming Services Module
 *
 * This module provides enhanced transcription services with streaming capabilities:
 * - Real-time audio chunk processing
 * - Progressive transcription with overlap detection
 * - Context-aware result refinement
 * - Backward compatibility with batch processing
 */
export { StreamingTranscriptionService } from './StreamingTranscriptionService.js';
export { ProgressiveTranscriptionManager, type ConsolidatedResult, type ProgressiveSessionStats } from './ProgressiveTranscriptionManager.js';
export { type IStreamingTranscriptionService, type PartialTranscriptionResult, type StreamingTranscriptionOptions, type StreamingContext, type WordTimestamp, type AudioChunk, type ProcessingMode, type StreamingOptions } from '../../interfaces/interfaces.js';
//# sourceMappingURL=index.d.ts.map