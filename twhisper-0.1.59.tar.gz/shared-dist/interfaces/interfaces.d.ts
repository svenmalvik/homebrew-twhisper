import { EventEmitter } from 'events';
import { Mode } from '../types/modes.js';
export declare enum ServiceStatus {
    Stopped = "stopped",
    Starting = "starting",
    Running = "running",
    Error = "error"
}
export interface IService {
    readonly name: string;
    initialize(): Promise<void>;
    shutdown(): Promise<void>;
    getStatus(): ServiceStatus;
    isHealthy(): Promise<boolean>;
}
export declare abstract class IRecordingService extends EventEmitter {
    /**
     * Start audio recording with optional configuration
     */
    abstract start(options?: RecordingOptions): void;
    /**
     * Stop current recording and return audio data
     */
    abstract stop(): Buffer | null;
    /**
     * Cancel current recording without returning data
     */
    abstract cancel(): void;
    /**
     * Check if currently recording
     */
    abstract getIsRecording(): boolean;
    /**
     * Get current recording duration in seconds
     */
    abstract getRecordingDuration(): number;
    /**
     * Calculate audio amplitude for visualization
     */
    abstract calculateAmplitude(buffer: Buffer): number;
}
export interface RecordingOptions {
    maxDuration?: number;
    minDuration?: number;
    sampleRate?: number;
    channels?: number;
}
export declare enum ProcessingMode {
    BATCH = "batch",
    STREAMING = "streaming"
}
export interface StreamingOptions extends RecordingOptions {
    bufferDuration?: number;
    chunkSize?: number;
    overlapDuration?: number;
}
export interface AudioChunk {
    data: Buffer;
    timestamp: number;
    sequenceId: number;
    sampleRate: number;
    channels: number;
    duration: number;
}
export declare abstract class IEnhancedRecordingService extends IRecordingService {
    /**
     * Set the processing mode (batch or streaming)
     */
    abstract setProcessingMode(mode: ProcessingMode): Promise<void>;
    /**
     * Get the current processing mode
     */
    abstract getCurrentMode(): ProcessingMode;
    /**
     * Start streaming audio capture
     */
    abstract startStreaming(options?: StreamingOptions): Promise<void>;
    /**
     * Stop streaming audio capture
     */
    abstract stopStreaming(): Promise<void>;
    /**
     * Check if currently streaming
     */
    abstract getIsStreaming(): boolean;
    /**
     * Get streaming buffer status
     */
    abstract getBufferStatus(): {
        bufferSize: number;
        utilization: number;
        overflowCount: number;
    };
    /**
     * Configure streaming buffer parameters
     */
    abstract configureBuffer(bufferDuration: number, chunkSize?: number): void;
    /**
     * Get real-time audio level during streaming
     */
    abstract getCurrentAudioLevel(): number;
}
export declare abstract class ITranscriptionService extends EventEmitter {
    /**
     * Transcribe audio buffer to text
     */
    abstract transcribe(audioBuffer: Buffer, options?: TranscriptionOptions): Promise<TranscriptionResult>;
    /**
     * Check service availability and configuration
     */
    abstract checkAvailability(): Promise<boolean>;
    /**
     * Get supported audio formats
     */
    abstract getSupportedFormats(): string[];
    /**
     * Transcribe audio with retry logic
     */
    abstract transcribeWithRetry(audioBuffer: Buffer, options?: TranscriptionOptions, maxRetries?: number): Promise<TranscriptionResult>;
}
export interface TranscriptionOptions {
    language?: string;
    temperature?: number;
    prompt?: string;
}
export interface TranscriptionResult {
    text: string;
    confidence?: number;
    language?: string;
    duration: number;
    wordCount: number;
    segments?: TranscriptionSegment[];
}
export interface TranscriptionSegment {
    id: number;
    seek: number;
    start: number;
    end: number;
    text: string;
    temperature: number;
    avgLogProb: number;
    compressionRatio: number;
    noSpeechProb: number;
}
export interface PartialTranscriptionResult {
    text: string;
    confidence: number;
    isComplete: boolean;
    timestamp: number;
    sequenceId: number;
    wordTimestamps?: WordTimestamp[];
}
export interface WordTimestamp {
    word: string;
    start: number;
    end: number;
    confidence: number;
}
export interface StreamingTranscriptionOptions extends TranscriptionOptions {
    enableWordTimestamps?: boolean;
    enablePartialResults?: boolean;
    minConfidenceThreshold?: number;
    contextWindow?: number;
}
export declare abstract class IStreamingTranscriptionService extends ITranscriptionService {
    /**
     * Process a single audio chunk and return partial transcription
     */
    abstract processChunk(audioChunk: AudioChunk, options?: StreamingTranscriptionOptions): Promise<PartialTranscriptionResult>;
    /**
     * Start a streaming transcription session
     */
    abstract startStreamingSession(options?: StreamingTranscriptionOptions): Promise<string>;
    /**
     * End a streaming transcription session and get final result
     */
    abstract endStreamingSession(sessionId: string): Promise<TranscriptionResult>;
    /**
     * Process multiple chunks in sequence with context preservation
     */
    abstract processChunkSequence(chunks: AudioChunk[], sessionId: string, options?: StreamingTranscriptionOptions): Promise<PartialTranscriptionResult[]>;
    /**
     * Get current streaming context for a session
     */
    abstract getStreamingContext(sessionId: string): StreamingContext | null;
    /**
     * Update streaming configuration during active session
     */
    abstract updateStreamingConfig(sessionId: string, config: Partial<StreamingTranscriptionOptions>): Promise<void>;
}
export interface StreamingContext {
    sessionId: string;
    startTime: number;
    lastChunkTime: number;
    processedChunks: number;
    accumulatedText: string;
    averageConfidence: number;
    contextWindow: AudioChunk[];
    options: StreamingTranscriptionOptions;
}
export declare abstract class IFormattingService extends EventEmitter {
    /**
     * Format transcribed text using specified mode
     */
    abstract format(text: string, mode: Mode, options?: FormattingOptions): Promise<FormattingResult>;
    /**
     * Check service availability and configuration
     */
    abstract checkAvailability(): Promise<boolean>;
    /**
     * Get available models
     */
    abstract getAvailableModels(): string[];
    /**
     * Format text with retry logic
     */
    abstract formatWithRetry(text: string, mode: Mode, options?: FormattingOptions, maxRetries?: number): Promise<FormattingResult>;
}
export interface FormattingOptions {
    maxTokens?: number;
    temperature?: number;
    customPrompt?: string;
}
export interface FormattingResult {
    formattedText: string;
    originalText: string;
    mode: string;
    tokensUsed: number;
    model: string;
    confidence?: number;
    processingTime: number;
}
export declare abstract class IClipboardService {
    /**
     * Write text to clipboard
     */
    abstract write(text: string): Promise<boolean>;
    /**
     * Read text from clipboard
     */
    abstract read(): Promise<string>;
    /**
     * Check if clipboard is available
     */
    abstract isAvailable(): Promise<boolean>;
    /**
     * Clear clipboard contents
     */
    abstract clear(): Promise<boolean>;
    /**
     * Write text to clipboard with confirmation and retry logic
     */
    abstract writeWithConfirmation(text: string, maxRetries?: number): Promise<{
        success: boolean;
        wordCount: number;
        preview: string;
    }>;
}
export declare abstract class IConfigurationService {
    /**
     * Load configuration from environment and files
     */
    abstract load(): Promise<Configuration>;
    /**
     * Validate configuration completeness and correctness
     */
    abstract validate(config: Configuration): ValidationResult;
    /**
     * Get configuration value by key
     */
    abstract get<T>(key: string): T | undefined;
    /**
     * Set configuration value
     */
    abstract set<T>(key: string, value: T): void;
    /**
     * Save configuration to file
     */
    abstract save(): Promise<boolean>;
    /**
     * Get the current configuration (read-only)
     */
    abstract getConfiguration(): Configuration | null;
    /**
     * Persist processing mode change to config file
     */
    abstract persistProcessingMode(mode: ProcessingMode): Promise<void>;
    /**
     * Persist language change to config file
     */
    abstract persistLanguage(language: string): Promise<void>;
    /**
     * Persist formatting mode change to config file
     */
    abstract persistMode(mode: string): Promise<void>;
}
export interface Configuration {
    azureOpenAI: {
        apiKey: string;
        endpoint: string;
        apiVersion: string;
        whisperDeployment: string;
        gptDeployment: string;
    };
    auth: {
        enabled: boolean;
        requireForStreaming: boolean;
        supabaseUrl: string;
        supabaseAnonKey: string;
    };
    app: {
        defaultMode: string;
        defaultProcessingMode: ProcessingMode;
        autoCopy: boolean;
        useLocalWhisper: boolean;
        debug: boolean;
    };
    audio: {
        sampleRate: number;
        channels: number;
        encoding: string;
    };
    whisper: {
        modelSize: 'tiny' | 'tiny.en' | 'base' | 'base.en' | 'small' | 'small.en' | 'medium' | 'medium.en';
        useGPU: boolean;
        language: 'en' | 'no' | 'da' | 'fi';
    };
    ui: {
        theme: 'light' | 'dark' | 'auto';
        showWaveform: boolean;
        showProgress: boolean;
        refreshRate: number;
    };
}
export interface ValidationResult {
    valid: boolean;
    errors: ValidationError[];
    warnings: ValidationWarning[];
}
export interface ValidationError {
    field: string;
    message: string;
    code: string;
}
export interface ValidationWarning {
    field: string;
    message: string;
    suggestion?: string;
}
export declare abstract class IFileService {
    /**
     * Create temporary file for audio data
     */
    abstract createTempFile(extension: string, data?: Buffer): Promise<string>;
    /**
     * Delete temporary file
     */
    abstract deleteTempFile(filePath: string): Promise<boolean>;
    /**
     * Clean up all temporary files
     */
    abstract cleanupTempFiles(): Promise<number>;
    /**
     * Check if file exists
     */
    abstract exists(filePath: string): Promise<boolean>;
    /**
     * Read file as buffer
     */
    abstract readFile(filePath: string): Promise<Buffer>;
    /**
     * Write buffer to file
     */
    abstract writeFile(filePath: string, data: Buffer): Promise<boolean>;
    /**
     * Get the current temporary directory path
     */
    abstract getTempDir(): string;
    /**
     * Create a temporary WAV file with proper audio headers
     */
    abstract createTempWavFile(audioBuffer: Buffer, sampleRate?: number, channels?: number): Promise<string>;
}
export interface ServiceFactory {
    createRecordingService(): IRecordingService;
    createTranscriptionService(): ITranscriptionService;
    createFormattingService(): IFormattingService;
    createClipboardService(): IClipboardService;
    createConfigurationService(): IConfigurationService;
    createFileService(): IFileService;
}
export interface SubscriptionStatus {
    status?: 'starter' | 'active' | 'canceled' | 'past_due' | 'unpaid';
    tier: 'starter' | 'professional' | 'enterprise' | string;
    expiresAt?: Date;
    customerId?: string;
    isActive: boolean;
    canUseStreaming: boolean;
    maxRecordingMinutes: number;
    cacheAge?: number;
    isStale?: boolean;
    lastUpdated?: Date;
    tierUpdatedAt?: Date;
}
export interface SubscriptionUpgradeResult {
    success: boolean;
    subscriptionId?: string;
    message?: string;
}
export interface ISubscriptionService extends IService {
    getSubscriptionStatus(): Promise<SubscriptionStatus>;
    upgradeSubscription(plan: string): Promise<SubscriptionUpgradeResult>;
    cancelSubscription(): Promise<void>;
    setCurrentUser(user: {
        id: string;
        email: string;
        name: string;
    } | null): void;
    getMaxRecordingDuration(): Promise<number>;
    canUseStreamingMode(): Promise<boolean>;
}
export interface ServiceContainer {
    recording: IRecordingService;
    transcription: ITranscriptionService;
    formatting: IFormattingService;
    clipboard: IClipboardService;
    configuration: IConfigurationService;
    file: IFileService;
    subscription: ISubscriptionService;
}
export declare abstract class IServiceManager {
    /**
     * Initialize all services
     */
    abstract initialize(): Promise<ServiceContainer>;
    /**
     * Shutdown all services gracefully
     */
    abstract shutdown(): Promise<void>;
    /**
     * Health check for all services
     */
    abstract healthCheck(): Promise<ServiceHealthStatus>;
    /**
     * Get service container
     */
    abstract getServices(): ServiceContainer;
}
export interface ServiceHealthStatus {
    overall: 'healthy' | 'degraded' | 'unhealthy';
    services: {
        [serviceName: string]: {
            status: 'healthy' | 'degraded' | 'unhealthy';
            message?: string;
            lastCheck: Date;
        };
    };
}
//# sourceMappingURL=interfaces.d.ts.map