import { IServiceManager, ServiceContainer, ServiceHealthStatus } from '../interfaces/interfaces.js';
import { ModeRegistryImpl } from '../types/modes.js';
export declare class ServiceManager extends IServiceManager {
    private services;
    private isInitialized;
    private modeRegistry;
    constructor();
    initialize(): Promise<ServiceContainer>;
    shutdown(): Promise<void>;
    healthCheck(): Promise<ServiceHealthStatus>;
    private checkRecordingService;
    private checkTranscriptionService;
    private checkFormattingService;
    private checkClipboardService;
    private checkFileService;
    getServices(): ServiceContainer;
    /**
     * Get the mode registry for managing modes
     */
    getModeRegistry(): ModeRegistryImpl;
    /**
     * Check if services are initialized
     */
    isReady(): boolean;
}
//# sourceMappingURL=ServiceManager.d.ts.map