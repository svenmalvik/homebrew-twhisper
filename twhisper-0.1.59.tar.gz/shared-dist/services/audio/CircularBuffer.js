export class CircularBuffer {
    constructor(options) {
        this.writeIndex = 0;
        this.overflowCount = 0;
        this.totalChunksProcessed = 0;
        this.totalBytesProcessed = 0;
        this.options = {
            ...options,
            autoResize: options.autoResize ?? false
        };
        this.maxSize = this.calculateMaxSize();
        this.buffer = new Array(this.maxSize);
    }
    /**
     * Calculate maximum buffer size based on duration and audio parameters
     */
    calculateMaxSize() {
        const { maxSizeSeconds, chunkSizeBytes, sampleRate, channels } = this.options;
        const bytesPerSecond = sampleRate * channels * 2; // 16-bit audio = 2 bytes per sample
        const chunksPerSecond = bytesPerSecond / chunkSizeBytes;
        return Math.ceil(maxSizeSeconds * chunksPerSecond);
    }
    /**
     * Add an audio chunk to the circular buffer
     */
    push(chunk) {
        if (!chunk || !chunk.data) {
            return false;
        }
        // Handle overflow - remove oldest chunk
        if (this.isFull()) {
            this.overflowCount++;
            // Auto-resize if enabled and we're consistently overflowing
            if (this.options.autoResize && this.overflowCount % 10 === 0) {
                this.resize(Math.floor(this.maxSize * 1.2));
            }
        }
        // Add chunk to buffer
        this.buffer[this.writeIndex] = chunk;
        this.writeIndex = (this.writeIndex + 1) % this.maxSize;
        // Update statistics
        this.totalChunksProcessed++;
        this.totalBytesProcessed += chunk.data.length;
        return true;
    }
    /**
     * Get the most recent N chunks from the buffer
     */
    getRecentChunks(count) {
        const chunks = [];
        let index = (this.writeIndex - 1 + this.maxSize) % this.maxSize;
        for (let i = 0; i < Math.min(count, this.size()); i++) {
            const chunk = this.buffer[index];
            if (chunk) {
                chunks.unshift(chunk); // Add to beginning to maintain chronological order
            }
            index = (index - 1 + this.maxSize) % this.maxSize;
        }
        return chunks;
    }
    /**
     * Get all chunks within a time range (in milliseconds)
     */
    getChunksInTimeRange(startTime, endTime) {
        const chunks = [];
        const allChunks = this.getAllChunks();
        for (const chunk of allChunks) {
            if (chunk.timestamp >= startTime && chunk.timestamp <= endTime) {
                chunks.push(chunk);
            }
        }
        return chunks.sort((a, b) => a.timestamp - b.timestamp);
    }
    /**
     * Get all valid chunks in chronological order
     */
    getAllChunks() {
        const chunks = [];
        const currentSize = this.size();
        if (currentSize === 0)
            return chunks;
        // Start from oldest chunk
        const startIndex = this.isFull() ? this.writeIndex : 0;
        for (let i = 0; i < currentSize; i++) {
            const index = (startIndex + i) % this.maxSize;
            const chunk = this.buffer[index];
            if (chunk) {
                chunks.push(chunk);
            }
        }
        return chunks;
    }
    /**
     * Get audio data as a concatenated buffer from recent chunks
     */
    getAudioBuffer(chunkCount) {
        const chunks = chunkCount ? this.getRecentChunks(chunkCount) : this.getAllChunks();
        if (chunks.length === 0) {
            return Buffer.alloc(0);
        }
        return Buffer.concat(chunks.map(chunk => chunk.data));
    }
    /**
     * Clear the buffer and reset counters
     */
    clear() {
        this.buffer = new Array(this.maxSize);
        this.writeIndex = 0;
        this.overflowCount = 0;
        this.totalChunksProcessed = 0;
        this.totalBytesProcessed = 0;
    }
    /**
     * Get buffer status and statistics
     */
    getStatus() {
        const currentSize = this.size();
        const chunks = currentSize > 0 ? this.getAllChunks() : [];
        return {
            bufferSize: this.maxSize,
            utilization: currentSize / this.maxSize,
            overflowCount: this.overflowCount,
            totalChunks: this.totalChunksProcessed,
            totalBytesProcessed: this.totalBytesProcessed,
            averageChunkSize: this.totalChunksProcessed > 0 ? this.totalBytesProcessed / this.totalChunksProcessed : 0,
            oldestTimestamp: chunks.length > 0 ? chunks[0].timestamp : null,
            newestTimestamp: chunks.length > 0 ? chunks[chunks.length - 1].timestamp : null
        };
    }
    /**
     * Configure buffer parameters (can only be done when buffer is empty)
     */
    configure(options) {
        if (this.size() > 0) {
            return false; // Cannot reconfigure while buffer has data
        }
        // Update options
        this.options = { ...this.options, ...options };
        // Recalculate max size if relevant parameters changed
        if (options.maxSizeSeconds || options.chunkSizeBytes || options.sampleRate || options.channels) {
            const newMaxSize = this.calculateMaxSize();
            this.resize(newMaxSize);
        }
        return true;
    }
    /**
     * Resize the buffer (preserving existing data if possible)
     */
    resize(newMaxSize) {
        if (newMaxSize <= 0) {
            return false;
        }
        const existingChunks = this.getAllChunks();
        this.maxSize = newMaxSize;
        this.buffer = new Array(newMaxSize);
        this.writeIndex = 0;
        // Re-add existing chunks (up to new capacity)
        const chunksToKeep = existingChunks.slice(-newMaxSize);
        for (const chunk of chunksToKeep) {
            this.buffer[this.writeIndex] = chunk;
            this.writeIndex++;
        }
        return true;
    }
    /**
     * Check if buffer is full
     */
    isFull() {
        return this.size() >= this.maxSize;
    }
    /**
     * Get current number of chunks in buffer
     */
    size() {
        if (this.totalChunksProcessed === 0) {
            return 0;
        }
        return Math.min(this.totalChunksProcessed, this.maxSize);
    }
    /**
     * Get maximum buffer capacity
     */
    capacity() {
        return this.maxSize;
    }
    /**
     * Check if buffer is empty
     */
    isEmpty() {
        return this.size() === 0;
    }
    /**
     * Get buffer configuration
     */
    getOptions() {
        return { ...this.options };
    }
    /**
     * Estimate memory usage in bytes
     */
    getMemoryUsage() {
        const chunks = this.getAllChunks();
        return chunks.reduce((total, chunk) => total + chunk.data.length, 0);
    }
}
//# sourceMappingURL=CircularBuffer.js.map