/**
 * Subscription-related types for Twhisper
 */
export interface SubscriptionPlan {
    id: string;
    name: string;
    price: number;
    currency: string;
    features: string[];
    maxRecordingMinutes: number;
    allowsStreaming: boolean;
}
export interface SubscriptionSession {
    sessionToken: string;
    userId: string;
    checkoutSessionId?: string;
    expiresAt: Date;
    createdAt: Date;
    completedAt?: Date;
}
export interface WebhookEvent {
    id: string;
    stripeEventId: string;
    eventType: string;
    processedAt: Date;
    retryCount: number;
}
export declare const SUBSCRIPTION_PLANS: Record<string, SubscriptionPlan>;
export type SubscriptionStatus = 'starter' | 'active' | 'canceled' | 'past_due' | 'unpaid';
export interface UserSubscription {
    userId: string;
    stripeCustomerId?: string;
    status: SubscriptionStatus;
    currentPlan: keyof typeof SUBSCRIPTION_PLANS;
    tier: string;
    tierUpdatedAt: Date;
    expiresAt?: Date;
    updatedAt: Date;
}
export declare const SUBSCRIPTION_ERRORS: {
    readonly AUTHENTICATION_REQUIRED: "User must be authenticated to manage subscription";
    readonly SUBSCRIPTION_NOT_FOUND: "No subscription found for user";
    readonly PAYMENT_FAILED: "Payment processing failed";
    readonly CHECKOUT_SESSION_FAILED: "Failed to create checkout session";
    readonly PORTAL_SESSION_FAILED: "Failed to create customer portal session";
    readonly INVALID_SESSION_TOKEN: "Invalid or expired session token";
    readonly WEBHOOK_VERIFICATION_FAILED: "Webhook signature verification failed";
};
//# sourceMappingURL=subscription.d.ts.map