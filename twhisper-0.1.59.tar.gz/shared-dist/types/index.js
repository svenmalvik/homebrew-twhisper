// Application states
export var AppState;
(function (AppState) {
    AppState["IDLE"] = "idle";
    AppState["RECORDING"] = "recording";
    AppState["TRANSCRIBING"] = "transcribing";
    AppState["FORMATTING"] = "formatting";
    AppState["COMPLETE"] = "complete";
    AppState["ERROR"] = "error";
    // Streaming states
    AppState["STREAMING"] = "streaming";
    AppState["STREAMING_PAUSED"] = "streaming_paused";
    AppState["STREAMING_STOPPING"] = "streaming_stopping";
    AppState["PROCESSING_CHUNK"] = "processing_chunk";
})(AppState || (AppState = {}));
// Error codes
export var ErrorCode;
(function (ErrorCode) {
    // General errors
    ErrorCode["UNKNOWN_ERROR"] = "unknown_error";
    ErrorCode["INVALID_INPUT"] = "invalid_input";
    ErrorCode["SERVICE_NOT_INITIALIZED"] = "service_not_initialized";
    // Configuration errors
    ErrorCode["CONFIGURATION_ERROR"] = "configuration_error";
    ErrorCode["AUTHENTICATION_ERROR"] = "authentication_error";
    ErrorCode["STREAMING_AUTHENTICATION_REQUIRED"] = "streaming_authentication_required";
    // Network errors
    ErrorCode["NETWORK_ERROR"] = "network_error";
    ErrorCode["SERVICE_UNAVAILABLE"] = "service_unavailable";
    ErrorCode["RATE_LIMIT_EXCEEDED"] = "rate_limit_exceeded";
    // Recording errors
    ErrorCode["RECORDING_ERROR"] = "recording_error";
    ErrorCode["MICROPHONE_ACCESS_DENIED"] = "microphone_access_denied";
    // Transcription errors
    ErrorCode["TRANSCRIPTION_FAILED"] = "transcription_failed";
    ErrorCode["INVALID_AUDIO_FORMAT"] = "invalid_audio_format";
    // Formatting errors
    ErrorCode["FORMATTING_FAILED"] = "formatting_failed";
    ErrorCode["CONTENT_POLICY_VIOLATION"] = "content_policy_violation";
    // File operations
    ErrorCode["FILE_OPERATION_ERROR"] = "file_operation_error";
    ErrorCode["TEMP_FILE_CREATION_FAILED"] = "temp_file_creation_failed";
    // Clipboard errors
    ErrorCode["CLIPBOARD_ERROR"] = "clipboard_error";
    ErrorCode["CLIPBOARD_ACCESS_DENIED"] = "clipboard_access_denied";
    // Streaming errors
    ErrorCode["STREAMING_SESSION_NOT_FOUND"] = "streaming_session_not_found";
    ErrorCode["STREAMING_CONTEXT_ERROR"] = "streaming_context_error";
    // Subscription errors
    ErrorCode["SUBSCRIPTION_ERROR"] = "subscription_error";
    ErrorCode["SUBSCRIPTION_REQUIRED"] = "subscription_required";
    ErrorCode["AUTHENTICATION_REQUIRED"] = "authentication_required";
    ErrorCode["SERVICE_INITIALIZATION_FAILED"] = "service_initialization_failed";
})(ErrorCode || (ErrorCode = {}));
// Error types (legacy)
export var ErrorType;
(function (ErrorType) {
    ErrorType["RECORDING_ERROR"] = "recording_error";
    ErrorType["TRANSCRIPTION_ERROR"] = "transcription_error";
    ErrorType["FORMATTING_ERROR"] = "formatting_error";
    ErrorType["CLIPBOARD_ERROR"] = "clipboard_error";
    ErrorType["NETWORK_ERROR"] = "network_error";
    ErrorType["CONFIGURATION_ERROR"] = "configuration_error";
    ErrorType["VALIDATION_ERROR"] = "validation_error";
})(ErrorType || (ErrorType = {}));
// Application error class
export class AppError extends Error {
    constructor(message, code, details) {
        super(message);
        this.name = 'AppError';
        this.code = code;
        this.details = details;
        this.timestamp = new Date();
        // Maintains proper stack trace for where our error was thrown (only available on V8)
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, AppError);
        }
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            code: this.code,
            details: this.details,
            timestamp: this.timestamp,
            stack: this.stack
        };
    }
}
//# sourceMappingURL=index.js.map