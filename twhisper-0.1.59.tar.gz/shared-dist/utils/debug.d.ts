/**
 * Debug logging utility
 */
/**
 * Log debug messages only when DEBUG environment variable is explicitly set to 'true'
 */
export declare function debugLog(message: string, ...args: unknown[]): void;
/**
 * Log info messages that should always be visible in production
 */
export declare function infoLog(message: string, ...args: unknown[]): void;
/**
 * Log error messages that should always be visible
 */
export declare function errorLog(message: string, ...args: unknown[]): void;
//# sourceMappingURL=debug.d.ts.map