/**
 * Subscription-related types for Twhisper
 */
export const SUBSCRIPTION_PLANS = {
    STARTER: {
        id: 'starter',
        name: 'Starter',
        price: 0,
        currency: 'EUR',
        features: [
            'Up to 1-minute recordings',
            'All formatting modes',
            'Batch processing',
            'Community support'
        ],
        maxRecordingMinutes: 1,
        allowsStreaming: false
    },
    PROFESSIONAL: {
        id: 'professional',
        name: 'Professional',
        price: 9,
        currency: 'EUR',
        features: [
            'Up to 10-minute recordings',
            'Real-time streaming mode',
            'Custom formatting modes',
            'Priority support',
            'Revision history',
            'Secure backup'
        ],
        maxRecordingMinutes: 10,
        allowsStreaming: true
    }
};
export const SUBSCRIPTION_ERRORS = {
    AUTHENTICATION_REQUIRED: 'User must be authenticated to manage subscription',
    SUBSCRIPTION_NOT_FOUND: 'No subscription found for user',
    PAYMENT_FAILED: 'Payment processing failed',
    CHECKOUT_SESSION_FAILED: 'Failed to create checkout session',
    PORTAL_SESSION_FAILED: 'Failed to create customer portal session',
    INVALID_SESSION_TOKEN: 'Invalid or expired session token',
    WEBHOOK_VERIFICATION_FAILED: 'Webhook signature verification failed'
};
//# sourceMappingURL=subscription.js.map