import { EventEmitter } from 'events';
import { randomUUID } from 'crypto';
import { exec } from 'child_process';
import { promisify } from 'util';
import { ServiceStatus } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
const execAsync = promisify(exec);
export class SubscriptionService extends EventEmitter {
    constructor(configService) {
        super();
        this.name = 'SubscriptionService';
        this.status = ServiceStatus.Stopped;
        this.currentUser = null;
        this.configService = configService;
        this.supabaseUrl = process.env.SUPABASE_TWHISPER_URL || 'https://abhhnwiajhoncpqamrcj.supabase.co';
        this.supabaseKey = process.env.SUPABASE_TWHISPER_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiaGhud2lhamhvbmNwcWFtcmNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc2MDMwMTgsImV4cCI6MjA3MzE3OTAxOH0.jFpxWu6iRAFaH8jzCw82UTUa61aVTzVIAHGRZCg_Ee4';
    }
    async initialize() {
        try {
            this.status = ServiceStatus.Starting;
            if (!this.supabaseUrl || !this.supabaseKey) {
                throw new AppError('Missing Supabase configuration for subscription service', ErrorCode.SERVICE_INITIALIZATION_FAILED);
            }
            this.status = ServiceStatus.Running;
            this.emit('statusChanged', this.status);
        }
        catch (error) {
            this.status = ServiceStatus.Error;
            this.emit('error', error);
            throw error;
        }
    }
    async shutdown() {
        this.status = ServiceStatus.Stopped;
        this.emit('statusChanged', this.status);
    }
    getStatus() {
        return this.status;
    }
    async isHealthy() {
        return this.status === ServiceStatus.Running;
    }
    setCurrentUser(user) {
        this.currentUser = user;
    }
    /**
     * Get current user's subscription status using cached API with fallback
     */
    async getSubscriptionStatus() {
        if (!this.currentUser) {
            return this.getStarterSubscriptionStatus();
        }
        try {
            // First try the optimized subscription status API (uses database cache)
            const cachedStatus = await this.getSubscriptionStatusFromAPI();
            if (cachedStatus) {
                return cachedStatus;
            }
            // Fallback to direct database query if API fails
            console.warn('Subscription API unavailable, falling back to direct database query');
            return await this.getSubscriptionStatusDirect();
        }
        catch (error) {
            console.warn('Error fetching subscription status:', error);
            return this.getStarterSubscriptionStatus();
        }
    }
    /**
     * Get subscription status from the cached API endpoint
     */
    async getSubscriptionStatusFromAPI() {
        try {
            const response = await fetch(`${this.supabaseUrl}/functions/v1/stripe-webhook/subscription-status?user_id=${this.currentUser?.id}`, {
                headers: {
                    'Authorization': `Bearer ${this.supabaseKey}`,
                    'Content-Type': 'application/json'
                }
            });
            if (!response.ok) {
                if (response.status === 404) {
                    // User not found - return free status
                    return this.getStarterSubscriptionStatus();
                }
                throw new Error(`API returned ${response.status}`);
            }
            const data = await response.json();
            const status = data.subscription_status || 'starter';
            const tier = data.subscription_tier || 'starter';
            const isActive = tier === 'professional';
            const expiresAt = data.subscription_expires_at ? new Date(data.subscription_expires_at) : undefined;
            const lastUpdated = data.last_updated ? new Date(data.last_updated) : undefined;
            return {
                status: status,
                tier: tier,
                expiresAt,
                customerId: data.has_stripe_customer ? 'hidden' : undefined, // Don't expose full customer ID
                isActive,
                canUseStreaming: isActive,
                maxRecordingMinutes: this.getMaxRecordingMinutesForTier(tier),
                cacheAge: data.cache_age_hours,
                isStale: data.is_stale,
                lastUpdated
            };
        }
        catch (error) {
            console.debug('Subscription API error:', error instanceof Error ? error.message : String(error));
            return null;
        }
    }
    /**
     * Direct database query fallback (legacy method)
     */
    async getSubscriptionStatusDirect() {
        try {
            // Query user's subscription data directly from Supabase
            const response = await fetch(`${this.supabaseUrl}/rest/v1/users?id=eq.${this.currentUser?.id}&select=*`, {
                headers: {
                    'apikey': this.supabaseKey,
                    'Authorization': `Bearer ${this.supabaseKey}`,
                    'Content-Type': 'application/json'
                }
            });
            if (!response.ok) {
                console.warn('Failed to fetch subscription status, using starter tier');
                return this.getStarterSubscriptionStatus();
            }
            const users = await response.json();
            const user = users?.[0];
            if (!user || (!user.subscription_status && !user.subscription_tier)) {
                return this.getStarterSubscriptionStatus();
            }
            const status = user.subscription_status || 'starter';
            const tier = user.subscription_tier || 'starter';
            const isActive = tier === 'professional';
            const expiresAt = user.subscription_expires_at ? new Date(user.subscription_expires_at) : undefined;
            const lastUpdated = user.subscription_updated_at ? new Date(user.subscription_updated_at) : undefined;
            const tierUpdatedAt = user.subscription_tier_updated_at ? new Date(user.subscription_tier_updated_at) : undefined;
            return {
                status: status,
                tier: tier,
                expiresAt,
                customerId: user.stripe_customer_id,
                isActive,
                canUseStreaming: isActive,
                maxRecordingMinutes: this.getMaxRecordingMinutesForTier(tier),
                lastUpdated,
                tierUpdatedAt
            };
        }
        catch (error) {
            console.warn('Direct database query failed:', error);
            return this.getStarterSubscriptionStatus();
        }
    }
    /**
     * Check if user can use professional features with server-side validation
     */
    async canUseProfessionalFeatures() {
        const subscription = await this.getSubscriptionStatus();
        // If cache is stale, we should be more restrictive for premium features
        if (subscription.isStale && subscription.cacheAge && subscription.cacheAge > 48) {
            console.warn('Subscription cache is very stale, restricting professional features');
            return false;
        }
        return subscription.isActive;
    }
    /**
     * Check if user can use streaming mode
     */
    async canUseStreamingMode() {
        const subscription = await this.getSubscriptionStatus();
        return subscription.canUseStreaming;
    }
    /**
     * Get maximum recording duration for current user
     */
    async getMaxRecordingDuration() {
        const subscription = await this.getSubscriptionStatus();
        return subscription.maxRecordingMinutes;
    }
    /**
     * Upgrade user to professional tier instantly (no payment required during free period)
     */
    async upgradeToProfessionalTier() {
        if (!this.currentUser) {
            throw new AppError('User must be authenticated to upgrade to professional tier', ErrorCode.AUTHENTICATION_REQUIRED);
        }
        try {
            // Use Edge Function for secure tier upgrade with proper authentication
            const response = await fetch(`${this.supabaseUrl}/functions/v1/stripe-webhook/upgrade-tier`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.supabaseKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_id: this.currentUser.id,
                    tier: 'professional'
                })
            });
            if (!response.ok) {
                const error = await response.text();
                throw new AppError(`Failed to upgrade to professional tier: ${error}`, ErrorCode.SUBSCRIPTION_ERROR);
            }
            console.log('✅ Successfully upgraded to Professional tier!');
        }
        catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError(`Professional tier upgrade failed: ${error instanceof Error ? error.message : 'Unknown error'}`, ErrorCode.SUBSCRIPTION_ERROR);
        }
    }
    /**
     * Generate session token and initiate subscription upgrade flow (for future paid tiers)
     */
    async initiateSubscriptionUpgrade() {
        if (!this.currentUser) {
            throw new AppError('User must be authenticated to upgrade subscription', ErrorCode.AUTHENTICATION_REQUIRED);
        }
        try {
            // Generate unique session token
            const sessionToken = `tws_${randomUUID()}`;
            // Create checkout session via Edge Function
            const response = await fetch(`${this.supabaseUrl}/functions/v1/stripe-webhook/create-checkout-session`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.supabaseKey}`
                },
                body: JSON.stringify({
                    session_token: sessionToken,
                    user_id: this.currentUser.id
                })
            });
            if (!response.ok) {
                const error = await response.text();
                throw new AppError(`Failed to create checkout session: ${error}`, ErrorCode.SUBSCRIPTION_ERROR);
            }
            const result = await response.json();
            if (!result.url) {
                throw new AppError('No checkout URL returned from payment service', ErrorCode.SUBSCRIPTION_ERROR);
            }
            // Open browser to payment page
            await this.openBrowser(result.url);
            return sessionToken;
        }
        catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError(`Subscription upgrade failed: ${error instanceof Error ? error.message : 'Unknown error'}`, ErrorCode.SUBSCRIPTION_ERROR);
        }
    }
    /**
     * Create customer portal session for subscription management
     */
    async openCustomerPortal() {
        if (!this.currentUser) {
            throw new AppError('User must be authenticated to access customer portal', ErrorCode.AUTHENTICATION_REQUIRED);
        }
        // Get the subscription status first to ensure user has active subscription
        const subscription = await this.getSubscriptionStatus();
        if (!subscription.isActive) {
            throw new AppError('No active subscription found. Please upgrade to Professional first.', ErrorCode.SUBSCRIPTION_ERROR);
        }
        // Get the real customer ID using our new dedicated endpoint
        // This ensures we get the correct customer ID linked to this Supabase user
        let customerId;
        try {
            const customerResponse = await fetch(`${this.supabaseUrl}/functions/v1/stripe-webhook/get-customer-id?user_id=${this.currentUser.id}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.supabaseKey}`
                }
            });
            if (!customerResponse.ok) {
                throw new AppError('Failed to fetch customer information', ErrorCode.SUBSCRIPTION_ERROR);
            }
            const customerData = await customerResponse.json();
            if (!customerData.customer_id) {
                throw new AppError('No customer ID found. Please upgrade to Professional first.', ErrorCode.SUBSCRIPTION_ERROR);
            }
            customerId = customerData.customer_id;
        }
        catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError('Failed to fetch customer information', ErrorCode.SUBSCRIPTION_ERROR);
        }
        try {
            // Debug logging
            console.log('Creating portal session for customer:', customerId);
            console.log('Supabase URL:', this.supabaseUrl);
            // Create portal session via Edge Function
            const portalResponse = await fetch(`${this.supabaseUrl}/functions/v1/stripe-webhook/create-portal-session`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.supabaseKey}`
                },
                body: JSON.stringify({
                    customer_id: customerId
                })
            });
            if (!portalResponse.ok) {
                const error = await portalResponse.text();
                throw new AppError(`Failed to create portal session: ${error}`, ErrorCode.SUBSCRIPTION_ERROR);
            }
            const result = await portalResponse.json();
            if (!result.url) {
                throw new AppError('No portal URL returned from service', ErrorCode.SUBSCRIPTION_ERROR);
            }
            // Open browser to customer portal
            await this.openBrowser(result.url);
        }
        catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError(`Failed to open customer portal: ${error instanceof Error ? error.message : 'Unknown error'}`, ErrorCode.SUBSCRIPTION_ERROR);
        }
    }
    /**
     * Open URL in default browser
     */
    async openBrowser(url) {
        try {
            const platform = process.platform;
            let command;
            switch (platform) {
                case 'darwin':
                    command = `open "${url}"`;
                    break;
                case 'win32':
                    command = `start "" "${url}"`;
                    break;
                default:
                    command = `xdg-open "${url}"`;
                    break;
            }
            await execAsync(command);
            console.log(`\n🌐 Opening browser to: ${url.substring(0, 50)}...`);
        }
        catch {
            console.warn('Could not open browser automatically. Please visit:', url);
        }
    }
    /**
     * Get default starter subscription status
     */
    getStarterSubscriptionStatus() {
        return {
            status: 'starter',
            tier: 'starter',
            isActive: false,
            canUseStreaming: false,
            maxRecordingMinutes: 1
        };
    }
    /**
     * Get maximum recording minutes for a tier
     */
    getMaxRecordingMinutesForTier(tier) {
        switch (tier) {
            case 'professional':
            case 'enterprise':
                return 10;
            case 'starter':
            default:
                return 1;
        }
    }
    /**
     * Force refresh subscription status from Stripe API
     */
    async refreshSubscriptionStatus() {
        if (!this.currentUser) {
            return this.getStarterSubscriptionStatus();
        }
        try {
            console.log('🔄 Getting latest subscription status...');
            // This would ideally trigger a server-side refresh
            // For now, we'll use direct query and then the API
            const directStatus = await this.getSubscriptionStatusDirect();
            // Small delay to allow any server-side updates to propagate
            await new Promise(resolve => setTimeout(resolve, 1000));
            // Get fresh status from API
            const apiStatus = await this.getSubscriptionStatusFromAPI();
            return apiStatus || directStatus;
        }
        catch (error) {
            console.warn('Failed to refresh subscription status:', error);
            return this.getStarterSubscriptionStatus();
        }
    }
    /**
     * Get subscription status with smart cache strategy
     * - For premium feature checks: always check fresh if user is currently free
     * - For display: use cache if recent enough
     */
    async getSubscriptionStatusForFeatureCheck() {
        const cachedStatus = await this.getSubscriptionStatus();
        // If user appears to be free but cache is older than 5 minutes, check fresh
        // This catches users who just paid and might be waiting for activation
        if (!cachedStatus.isActive && cachedStatus.cacheAge && cachedStatus.cacheAge > 0.083) { // 5 minutes
            console.log('🔍 Checking for subscription updates...');
            return await this.refreshSubscriptionStatus();
        }
        // If user appears active but cache is very stale, refresh to catch cancellations
        if (cachedStatus.isActive && cachedStatus.isStale && cachedStatus.cacheAge && cachedStatus.cacheAge > 48) {
            console.log('🔍 Verifying subscription status...');
            return await this.refreshSubscriptionStatus();
        }
        return cachedStatus;
    }
    /**
     * Validate subscription before professional feature use with smart refresh
     */
    async validateProfessionalFeatureAccess(feature) {
        const subscription = await this.getSubscriptionStatusForFeatureCheck();
        if (!subscription.isActive) {
            // Handle different subscription states with appropriate messaging
            this.handleInactiveSubscription(subscription, feature);
            return false;
        }
        // Check if subscription is about to expire
        if (subscription.expiresAt) {
            const daysUntilExpiry = Math.ceil((subscription.expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
            if (daysUntilExpiry <= 3 && daysUntilExpiry > 0) {
                console.log(`🔔 Professional subscription expires in ${daysUntilExpiry} day${daysUntilExpiry > 1 ? 's' : ''}`);
                console.log('   Renew now to avoid service interruption: twhisper manage');
            }
        }
        return true;
    }
    /**
     * Handle inactive subscription with appropriate messaging
     */
    handleInactiveSubscription(subscription, feature) {
        console.log(`\n⚠️  Professional feature '${feature}' requires an active subscription.`);
        switch (subscription.status) {
            case 'canceled':
                console.log('🚫 Subscription Status: Canceled');
                if (subscription.expiresAt && subscription.expiresAt > new Date()) {
                    const daysLeft = Math.ceil((subscription.expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
                    console.log(`   Access continues until: ${subscription.expiresAt.toLocaleDateString()} (${daysLeft} days)`);
                    console.log('   Reactivate subscription: twhisper manage');
                }
                else {
                    console.log('   Subscription has ended. Resubscribe to restore access.');
                    console.log('   Get Professional again: twhisper subscribe');
                }
                break;
            case 'past_due':
                console.log('💳 Subscription Status: Payment Past Due');
                console.log('   Update payment method to restore access: twhisper manage');
                console.log('   Professional features temporarily disabled');
                break;
            case 'unpaid':
                console.log('🚫 Subscription Status: Payment Failed');
                console.log('   Update payment method urgently: twhisper manage');
                console.log('   Risk of subscription cancellation');
                break;
            default: // 'free'
                console.log('Current plan: Starter (up to 1 minute recording)');
                break;
        }
        console.log('\nProfessional Features:');
        console.log('• 10-minute recordings (vs 1-minute limit)');
        console.log('• Real-time streaming mode');
        console.log('• Priority support');
        console.log('• Only €9/month');
        if (subscription.status === 'starter') {
            console.log('\n🎆 Upgrade to Professional: twhisper subscribe');
            // If the user just attempted to use a professional feature and they're on starter,
            // suggest checking status in case they recently paid
            console.log('\n💡 Just completed payment? Run: twhisper status --refresh');
        }
        else {
            console.log('\n⚙️  Manage subscription: twhisper manage');
        }
    }
    /**
     * Get user-friendly subscription info for display with cache information
     */
    async getSubscriptionDisplayInfo() {
        const subscription = await this.getSubscriptionStatus();
        let cacheInfo;
        // Only show cache info in debug mode or for developers
        // Normal users don't need to see technical cache details
        if (subscription.isActive) {
            return {
                plan: 'Professional',
                status: subscription.tier === 'professional' && !subscription.expiresAt ? 'Free (Early Access)' : 'Active',
                features: [
                    'Up to 10-minute recordings',
                    'Real-time streaming mode',
                    'Custom formatting modes',
                    'Priority support'
                ],
                nextAction: subscription.expiresAt ?
                    `Next billing: ${subscription.expiresAt.toLocaleDateString()}` :
                    subscription.tier === 'professional' ?
                        'Currently free during early access period' : undefined,
                cacheInfo
            };
        }
        return {
            plan: 'Starter',
            status: 'Active',
            features: [
                'Up to 1-minute recordings',
                'All formatting modes',
                'Batch processing only'
            ],
            nextAction: 'Upgrade to Professional for unlimited features',
            cacheInfo
        };
    }
    /**
     * Upgrade subscription to a specific plan
     */
    async upgradeSubscription(plan) {
        // Implementation depends on the plan parameter
        if (plan === 'professional') {
            await this.upgradeToProfessionalTier();
            return { success: true, message: 'Upgraded to Professional tier' };
        }
        return { success: false, message: 'Invalid plan specified' };
    }
    /**
     * Cancel subscription
     */
    async cancelSubscription() {
        if (!this.currentUser) {
            throw new AppError('Authentication required to cancel subscription', ErrorCode.AUTHENTICATION_REQUIRED, { operation: 'cancelSubscription' });
        }
        // In a real implementation, this would call the appropriate API
        // For now, it's a placeholder
        throw new Error('Cancellation must be done through customer portal');
    }
}
//# sourceMappingURL=SubscriptionService.js.map