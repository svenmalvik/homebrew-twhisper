import { IEnhancedRecordingService, ProcessingMode, StreamingOptions, AudioChunk, RecordingOptions } from '../interfaces/interfaces.js';
import { BufferStatus } from './audio/CircularBuffer.js';
import { StreamingRecorderOptions, StreamingStatus } from './audio/StreamingRecorder.js';
export interface AudioConfig {
    sampleRate: number;
    channels: number;
    encoding: string;
    silence: string;
    endOnSilence: boolean;
    thresholdStart: number;
    thresholdEnd: number;
    verbose: boolean;
}
export declare class RecordingService extends IEnhancedRecordingService {
    private recorder;
    private audioBuffer;
    private isRecording;
    private startTime;
    private audioLevels;
    private recordModule;
    private moduleLoaded;
    private processingMode;
    private isStreaming;
    private streamingRecorder;
    private sequentialRecorder;
    private useSequentialStreaming;
    private circularBuffer;
    private bufferDuration;
    private chunkSize;
    private sequenceId;
    private overflowCount;
    private currentAudioLevel;
    private readonly config;
    constructor();
    /**
     * Pre-load the node-record-lpcm16 module to avoid dynamic import delay during recording
     */
    private preloadRecordingModule;
    /**
     * Start audio recording
     */
    start(options?: RecordingOptions): Promise<void>;
    /**
     * Stop audio recording
     */
    stop(): Buffer | null;
    /**
     * Cancel current recording
     */
    cancel(): void;
    /**
     * Check if currently recording
     */
    getIsRecording(): boolean;
    /**
     * Get current recording duration in seconds
     */
    getRecordingDuration(): number;
    /**
     * Calculate audio amplitude for visualization (RMS calculation)
     */
    calculateAmplitude(buffer: Buffer): number;
    /**
     * Set the processing mode (batch or streaming)
     */
    setProcessingMode(mode: ProcessingMode): Promise<void>;
    /**
     * Get the current processing mode
     */
    getCurrentMode(): ProcessingMode;
    /**
     * Start streaming audio capture with enhanced capabilities
     */
    startStreaming(options?: StreamingOptions): Promise<void>;
    /**
     * Stop streaming audio capture with enhanced reporting
     */
    stopStreaming(): Promise<void>;
    /**
     * Check if currently streaming
     */
    getIsStreaming(): boolean;
    /**
     * Get streaming buffer status
     */
    getBufferStatus(): {
        bufferSize: number;
        utilization: number;
        overflowCount: number;
    };
    /**
     * Configure streaming buffer parameters
     */
    configureBuffer(bufferDuration: number, chunkSize?: number): void;
    /**
     * Get real-time audio level during streaming
     */
    getCurrentAudioLevel(): number;
    /**
     * Get audio buffer from streaming recorder (most recent chunks)
     */
    getStreamingAudioBuffer(chunkCount?: number): Buffer;
    /**
     * Get recent audio chunks from streaming recorder
     */
    getRecentAudioChunks(count: number): AudioChunk[];
    /**
     * Get all audio chunks from streaming recorder
     */
    getAllAudioChunks(): AudioChunk[];
    /**
     * Get detailed buffer statistics
     */
    getDetailedBufferStatus(): BufferStatus | null;
    /**
     * Get buffer memory usage in bytes
     */
    getBufferMemoryUsage(): number;
    /**
     * Get enhanced streaming status
     */
    getEnhancedStreamingStatus(): StreamingStatus | null;
    /**
     * Update streaming options dynamically
     */
    updateStreamingOptions(options: Partial<StreamingRecorderOptions>): void;
    /**
     * Setup enhanced streaming event handlers
     */
    private setupStreamingEventHandlers;
    /**
     * Handle streaming errors
     */
    private handleStreamingError;
    /**
     * Initialize circular buffer for streaming mode
     */
    private initializeCircularBuffer;
    /**
     * Clean up streaming resources
     */
    private cleanupStreaming;
    /**
     * Handle recording errors
     */
    private handleRecordingError;
    /**
     * Clean up resources
     */
    private cleanup;
}
//# sourceMappingURL=RecordingService.d.ts.map