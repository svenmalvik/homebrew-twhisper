import { EventEmitter } from 'events';
import { AppError, ErrorCode } from '../../types/index.js';
/**
 * Progressive Transcription Manager
 *
 * Manages progressive transcription results and provides:
 * 1. Real-time result streaming with confidence filtering
 * 2. Text consolidation and overlap detection
 * 3. Progressive result buffering and emission
 * 4. Context-aware result refinement
 */
export class ProgressiveTranscriptionManager extends EventEmitter {
    constructor() {
        super(...arguments);
        this.CONFIDENCE_SMOOTHING_FACTOR = 0.3;
        this.OVERLAP_DETECTION_THRESHOLD = 0.7;
        this.PROGRESSIVE_EMIT_INTERVAL = 100; // ms
        this.progressiveResults = new Map();
        this.emitIntervals = new Map();
    }
    /**
     * Initialize progressive transcription for a session
     */
    initializeSession(sessionId, options) {
        const sessionData = {
            sessionId,
            options,
            buffer: [],
            lastEmittedText: '',
            accumulatedConfidence: 0,
            wordBuffer: [],
            lastUpdateTime: Date.now(),
            consolidatedText: ''
        };
        this.progressiveResults.set(sessionId, sessionData);
        // Set up progressive emission if enabled
        if (options.enablePartialResults) {
            const interval = setInterval(() => {
                this.emitProgressiveResult(sessionId);
            }, this.PROGRESSIVE_EMIT_INTERVAL);
            this.emitIntervals.set(sessionId, interval);
        }
        this.emit('progressive:session:initialized', { sessionId, options });
    }
    /**
     * Add a partial result to the progressive stream
     */
    addPartialResult(sessionId, partialResult) {
        const sessionData = this.progressiveResults.get(sessionId);
        if (!sessionData) {
            throw new AppError(`Progressive session not found: ${sessionId}`, ErrorCode.STREAMING_SESSION_NOT_FOUND, { sessionId });
        }
        // Apply confidence filtering
        if (partialResult.confidence < sessionData.options.minConfidenceThreshold) {
            this.emit('progressive:result:filtered', {
                sessionId,
                result: partialResult,
                reason: 'low_confidence'
            });
            return;
        }
        // Process and refine the result
        const refinedResult = this.refinePartialResult(partialResult, sessionData);
        // Add to buffer
        sessionData.buffer.push(refinedResult);
        sessionData.lastUpdateTime = Date.now();
        // Update consolidated text
        this.updateConsolidatedText(sessionData, refinedResult);
        this.emit('progressive:result:added', { sessionId, result: refinedResult });
    }
    /**
     * Refine partial result using context and previous results
     */
    refinePartialResult(result, sessionData) {
        const refinedResult = {
            ...result,
            refinedText: result.text,
            overlapDetected: false,
            contextScore: 0,
            refinementApplied: []
        };
        // Apply overlap detection
        this.detectAndResolveOverlap(refinedResult, sessionData);
        // Apply context-based refinement
        this.applyContextualRefinement(refinedResult, sessionData);
        // Smooth confidence scores
        this.smoothConfidenceScore(refinedResult, sessionData);
        return refinedResult;
    }
    /**
     * Detect and resolve text overlap between consecutive results
     */
    detectAndResolveOverlap(result, sessionData) {
        if (sessionData.buffer.length === 0)
            return;
        const lastResult = sessionData.buffer[sessionData.buffer.length - 1];
        const overlap = this.findTextOverlap(lastResult.refinedText, result.text);
        if (overlap && overlap.similarity > this.OVERLAP_DETECTION_THRESHOLD) {
            // Remove overlapping portion from current result
            result.refinedText = result.text.substring(overlap.endIndex);
            result.overlapDetected = true;
            result.refinementApplied.push('overlap_removal');
            this.emit('progressive:overlap:detected', {
                sessionId: sessionData.sessionId,
                overlap,
                originalText: result.text,
                refinedText: result.refinedText
            });
        }
    }
    /**
     * Find text overlap between two strings
     */
    findTextOverlap(previousText, currentText) {
        const prevWords = previousText.toLowerCase().split(/\s+/);
        const currWords = currentText.toLowerCase().split(/\s+/);
        let bestOverlap = null;
        let maxSimilarity = 0;
        // Check for overlap at the end of previous text and start of current text
        for (let i = Math.max(0, prevWords.length - 5); i < prevWords.length; i++) {
            for (let j = 0; j < Math.min(5, currWords.length); j++) {
                const overlapLength = Math.min(prevWords.length - i, currWords.length - j);
                if (overlapLength < 2)
                    continue; // Minimum overlap of 2 words
                let matches = 0;
                for (let k = 0; k < overlapLength; k++) {
                    if (prevWords[i + k] === currWords[j + k]) {
                        matches++;
                    }
                }
                const similarity = matches / overlapLength;
                if (similarity > maxSimilarity && similarity > this.OVERLAP_DETECTION_THRESHOLD) {
                    maxSimilarity = similarity;
                    bestOverlap = {
                        similarity,
                        startIndex: j,
                        endIndex: j + overlapLength,
                        overlapLength,
                        overlappingText: currWords.slice(j, j + overlapLength).join(' ')
                    };
                }
            }
        }
        return bestOverlap;
    }
    /**
     * Apply contextual refinement to improve accuracy
     */
    applyContextualRefinement(result, sessionData) {
        // Calculate context score based on consistency with previous results
        if (sessionData.buffer.length > 0) {
            result.contextScore = this.calculateContextScore(result.refinedText, sessionData.buffer);
            // Apply corrections based on context
            if (result.contextScore > 0.8) {
                // High context confidence - apply smoothing
                result.refinedText = this.applySemanticallyAwareSmoothening(result.refinedText);
                result.refinementApplied.push('contextual_smoothing');
            }
        }
    }
    /**
     * Apply semantically aware text smoothing
     */
    applySemanticallyAwareSmoothening(text) {
        // Simple implementation - could be enhanced with NLP
        let smoothedText = text;
        // Fix common transcription artifacts
        smoothedText = smoothedText.replace(/\b(um|uh|er|ah)\b/gi, ''); // Remove filler words
        smoothedText = smoothedText.replace(/\s+/g, ' '); // Normalize whitespace
        smoothedText = smoothedText.trim();
        return smoothedText;
    }
    /**
     * Calculate context score based on consistency with previous results
     */
    calculateContextScore(text, previousResults) {
        if (previousResults.length === 0)
            return 0.5;
        const words = text.toLowerCase().split(/\s+/);
        const recentResults = previousResults.slice(-3); // Consider last 3 results
        let contextMatches = 0;
        let totalWords = 0;
        for (const word of words) {
            totalWords++;
            for (const result of recentResults) {
                if (result.refinedText.toLowerCase().includes(word)) {
                    contextMatches++;
                    break;
                }
            }
        }
        return totalWords > 0 ? (contextMatches / totalWords) : 0;
    }
    /**
     * Smooth confidence scores over time
     */
    smoothConfidenceScore(result, sessionData) {
        if (sessionData.buffer.length === 0) {
            sessionData.accumulatedConfidence = result.confidence;
            return;
        }
        // Apply exponential smoothing
        sessionData.accumulatedConfidence =
            (this.CONFIDENCE_SMOOTHING_FACTOR * result.confidence) +
                ((1 - this.CONFIDENCE_SMOOTHING_FACTOR) * sessionData.accumulatedConfidence);
        result.smoothedConfidence = sessionData.accumulatedConfidence;
    }
    /**
     * Update consolidated text for the session
     */
    updateConsolidatedText(sessionData, result) {
        if (result.refinedText.trim()) {
            sessionData.consolidatedText += (sessionData.consolidatedText ? ' ' : '') + result.refinedText.trim();
            // Maintain word buffer for advanced processing
            const words = result.refinedText.trim().split(/\s+/);
            sessionData.wordBuffer.push(...words.map(word => ({
                word,
                timestamp: result.timestamp,
                confidence: result.confidence,
                sequenceId: result.sequenceId
            })));
            // Limit word buffer size
            if (sessionData.wordBuffer.length > 100) {
                sessionData.wordBuffer = sessionData.wordBuffer.slice(-100);
            }
        }
    }
    /**
     * Emit progressive result if conditions are met
     */
    emitProgressiveResult(sessionId) {
        const sessionData = this.progressiveResults.get(sessionId);
        if (!sessionData)
            return;
        const currentText = sessionData.consolidatedText;
        // Only emit if text has changed significantly
        if (currentText !== sessionData.lastEmittedText && currentText.length > sessionData.lastEmittedText.length) {
            const progressiveResult = {
                text: currentText,
                confidence: sessionData.accumulatedConfidence,
                isComplete: false,
                timestamp: Date.now(),
                wordCount: sessionData.wordBuffer.length,
                processingLatency: Date.now() - sessionData.lastUpdateTime
            };
            sessionData.lastEmittedText = currentText;
            this.emit('progressive:result:updated', {
                sessionId,
                result: progressiveResult,
                bufferSize: sessionData.buffer.length
            });
        }
    }
    /**
     * Get consolidated result for a session
     */
    getConsolidatedResult(sessionId) {
        const sessionData = this.progressiveResults.get(sessionId);
        if (!sessionData)
            return null;
        return {
            text: sessionData.consolidatedText,
            confidence: sessionData.accumulatedConfidence,
            wordCount: sessionData.wordBuffer.length,
            chunkCount: sessionData.buffer.length,
            averageLatency: this.calculateAverageLatency(sessionData.buffer),
            wordTimestamps: this.generateConsolidatedWordTimestamps(sessionData)
        };
    }
    /**
     * Calculate average processing latency
     */
    calculateAverageLatency(buffer) {
        if (buffer.length === 0)
            return 0;
        const latencies = buffer.map(result => result.timestamp - (result.timestamp - 100) // Simplified latency calculation
        );
        return latencies.reduce((sum, lat) => sum + lat, 0) / latencies.length;
    }
    /**
     * Generate consolidated word timestamps
     */
    generateConsolidatedWordTimestamps(sessionData) {
        return sessionData.wordBuffer.map(wordData => ({
            word: wordData.word,
            start: wordData.timestamp,
            end: wordData.timestamp + 0.5, // Simplified duration
            confidence: wordData.confidence
        }));
    }
    /**
     * Cleanup session resources
     */
    cleanupSession(sessionId) {
        // Clear progressive emission interval
        const interval = this.emitIntervals.get(sessionId);
        if (interval) {
            clearInterval(interval);
            this.emitIntervals.delete(sessionId);
        }
        // Remove session data
        this.progressiveResults.delete(sessionId);
        this.emit('progressive:session:cleaned', { sessionId });
    }
    /**
     * Get session statistics
     */
    getSessionStats(sessionId) {
        const sessionData = this.progressiveResults.get(sessionId);
        if (!sessionData)
            return null;
        return {
            sessionId,
            chunkCount: sessionData.buffer.length,
            wordCount: sessionData.wordBuffer.length,
            averageConfidence: sessionData.accumulatedConfidence,
            totalTextLength: sessionData.consolidatedText.length,
            lastUpdateTime: sessionData.lastUpdateTime,
            sessionDuration: Date.now() - (sessionData.buffer[0]?.timestamp || Date.now())
        };
    }
}
//# sourceMappingURL=ProgressiveTranscriptionManager.js.map