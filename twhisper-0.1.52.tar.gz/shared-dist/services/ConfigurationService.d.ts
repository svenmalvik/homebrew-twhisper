import { IConfigurationService, Configuration, ValidationResult, ProcessingMode } from '../interfaces/interfaces.js';
export declare class ConfigurationService extends IConfigurationService {
    private configuration;
    private configPath;
    private isLoaded;
    constructor(configPath?: string);
    load(): Promise<Configuration>;
    private mergeConfigurations;
    validate(config: Configuration): ValidationResult;
    get<T>(key: string): T | undefined;
    set<T>(key: string, value: T): void;
    save(): Promise<boolean>;
    private sanitizeConfigForStorage;
    /**
     * Get the configuration file path
     */
    getConfigPath(): string;
    /**
     * Check if configuration is loaded
     */
    isConfigLoaded(): boolean;
    /**
     * Get the current configuration (read-only)
     */
    getConfiguration(): Configuration | null;
    /**
     * Reload configuration from file and environment
     */
    reload(): Promise<Configuration>;
    /**
     * Create a sample configuration file with documentation
     */
    createSampleConfig(): Promise<string>;
    /**
     * Get configuration update runtime validation
     */
    validateConfigurationUpdate(updates: Partial<Configuration>): Promise<ValidationResult>;
    /**
     * Check if this is a first-run scenario based on validation errors
     */
    private isFirstRunScenario;
    /**
     * Create default configuration file with all possible settings
     */
    private createDefaultConfigFile;
    /**
     * Generate default configuration file content with all settings
     */
    /**
     * Generate unified config content with optional overrides
     */
    private generateConfigContent;
    /**
     * Legacy method for backwards compatibility
     */
    private generateDefaultConfigContent;
    /**
     * Persist processing mode change to config file
     */
    persistProcessingMode(mode: ProcessingMode): Promise<void>;
    /**
     * Persist language change to config file
     */
    persistLanguage(language: string): Promise<void>;
    /**
     * Generate config content with processing mode
     */
    /**
     * Persist formatting mode change to config file
     */
    persistMode(mode: string): Promise<void>;
    /**
     * Generate config content with language setting
     */
    /**
     * Show welcome message for first-run users
     */
    private showFirstRunWelcome;
}
//# sourceMappingURL=ConfigurationService.d.ts.map