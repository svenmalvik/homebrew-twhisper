// Mode registry implementation
export class ModeRegistryImpl {
    constructor() {
        this.modes = new Map();
        this.defaultMode = 'default';
        this.currentMode = 'default';
        this.initializeDefaultModes();
    }
    /**
     * Initialize default modes
     */
    initializeDefaultModes() {
        // Default mode - general purpose text cleanup
        this.addMode({
            id: 'default',
            name: 'Default',
            description: 'General text cleanup and formatting',
            systemPrompt: 'You are a text editor that cleans up transcribed speech. Fix grammar, remove filler words (um, uh, like, you know), add punctuation, and create proper paragraph breaks. Keep the original meaning and tone intact.',
            examples: [
                'Input: "Um, so I think we should, like, move forward with the project."',
                'Output: "I think we should move forward with the project."'
            ],
            localizedContent: {
                'no': {
                    systemPrompt: 'Du er en tekstredigerer som renser opp transkribert tale. Rett grammatikk, fjern fylleord (eh, øh, liksom, du vet), legg til tegnsetting og lag riktige avsnittsskift. Bevar den opprinnelige meningen og tonen intakt.',
                    examples: [
                        'Inndata: "Eh, så jeg tror vi burde, liksom, gå videre med prosjektet."',
                        'Utdata: "Jeg tror vi burde gå videre med prosjektet."'
                    ],
                    userPromptTemplate: 'Vennligst rens opp denne transkriberte teksten:\n\n{transcription}'
                },
                'da': {
                    systemPrompt: 'Du er en tekstredigerer, der renser transskriberet tale op. Ret grammatik, fjern fyldord (øh, eh, ligesom, du ved), tilføj tegnsætning og lav passende afsnitsopdelinger. Bevar den oprindelige mening og tone intakt.',
                    examples: [
                        'Input: "Øh, så jeg tror vi burde, ligesom, gå videre med projektet."',
                        'Output: "Jeg tror vi burde gå videre med projektet."'
                    ],
                    userPromptTemplate: 'Venligst rens denne transskriberede tekst op:\n\n{transcription}'
                },
                'fi': {
                    systemPrompt: 'Olet tekstieditori, joka siivoaa transkriptoitua puhetta. Korjaa kielioppi, poista täytesanat (öö, hmm, niinkuin, tiedäthän), lisää välimerkit ja luo asianmukaiset kappalejako. Säilytä alkuperäinen merkitys ja sävy ennallaan.',
                    examples: [
                        'Syöte: "Öö, niin mä luulen että meidän pitäisi, niinkuin, jatkaa projektin kanssa."',
                        'Tuloste: "Luulen että meidän pitäisi jatkaa projektin kanssa."'
                    ],
                    userPromptTemplate: 'Siivoa tämä transkriptoitu teksti:\n\n{transcription}'
                }
            },
            settings: {
                temperature: 0.3,
                maxTokens: 1000,
                systemPrompt: 'You are a text editor that cleans up transcribed speech. Fix grammar, remove filler words (um, uh, like, you know), add punctuation, and create proper paragraph breaks. Keep the original meaning and tone intact.',
                userPromptTemplate: 'Please clean up this transcribed text:\n\n{transcription}',
                outputFormat: {
                    preserveLineBreaks: false,
                    addParagraphBreaks: true,
                    capitalizeFirst: true,
                    addPunctuation: true,
                    removeFillerWords: true,
                    correctGrammar: true
                },
                postProcessing: {
                    trimWhitespace: true,
                    removeExtraSpaces: true,
                    normalizeQuotes: true,
                    fixCommonTypos: true
                }
            },
            active: true
        });
        // Email mode - professional email formatting
        this.addMode({
            id: 'email',
            name: 'Email',
            description: 'Format as professional email',
            systemPrompt: 'You are an email assistant that formats transcribed speech into professional emails. Add appropriate greetings, structure the content into clear paragraphs, and include a professional closing. Maintain a courteous and business-appropriate tone.',
            examples: [
                'Input: "I wanted to follow up on our meeting yesterday"',
                'Output: "Dear [Name],\\n\\nI wanted to follow up on our meeting yesterday.\\n\\nBest regards,\\n[Your name]"'
            ],
            localizedContent: {
                'no': {
                    systemPrompt: 'Du er en e-postassistent som formaterer transkribert tale til profesjonelle e-poster. Legg til passende hilsner, strukturer innholdet i tydelige avsnitt og inkluder en profesjonell avslutning. Oppretthold en høflig og forretningspassende tone.',
                    examples: [
                        'Inndata: "Jeg ønsket å følge opp møtet vårt i går"',
                        'Utdata: "Kjære [Navn],\\n\\nJeg ønsket å følge opp møtet vårt i går.\\n\\nVennlig hilsen,\\n[Ditt navn]"'
                    ],
                    userPromptTemplate: 'Vennligst formater denne transkriberte teksten som en profesjonell e-post:\n\n{transcription}'
                },
                'da': {
                    systemPrompt: 'Du er en e-mail-assistent, der formaterer transskriberet tale til professionelle e-mails. Tilføj passende hilsner, strukturér indholdet i klare afsnit, og inkluder en professionel afslutning. Bevar en høflig og forretningspassende tone.',
                    examples: [
                        'Input: "Jeg ville følge op på vores møde i går"',
                        'Output: "Kære [Navn],\\n\\nJeg ville følge op på vores møde i går.\\n\\nVenlig hilsen,\\n[Dit navn]"'
                    ],
                    userPromptTemplate: 'Venligst formater denne transskriberede tekst som en professionel e-mail:\n\n{transcription}'
                },
                'fi': {
                    systemPrompt: 'Olet sähköpostiassistentti, joka muotoilee transkriptoitua puhetta ammattimaisiksi sähköposteiksi. Lisää asianmukaiset tervehdykset, jäsennä sisältö selkeisiin kappaleisiin ja sisällytä ammattimainen lopetus. Säilytä kohtelias ja liiketoimintaan sopiva sävy.',
                    examples: [
                        'Syöte: "Halusin seurata eilistä tapaamistamme"',
                        'Tuloste: "Hyvä [Nimi],\\n\\nHalusin seurata eilistä tapaamistamme.\\n\\nYstävällisin terveisin,\\n[Nimesi]"'
                    ],
                    userPromptTemplate: 'Muotoile tämä transkriptoitu teksti ammattimaiseksi sähköpostiksi:\n\n{transcription}'
                }
            },
            settings: {
                temperature: 0.4,
                maxTokens: 1500,
                systemPrompt: 'You are an email assistant that formats transcribed speech into professional emails. Add appropriate greetings, structure the content into clear paragraphs, and include a professional closing. Maintain a courteous and business-appropriate tone.',
                userPromptTemplate: 'Please format this transcribed text as a professional email:\n\n{transcription}',
                outputFormat: {
                    preserveLineBreaks: true,
                    addParagraphBreaks: true,
                    capitalizeFirst: true,
                    addPunctuation: true,
                    removeFillerWords: true,
                    correctGrammar: true
                },
                postProcessing: {
                    trimWhitespace: true,
                    removeExtraSpaces: true,
                    normalizeQuotes: true,
                    fixCommonTypos: true
                }
            },
            active: true
        });
        // Slack mode - Slack message formatting with emojis
        this.addMode({
            id: 'slack',
            name: 'Slack',
            description: 'Slack message formatting with emojis',
            systemPrompt: 'You are a Slack messaging assistant that formats transcribed speech into casual, friendly Slack messages. Keep the tone conversational and natural while cleaning up the text. Always include at least one relevant emoji to make the message more engaging and Slack-appropriate.',
            examples: [
                'Input: "Hey um I was wondering if you wanted to grab coffee later"',
                'Output: "Hey! I was wondering if you wanted to grab coffee later? ☕"'
            ],
            localizedContent: {
                'no': {
                    systemPrompt: 'Du er en Slack-meldingsassistent som formaterer transkribert tale til uformelle, vennlige Slack-meldinger. Hold tonen samtalepreget og naturlig mens du renser opp teksten. Inkluder alltid minst én relevant emoji for å gjøre meldingen mer engasjerende og Slack-passende.',
                    examples: [
                        'Inndata: "Hei eh jeg lurte på om du hadde lyst til å ta kaffe senere"',
                        'Utdata: "Hei! Jeg lurte på om du hadde lyst til å ta kaffe senere? ☕"'
                    ],
                    userPromptTemplate: 'Vennligst formater denne transkriberte teksten som en Slack-melding med minst én emoji:\n\n{transcription}'
                },
                'da': {
                    systemPrompt: 'Du er en Slack-besked-assistent, der formaterer transskriberet tale til uformelle, venlige Slack-beskeder. Hold tonen samtalevenlig og naturlig, mens du renser teksten op. Inkluder altid mindst én relevant emoji for at gøre beskeden mere engagerende og Slack-passende.',
                    examples: [
                        'Input: "Hej øh jeg tænkte på om du havde lyst til at tage kaffe senere"',
                        'Output: "Hej! Jeg tænkte på om du havde lyst til at tage kaffe senere? ☕"'
                    ],
                    userPromptTemplate: 'Venligst formater denne transskriberede tekst som en Slack-besked med mindst én emoji:\n\n{transcription}'
                },
                'fi': {
                    systemPrompt: 'Olet Slack-viestiassistentti, joka muotoilee transkriptoitua puhetta rennoksi, ystävällisiksi Slack-viesteiksi. Pidä sävy keskustelevana ja luonnollisena samalla kun siivoat tekstiä. Sisällytä aina vähintään yksi relevantti emoji tehdäksesi viestistä kiinnostavamman ja Slack-sopivan.',
                    examples: [
                        'Syöte: "Hei öö mä mietin että haluisitko ottaa kahvia myöhemmin"',
                        'Tuloste: "Hei! Mietin että haluisitko ottaa kahvia myöhemmin? ☕"'
                    ],
                    userPromptTemplate: 'Muotoile tämä transkriptoitu teksti Slack-viestiksi vähintään yhdellä emojilla:\n\n{transcription}'
                }
            },
            settings: {
                temperature: 0.6,
                maxTokens: 800,
                systemPrompt: 'You are a Slack messaging assistant that formats transcribed speech into casual, friendly Slack messages. Keep the tone conversational and natural while cleaning up the text. Always include at least one relevant emoji to make the message more engaging and Slack-appropriate.',
                userPromptTemplate: 'Please format this transcribed text as a Slack message with at least one emoji:\n\n{transcription}',
                outputFormat: {
                    preserveLineBreaks: false,
                    addParagraphBreaks: false,
                    capitalizeFirst: true,
                    addPunctuation: true,
                    removeFillerWords: true,
                    correctGrammar: true
                },
                postProcessing: {
                    trimWhitespace: true,
                    removeExtraSpaces: true,
                    normalizeQuotes: true,
                    fixCommonTypos: true
                }
            },
            active: true
        });
        // Professional casual mode - Polished, smart, and approachable messages
        this.addMode({
            id: 'pro-casual',
            name: 'Professional casual',
            description: 'Turns spoken transcripts into smart, polished, and approachable messages for professional settings.',
            systemPrompt: `
    You are a messaging assistant that formats transcribed speech into professional, polished, yet approachable messages suitable for business communication (such as Slack or Teams).
    - Enhance clarity and correctness: Remove filler words, fix grammar, and use concise language.
    - Maintain a confident, friendly tone, but avoid being overly formal or too casual.
    - Use sophisticated word choices where appropriate, but keep it natural and easy to read.
    - Only use an emoji if it adds genuine warmth, clarity, or emphasis (max one, or none if not needed).
    - Always review for spelling, clarity, and professionalism.
  `,
            examples: [
                'Input: "hey um just checking if you got a chance to look at that thing I sent?"',
                'Output: "Hi, have you had a chance to review what I sent earlier?"',
                'Input: "so basically I think we should try that new api, just to see what happens"',
                'Output: "I recommend trying the new API to see how it performs. Let me know your thoughts."'
            ],
            localizedContent: {
                'no': {
                    systemPrompt: `
        Du er en meldingsassistent som formaterer transkribert tale til profesjonelle, polerte, men tilgjengelige meldinger egnet for forretningskommunikasjon (som Slack eller Teams).
        - Forbedre klarhet og korrekthet: Fjern fylleord, rett grammatikk og bruk konsist språk.
        - Oppretthold en selvsikker, vennlig tone, men unngå å være overdrevent formell eller for uformell.
        - Bruk sofistikerte ordvalg der det passer, men hold det naturlig og lett å lese.
        - Bruk kun en emoji hvis den tilfører ekte varme, klarhet eller vektlegging (maks én, eller ingen hvis ikke nødvendig).
        - Gjennomgå alltid for stavefeil, klarhet og profesjonalitet.
      `,
                    examples: [
                        'Inndata: "hei eh bare sjekker om du fikk sjansen til å se på den greia jeg sendte?"',
                        'Utdata: "Hei, har du fått sjansen til å gjennomgå det jeg sendte tidligere?"',
                        'Inndata: "så egentlig tror jeg vi burde prøve den nye apien, bare for å se hva som skjer"',
                        'Utdata: "Jeg anbefaler at vi prøver den nye API-en for å se hvordan den presterer. Gi meg beskjed hva du tenker."'
                    ],
                    userPromptTemplate: 'Vennligst omformuler dette transkriptet som en profesjonell, polert, men vennlig melding (maks én emoji hvis passende):\n\n{transcription}'
                },
                'da': {
                    systemPrompt: `
        Du er en besked-assistent, der formaterer transskriberet tale til professionelle, polerede, men tilgængelige beskeder, der er egnede til forretningskommunikation (såsom Slack eller Teams).
        - Forbedr klarhed og korrekthed: Fjern fyldord, ret grammatik, og brug præcist sprog.
        - Bevar en selvsikker, venlig tone, men undgå at være overdrevet formel eller for afslappet.
        - Brug sofistikerede ordvalg, hvor det er passende, men hold det naturligt og let at læse.
        - Brug kun en emoji, hvis den tilføjer ægte varme, klarhed eller vægt (maks én, eller ingen hvis ikke nødvendig).
        - Gennemgå altid for stavefejl, klarhed og professionalisme.
      `,
                    examples: [
                        'Input: "hej øh bare tjekker om du fik chancen for at kigge på det jeg sendte?"',
                        'Output: "Hej, har du haft chancen for at gennemgå det, jeg sendte tidligere?"',
                        'Input: "så grundlæggende tror jeg vi skulle prøve den nye api, bare for at se hvad der sker"',
                        'Output: "Jeg anbefaler at prøve den nye API for at se, hvordan den presterer. Giv mig dine tanker."'
                    ],
                    userPromptTemplate: 'Venligst omformulér dette transkript som en professionel, poleret, men venlig besked (maks én emoji hvis passende):\n\n{transcription}'
                },
                'fi': {
                    systemPrompt: `
        Olet viestiassistentti, joka muotoilee transkriptoitua puhetta ammattimaisiksi, hiotuiksi mutta lähestyttäviksi viesteiksi, jotka sopivat liikekommunikaatioon (kuten Slack tai Teams).
        - Paranna selkeyttä ja oikeellisuutta: Poista täytesanat, korjaa kielioppi ja käytä ytimekästä kieltä.
        - Säilytä itsevarma, ystävällinen sävy, mutta vältä liian muodollista tai liian rennoa otetta.
        - Käytä hienostuneita sanavalinoja tarvittaessa, mutta pidä se luonnollisena ja helppolukuisena.
        - Käytä emojia vain, jos se tuo aitoa lämpöä, selkeyttä tai painotusta (enintään yksi, tai ei lainkaan jos ei tarvita).
        - Tarkista aina oikeinkirjoitus, selkeys ja ammattimainen ote.
      `,
                    examples: [
                        'Syöte: "hei öö vaan tarkistan että saitko mahdollisuuden katsoa sitä juttua minkä lähetin?"',
                        'Tuloste: "Hei, oletko ehtinyt tarkastaa sen mitä lähetin aikaisemmin?"',
                        'Syöte: "eli periaatteessa mä luulen että meidän pitäisi kokeilla sitä uutta apia, vaan nähdäkseen mitä tapahtuu"',
                        'Tuloste: "Suosittelen kokeilemaan uutta API:a nähdäksemme miten se toimii. Kerro mitä ajattelet."'
                    ],
                    userPromptTemplate: 'Muotoile tämä transkriptio ammattimaiseksi, hiottua mutta ystävälliseksi viestiksi (enintään yksi emoji jos sopiva):\n\n{transcription}'
                }
            },
            settings: {
                temperature: 0.5,
                maxTokens: 800,
                systemPrompt: `
      You are a messaging assistant that formats transcribed speech into professional, polished, yet approachable messages suitable for business communication (such as Slack or Teams).  
      - Enhance clarity and correctness: Remove filler words, fix grammar, and use concise language.  
      - Maintain a confident, friendly tone, but avoid being overly formal or too casual.  
      - Use sophisticated word choices where appropriate, but keep it natural and easy to read.  
      - Only use an emoji if it adds genuine warmth, clarity, or emphasis (max one, or none if not needed).  
      - Always review for spelling, clarity, and professionalism.
    `,
                userPromptTemplate: 'Please rephrase this transcript as a professional, polished, but friendly message (max one emoji if appropriate):\n\n{transcription}',
                outputFormat: {
                    preserveLineBreaks: false,
                    addParagraphBreaks: false,
                    capitalizeFirst: true,
                    addPunctuation: true,
                    removeFillerWords: true,
                    correctGrammar: true
                },
                postProcessing: {
                    trimWhitespace: true,
                    removeExtraSpaces: true,
                    normalizeQuotes: true,
                    fixCommonTypos: true
                }
            },
            active: true
        });
    }
    /**
     * Add a mode to the registry
     */
    addMode(mode) {
        this.modes.set(mode.id || mode.name, mode);
    }
    /**
     * Get a mode by ID
     */
    getMode(id) {
        return this.modes.get(id);
    }
    /**
     * Get all active modes
     */
    getActiveModes() {
        return Array.from(this.modes.values()).filter(mode => mode.active);
    }
    /**
     * Get mode IDs in order
     */
    getModeIds() {
        return Array.from(this.modes.keys());
    }
    /**
     * Set current mode
     */
    setCurrentMode(modeId) {
        if (this.modes.has(modeId)) {
            this.currentMode = modeId;
            return true;
        }
        return false;
    }
    /**
     * Get current mode
     */
    getCurrentMode() {
        return this.modes.get(this.currentMode);
    }
    /**
     * Get localized content for a mode based on language
     */
    getLocalizedContent(modeId, language) {
        const mode = this.modes.get(modeId);
        if (!mode?.localizedContent?.[language]) {
            return undefined;
        }
        return mode.localizedContent[language];
    }
    /**
     * Get mode with localized content applied
     */
    getModeWithLocalization(modeId, language = 'en') {
        const mode = this.modes.get(modeId);
        if (!mode)
            return undefined;
        // If requesting English or no localization available, return original
        if (language === 'en' || !mode.localizedContent?.[language]) {
            return mode;
        }
        // Create a copy with localized content
        const localizedContent = mode.localizedContent[language];
        return {
            ...mode,
            systemPrompt: localizedContent.systemPrompt,
            examples: localizedContent.examples,
            description: localizedContent.description || mode.description,
            settings: mode.settings ? {
                ...mode.settings,
                systemPrompt: localizedContent.systemPrompt,
                userPromptTemplate: localizedContent.userPromptTemplate
            } : undefined
        };
    }
    /**
     * Cycle to next mode
     */
    cycleToNextMode() {
        const activeModes = this.getActiveModes();
        const currentIndex = activeModes.findIndex(mode => mode.id === this.currentMode);
        const nextIndex = (currentIndex + 1) % activeModes.length;
        if (activeModes[nextIndex]) {
            this.currentMode = activeModes[nextIndex].id || activeModes[nextIndex].name;
            return activeModes[nextIndex];
        }
        return undefined;
    }
}
//# sourceMappingURL=modes.js.map