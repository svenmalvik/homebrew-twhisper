/**
 * Debug logging utility
 */
/**
 * Log debug messages only when DEBUG environment variable is explicitly set to 'true'
 */
export function debugLog(message, ...args) {
    if (process.env.DEBUG === 'true') {
        console.log(message, ...args);
    }
}
/**
 * Log info messages that should always be visible in production
 */
export function infoLog(message, ...args) {
    console.log(message, ...args);
}
/**
 * Log error messages that should always be visible
 */
export function errorLog(message, ...args) {
    console.error(message, ...args);
}
//# sourceMappingURL=debug.js.map