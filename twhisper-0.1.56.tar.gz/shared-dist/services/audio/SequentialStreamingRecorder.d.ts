import { EventEmitter } from 'events';
export interface SequentialChunk {
    data: Buffer;
    chunkNumber: number;
    startTime: number;
    endTime: number;
    duration: number;
}
export interface SequentialStreamingOptions {
    chunkDuration?: number;
    sampleRate?: number;
    channels?: number;
    audioType?: string;
}
/**
 * Sequential Streaming Recorder
 * Records audio in sequential chunks of fixed duration (e.g., 10 seconds)
 * Each chunk is emitted when complete for transcription
 */
export declare class SequentialStreamingRecorder extends EventEmitter {
    private recorder;
    private currentChunkBuffer;
    private chunkNumber;
    private chunkStartTime;
    private isRecording;
    private chunkTimer;
    private readonly options;
    constructor(options?: SequentialStreamingOptions);
    /**
     * Start recording sequential chunks
     */
    start(): Promise<void>;
    /**
     * Start recording a new chunk
     */
    private startNewChunk;
    /**
     * Complete the current chunk and start the next one
     * @param forceEmit - If true, emit the chunk even if recording has stopped (for partial chunks)
     */
    private completeCurrentChunk;
    /**
     * Stop recording
     */
    stop(): Promise<void>;
    /**
     * Check if currently recording
     */
    getIsRecording(): boolean;
    /**
     * Get current chunk number
     */
    getCurrentChunkNumber(): number;
}
//# sourceMappingURL=SequentialStreamingRecorder.d.ts.map