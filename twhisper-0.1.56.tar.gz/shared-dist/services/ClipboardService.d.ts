import { IClipboardService } from '../interfaces/interfaces.js';
export declare class ClipboardService extends IClipboardService {
    private isInitialized;
    private storeDirectory;
    constructor();
    private ensureStoreDirectory;
    private archiveClipboardContent;
    write(text: string): Promise<boolean>;
    read(): Promise<string>;
    isAvailable(): Promise<boolean>;
    clear(): Promise<boolean>;
    /**
     * Write text to clipboard with confirmation and retry logic
     */
    writeWithConfirmation(text: string, maxRetries?: number): Promise<{
        success: boolean;
        wordCount: number;
        preview: string;
    }>;
    /**
     * Get clipboard statistics for monitoring
     */
    getClipboardStats(): {
        totalWrites: number;
        successRate: number;
        averageTextLength: number;
        lastWriteTime: Date | null;
    };
}
//# sourceMappingURL=ClipboardService.d.ts.map