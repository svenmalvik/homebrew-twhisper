import { EventEmitter } from 'events';
import { ServiceContainer, ProcessingMode, AudioChunk, PartialTranscriptionResult, StreamingTranscriptionOptions } from '../interfaces/interfaces.js';
import { ProcessingResult, AppState, AppError } from '../types/index.js';
import { ModeRegistryImpl } from '../types/modes.js';
export interface PipelineEvents {
    'state:changed': (state: AppState) => void;
    'recording:started': () => void;
    'recording:stopped': (audioData: Buffer) => void;
    'recording:cancelled': () => void;
    'transcription:started': () => void;
    'transcription:progress': (progress: {
        stage: string;
        progress: number;
    }) => void;
    'transcription:completed': (transcription: string) => void;
    'formatting:started': () => void;
    'formatting:progress': (progress: {
        stage: string;
        progress: number;
    }) => void;
    'formatting:completed': (formattedText: string) => void;
    'clipboard:copied': (result: {
        success: boolean;
        wordCount: number;
        preview: string;
    }) => void;
    'pipeline:completed': (result: ProcessingResult) => void;
    'pipeline:error': (error: AppError) => void;
    'audio:level': (level: number) => void;
    'streaming:started': (sessionId: string) => void;
    'streaming:stopping': () => void;
    'streaming:stopped': (sessionId: string, result: ProcessingResult) => void;
    'streaming:paused': (sessionId: string) => void;
    'streaming:resumed': (sessionId: string) => void;
    'streaming:chunk:received': (data: {
        sessionId: string;
        chunk: AudioChunk;
    }) => void;
    'streaming:chunk:processed': (data: {
        sessionId: string;
        result: PartialTranscriptionResult;
    }) => void;
    'streaming:partial:result': (data: {
        sessionId: string;
        result: PartialTranscriptionResult;
    }) => void;
    'streaming:progressive:update': (data: {
        sessionId: string;
        text: string;
        confidence: number;
    }) => void;
    'streaming:buffer:status': (data: {
        sessionId: string;
        utilization: number;
        overflowCount: number;
    }) => void;
    'streaming:session:ended': (data: {
        sessionId: string;
        result: ProcessingResult;
    }) => void;
    'streaming:error': (data: {
        sessionId?: string;
        error: AppError;
    }) => void;
    'streaming:setup:required': (data: {
        whisperInstalled: boolean;
        modelExists: boolean;
        modelSize: 'tiny' | 'small' | 'medium';
        setupMessage: string;
    }) => void;
    'streaming:setup:confirmation': (data: {
        whisperInstalled: boolean;
        modelExists: boolean;
        modelSize: 'tiny' | 'small' | 'medium';
        onConfirm: () => void;
        onCancel: () => void;
    }) => void;
    'streaming:setup:started': (data: {
        whisperInstalled: boolean;
        modelExists: boolean;
        modelSize: 'tiny' | 'small' | 'medium';
    }) => void;
    'streaming:setup:progress': (data: {
        stage: string;
        progress: number;
    }) => void;
    'streaming:setup:completed': (data: {
        whisperInstalled: boolean;
        modelExists: boolean;
        modelSize: 'tiny' | 'small' | 'medium';
    }) => void;
    'streaming:setup:failed': (error: AppError) => void;
    'mode:changed': (data: {
        from: ProcessingMode;
        to: ProcessingMode;
    }) => void;
    'mode:switch:started': (mode: ProcessingMode) => void;
    'mode:switch:completed': (mode: ProcessingMode) => void;
    'mode:switch:failed': (error: AppError) => void;
    'whisper:language:changed': (data: {
        from: string;
        to: string;
        modelFrom?: string;
        modelTo?: string;
    }) => void;
    'whisper:language:error': (data: {
        currentLanguage: string;
        attemptedLanguage: string;
        currentModel?: string;
        attemptedModel?: string;
        error: string;
    }) => void;
    'error:recoverable': (data: {
        error: AppError;
        suggestion: string;
        context: Record<string, unknown>;
    }) => void;
    'error:critical': (data: {
        error: AppError;
        requiresRestart: boolean;
        context: Record<string, unknown>;
    }) => void;
    'error:network': (data: {
        error: AppError;
        retryCount: number;
        nextRetryIn: number;
    }) => void;
    'error:authentication': (data: {
        error: AppError;
        setupRequired: boolean;
        helpUrl?: string;
    }) => void;
    'error:subscription': (data: {
        error: AppError;
        tierRequired: string;
        upgradeUrl?: string;
    }) => void;
    'error:configuration': (data: {
        error: AppError;
        configPath: string;
        invalidFields: string[];
    }) => void;
}
export declare class ProcessingPipeline extends EventEmitter {
    on: <K extends keyof PipelineEvents>(event: K, listener: PipelineEvents[K]) => this;
    emit: <K extends keyof PipelineEvents>(event: K, ...args: Parameters<PipelineEvents[K]>) => boolean;
    private services;
    private modeRegistry;
    private currentState;
    private currentRecording;
    private isProcessing;
    private currentProcessingMode;
    private streamingSessions;
    private currentStreamingSessionId;
    private isModeSwitching;
    private chunkBatchSize;
    private chunkBuffer;
    private circuitBreakerState;
    private consecutiveFailures;
    private lastFailureTime;
    private readonly FAILURE_THRESHOLD;
    private readonly CIRCUIT_TIMEOUT;
    private readonly BACKOFF_DELAY;
    private cancelledSessions;
    private authCache;
    private subscriptionCache;
    private readonly CACHE_TTL_MS;
    private readonly SUBSCRIPTION_CACHE_TTL_MS;
    constructor(services: ServiceContainer, modeRegistry: ModeRegistryImpl);
    /**
     * Initialize the pipeline and check initial processing mode requirements
     */
    initialize(): Promise<void>;
    private setupEventListeners;
    /**
     * Start recording audio
     */
    startRecording(): Promise<void>;
    /**
     * Stop recording audio
     */
    stopRecording(): Promise<Buffer | null>;
    /**
     * Cancel current recording
     */
    cancelRecording(): void;
    /**
     * Process recorded audio through the complete pipeline
     */
    private processRecording;
    /**
     * Cycle to the next formatting mode
     */
    cycleMode(): string | null;
    /**
     * Get current mode name
     */
    getCurrentMode(): string | null;
    /**
     * Get all available mode names
     */
    getAvailableModes(): string[];
    /**
     * Set processing mode (batch or streaming)
     */
    setProcessingMode(mode: ProcessingMode): Promise<void>;
    /**
     * Get current processing mode
     */
    getCurrentProcessingMode(): ProcessingMode;
    /**
     * Start streaming session
     */
    startStreamingSession(options?: StreamingTranscriptionOptions): Promise<string>;
    /**
     * Stop streaming session
     */
    stopStreamingSession(sessionId: string): Promise<ProcessingResult>;
    /**
     * Stop the current active streaming session
     */
    stopCurrentStreamingSession(): Promise<ProcessingResult | null>;
    /**
     * Process individual audio chunk (streaming mode)
     */
    processAudioChunk(chunk: AudioChunk, sessionId: string): Promise<PartialTranscriptionResult>;
    /**
     * Pause streaming session
     */
    pauseStreamingSession(sessionId: string): Promise<void>;
    /**
     * Resume streaming session
     */
    resumeStreamingSession(sessionId: string): Promise<void>;
    /**
     * Handle streaming chunk from recording service
     */
    private handleStreamingChunk;
    /**
     * Process multiple chunks as a batch to reduce API calls
     */
    private processBatchedChunks;
    /**
     * Handle streaming stopped event
     */
    private handleStreamingStopped;
    /**
     * Prepare for mode switch by stopping active operations
     */
    private prepareForModeSwitch;
    /**
     * Check buffer status and emit warnings
     */
    private checkBufferStatus;
    /**
     * Handle streaming errors with circuit breaker pattern
     */
    private handleStreamingError;
    /**
     * Check if circuit breaker allows processing
     */
    private shouldAllowProcessing;
    /**
     * Reset circuit breaker on successful processing
     */
    private onProcessingSuccess;
    /**
     * Get current application state
     */
    getCurrentState(): AppState;
    /**
     * Check if currently processing
     */
    getIsProcessing(): boolean;
    /**
     * Get current recording duration
     */
    getRecordingDuration(): number;
    /**
     * Validate recording duration against subscription limits
     */
    validateRecordingDuration(): Promise<boolean>;
    /**
     * Check if user can continue recording based on subscription limits
     */
    checkRecordingLimits(): Promise<void>;
    /**
     * Get current recording status
     */
    getIsRecording(): boolean;
    private setState;
    private handleError;
    /**
     * Enhance errors with helpful recovery suggestions
     */
    private enhanceErrorWithSuggestions;
    /**
     * Get appropriate reset delay based on error type
     */
    private getErrorResetDelay;
    /**
     * Reset pipeline to idle state
     */
    reset(): void;
    /**
     * Get processing statistics
     */
    getProcessingStats(): {
        currentState: AppState;
        isProcessing: boolean;
        isRecording: boolean;
        recordingDuration: number;
        currentMode: string | null;
        availableModes: string[];
        currentProcessingMode: ProcessingMode;
        activeStreamingSessions: number;
        isModeSwitching: boolean;
        streamingSessionStats?: Array<{
            sessionId: string;
            isActive: boolean;
            isPaused: boolean;
            chunkCount: number;
            duration: number;
            accumulatedTextLength: number;
        }>;
    };
    /**
     * Check streaming requirements and offer automatic installation
     */
    private checkStreamingRequirements;
    /**
     * Check if whisper.cpp is installed (not Python whisper)
     */
    private checkWhisperInstalled;
    /**
     * Check if whisper model exists for the specified size
     */
    private checkWhisperModelExists;
    /**
     * Test if a command works
     */
    private testCommand;
    /**
     * Test if whisper.cpp command works (not Python whisper)
     */
    private testWhisperCppCommand;
    /**
     * Generate setup message for user
     */
    private generateSetupMessage;
    /**
     * Ask user for setup confirmation
     */
    private askUserForSetupConfirmation;
    /**
     * Perform automatic streaming setup
     */
    private performStreamingSetup;
    /**
     * Run a command and wait for completion
     */
    private runCommand;
    /**
     * Validate recording data before processing
     */
    private validateRecording;
    /**
     * Check if audio data is silent or very quiet
     */
    private isSilentAudio;
    /**
     * Get current configuration values
     */
    getConfiguration(): import("../index.js").Configuration | null;
    /**
     * Get cached authentication status or check fresh if cache expired
     */
    private getCachedAuthStatus;
    /**
     * Get cached subscription info (max duration and streaming access) or check fresh if cache expired
     */
    private getCachedSubscriptionInfo;
    /**
     * Get cached subscription max duration or check fresh if cache expired
     */
    private getCachedMaxDuration;
    /**
     * Check if current user has a starter plan (for UI conditional display)
     */
    isStarterPlan(): Promise<boolean>;
    /**
     * Update configuration with new values
     */
    updateConfiguration(changes: Record<string, unknown>): Promise<void>;
    /**
     * Reset configuration to defaults
     */
    resetConfiguration(): Promise<void>;
    /**
     * Get human-readable language name from language code
     */
    private getLanguageName;
    /**
     * Validate language permissions on startup and enforce restrictions
     * This prevents users from bypassing subscription checks via config files
     */
    private validateAndEnforceLanguagePermissions;
    /**
     * Force language back to English and notify user
     */
    private forceLanguageToEnglish;
    /**
     * Toggle Whisper language between English, Norwegian, Danish, and Finnish
     * Non-English languages require authentication and active subscription
     */
    toggleWhisperModel(): Promise<void>;
    /**
     * Emit structured error events based on error type and context
     * Provides detailed, actionable error information for Electron UI
     */
    private emitStructuredErrorEvents;
    /**
     * Get additional context for error reporting
     */
    private getErrorContext;
    /**
     * Calculate retry delay based on error type and history
     */
    private calculateRetryDelay;
    /**
     * Extract invalid configuration fields from error details
     */
    private extractInvalidFields;
    /**
     * Create a detailed error report for debugging and support
     */
    createErrorReport(error: AppError): {
        id: string;
        timestamp: Date;
        error: {
            message: string;
            code: string;
            stack?: string;
        };
        context: Record<string, unknown>;
        systemInfo: {
            platform: string;
            nodeVersion: string;
            memoryUsage: NodeJS.MemoryUsage;
        };
    };
    /**
     * Subscribe to events with a callback function
     * Provides a convenient way for Electron to subscribe to multiple events
     */
    subscribeToEvents(callback: (event: string, ...args: unknown[]) => void): () => void;
    /**
     * Unsubscribe from events
     * Note: This removes ALL listeners for the specified callback
     */
    unsubscribeFromEvents(): void;
    /**
     * Get current pipeline status for Electron integration
     * Returns comprehensive status information needed by Electron UI
     */
    getStatus(): {
        state: AppState;
        isProcessing: boolean;
        isRecording: boolean;
        recordingDuration: number;
        currentMode: string | null;
        availableModes: string[];
        processingMode: ProcessingMode;
        isModeSwitching: boolean;
        streamingStats?: {
            activeSessionId: string | null;
            sessionCount: number;
            sessionDetails: Array<{
                sessionId: string;
                isActive: boolean;
                isPaused: boolean;
                chunkCount: number;
                duration: number;
                accumulatedTextLength: number;
            }>;
        };
        error?: AppError;
    };
    /**
     * Subscribe to status polling for real-time UI updates
     * Electron can use this to get periodic status updates
     */
    subscribeToStatusPolling(callback: (status: ReturnType<ProcessingPipeline['getStatus']>) => void, intervalMs?: number): NodeJS.Timeout;
    /**
     * Unsubscribe from status polling
     */
    unsubscribeFromStatusPolling(interval: NodeJS.Timeout): void;
    /**
     * Advanced status polling with change detection
     * Only calls callback when status actually changes, reducing unnecessary updates
     */
    subscribeToStatusChanges(callback: (status: ReturnType<ProcessingPipeline['getStatus']>, changes: string[]) => void, intervalMs?: number): NodeJS.Timeout;
    /**
     * Detect specific changes between status objects
     */
    private detectStatusChanges;
    /**
     * Get performance metrics for status monitoring
     */
    getPerformanceMetrics(): {
        memory: {
            used: number;
            total: number;
            percentage: number;
        };
        uptime: number;
        processedSessions: number;
        averageProcessingTime: number;
        errorRate: number;
        lastErrorTime?: Date;
    };
    /**
     * Subscribe to performance monitoring with alerts
     */
    subscribeToPerformanceMonitoring(callback: (metrics: ReturnType<ProcessingPipeline['getPerformanceMetrics']>, alerts: string[]) => void, thresholds?: {
        memoryThreshold?: number;
        uptimeThreshold?: number;
        errorRateThreshold?: number;
    }, intervalMs?: number): NodeJS.Timeout;
    /**
     * Create a comprehensive health check for Electron integration
     */
    performHealthCheck(): Promise<{
        status: 'healthy' | 'warning' | 'error';
        checks: Array<{
            name: string;
            status: 'pass' | 'fail' | 'warning';
            message: string;
            details?: Record<string, unknown>;
        }>;
        timestamp: Date;
    }>;
    /**
     * Create a structured event listener for specific event types
     * Useful for Electron to listen to specific categories of events
     */
    createEventListener(eventCategories: {
        states?: boolean;
        recording?: boolean;
        transcription?: boolean;
        formatting?: boolean;
        streaming?: boolean;
        errors?: boolean;
        modes?: boolean;
    }): (callback: (event: {
        type: string;
        data: unknown;
        timestamp: Date;
    }) => void) => () => void;
}
//# sourceMappingURL=ProcessingPipeline.d.ts.map