import { TranscriptionResult, TranscriptionOptions, Configuration } from '../../interfaces/interfaces.js';
/**
 * Local Whisper transcription service using whisper.cpp
 * Optimized for Apple Silicon with GPU acceleration
 * Provides fast, offline transcription for streaming mode
 */
export declare class LocalWhisperService {
    private whisperPath;
    private modelPath;
    private isInitialized;
    private instanceId;
    private initializationPromise;
    private initializationFailed;
    private tempDir;
    private activeProcesses;
    private concurrencyQueue;
    private maxConcurrentProcesses;
    private configuration;
    constructor(configuration?: Configuration);
    /**
     * Initialize the local Whisper model
     */
    private initializeModel;
    private doInitializeModel;
    /**
     * Find whisper.cpp binary (not Python whisper)
     */
    private findWhisperBinary;
    /**
     * Test if whisper.cpp binary works (not Python whisper)
     */
    private testWhisperCppBinary;
    /**
     * Find or download Whisper model based on configuration
     */
    private findOrDownloadModel;
    /**
     * Try to find a specific model size - EXACT match only
     */
    private findSpecificModel;
    /**
     * Download the specified model to ~/.whisper directory
     */
    private downloadDefaultModel;
    /**
     * Transcribe audio buffer using local Whisper model
     */
    transcribe(audioBuffer: Buffer, options?: TranscriptionOptions): Promise<TranscriptionResult>;
    /**
     * Run whisper with concurrency control
     */
    private runWhisperWithConcurrencyControl;
    /**
     * Run whisper-cli with optimized settings for Apple Silicon
     */
    private runWhisper;
    /**
     * Write audio buffer as WAV file
     */
    private writeBufferAsWav;
    /**
     * Estimate confidence based on text quality (simplified heuristic)
     */
    private estimateConfidence;
    /**
     * Check if the service is ready
     */
    isReady(): boolean;
    /**
     * Get model info
     */
    getModelInfo(): {
        name: string;
        type: string;
        local: boolean;
        gpu: boolean;
        size: string;
    };
    /**
     * Clean up temporary files
     */
    cleanup(): Promise<void>;
}
//# sourceMappingURL=LocalWhisperService.d.ts.map