import { IConfigurationService, ProcessingMode } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
import { config } from 'dotenv';
import fs from 'fs/promises';
import path from 'path';
import { homedir } from 'os';
import { debugLog as utilDebugLog } from '../utils/debug.js';
export class ConfigurationService extends IConfigurationService {
    constructor(configPath) {
        super();
        this.configuration = null;
        this.isLoaded = false;
        this.configPath = configPath || path.join(homedir(), '.twhisper-settings.json');
    }
    async load() {
        try {
            // First try to load from .env file, then fallback to ~/.twhisper directory or legacy file
            const envPath = path.join(process.cwd(), '.env');
            const twhisperConfigPath = path.join(homedir(), '.twhisper');
            const twhisperLegacyConfigPath = path.join(homedir(), '.twhisper', 'config');
            let configSource = 'none';
            let hasAnyConfigFile = false;
            try {
                await fs.access(envPath);
                config({ path: envPath });
                configSource = '.env';
                hasAnyConfigFile = true;
            }
            catch {
                // .env doesn't exist, try ~/.twhisper directory structure first
                try {
                    await fs.access(twhisperLegacyConfigPath);
                    config({ path: twhisperLegacyConfigPath });
                    configSource = '~/.twhisper/config';
                    hasAnyConfigFile = true;
                }
                catch {
                    // Try legacy ~/.twhisper file
                    try {
                        const stats = await fs.stat(twhisperConfigPath);
                        if (stats.isFile()) {
                            config({ path: twhisperConfigPath });
                            configSource = '~/.twhisper (legacy)';
                            hasAnyConfigFile = true;
                        }
                        else {
                            // Directory exists but no config file found
                            configSource = 'environment';
                        }
                    }
                    catch {
                        // Neither file nor directory exists, continue with environment variables only
                        configSource = 'environment';
                    }
                }
            }
            if (process.env.DEBUG === 'true') {
                console.log('🔍 DEBUG: ConfigurationService.load()');
                console.log(`   Configuration source: ${configSource}`);
                if (configSource === '.env') {
                    console.log(`   Loaded from: ${envPath}`);
                }
                else if (configSource === '~/.twhisper') {
                    console.log(`   Loaded from: ${twhisperConfigPath}`);
                }
                console.log(`   process.cwd(): ${process.cwd()}`);
                console.log('   After config loading:');
                Object.keys(process.env).filter(key => key.startsWith('AZURE_OPENAI')).forEach(key => {
                    console.log(`     ${key}: ${process.env[key] ? 'SET' : 'NOT SET'}`);
                });
            }
            // Load configuration from JSON file if it exists (legacy support)
            let fileConfig = {};
            try {
                const configFile = await fs.readFile(this.configPath, 'utf-8');
                fileConfig = JSON.parse(configFile);
            }
            catch (error) {
                // Config file doesn't exist or is invalid, continue with env vars only
                if (error instanceof Error && 'code' in error && error.code !== 'ENOENT') {
                    throw new AppError('Configuration file exists but is invalid', ErrorCode.CONFIGURATION_ERROR, { configPath: this.configPath, error: error.message });
                }
            }
            // Merge environment variables with file configuration (env vars take precedence)
            this.configuration = this.mergeConfigurations(fileConfig);
            // Validate the configuration
            const validation = this.validate(this.configuration);
            if (!validation.valid) {
                // Check if this is a first-run scenario (no config files and missing required env vars)
                const isFirstRun = !hasAnyConfigFile && this.isFirstRunScenario(validation.errors);
                if (isFirstRun) {
                    await this.createDefaultConfigFile(twhisperLegacyConfigPath);
                    this.showFirstRunWelcome(twhisperLegacyConfigPath);
                }
                const errorMessages = validation.errors.map(e => e.message).join(', ');
                throw new AppError(`Invalid configuration: ${errorMessages}`, ErrorCode.CONFIGURATION_ERROR, { errors: validation.errors, warnings: validation.warnings, isFirstRun });
            }
            // Log warnings if any
            if (validation.warnings.length > 0) {
                console.warn('Configuration warnings:');
                validation.warnings.forEach(warning => {
                    console.warn(`  ${warning.field}: ${warning.message}`);
                    if (warning.suggestion) {
                        console.warn(`    Suggestion: ${warning.suggestion}`);
                    }
                });
            }
            this.isLoaded = true;
            return this.configuration;
        }
        catch (error) {
            if (error instanceof AppError) {
                throw error;
            }
            throw new AppError('Failed to load configuration', ErrorCode.CONFIGURATION_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    mergeConfigurations(fileConfig) {
        const defaultConfig = {
            azureOpenAI: {
                apiKey: process.env.AZURE_OPENAI_API_KEY || fileConfig.azureOpenAI?.apiKey || '',
                endpoint: process.env.AZURE_OPENAI_ENDPOINT || fileConfig.azureOpenAI?.endpoint || '',
                apiVersion: process.env.AZURE_OPENAI_API_VERSION || fileConfig.azureOpenAI?.apiVersion || '2024-02-15-preview',
                whisperDeployment: process.env.AZURE_OPENAI_WHISPER_DEPLOYMENT || fileConfig.azureOpenAI?.whisperDeployment || 'whisper',
                gptDeployment: process.env.AZURE_OPENAI_GPT_DEPLOYMENT || fileConfig.azureOpenAI?.gptDeployment || 'gpt-4.1',
            },
            auth: {
                enabled: true, // Always enabled for security - streaming mode requires authentication
                requireForStreaming: true, // Always require authentication for streaming mode (security requirement)
                supabaseUrl: 'https://abhhnwiajhoncpqamrcj.supabase.co',
                supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiaGhud2lhamhvbmNwcWFtcmNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc2MDMwMTgsImV4cCI6MjA3MzE3OTAxOH0.jFpxWu6iRAFaH8jzCw82UTUa61aVTzVIAHGRZCg_Ee4',
            },
            app: {
                defaultMode: process.env.DEFAULT_MODE || fileConfig.app?.defaultMode || 'default',
                defaultProcessingMode: (process.env.DEFAULT_PROCESSING_MODE === 'streaming') ? ProcessingMode.STREAMING : (fileConfig.app?.defaultProcessingMode || ProcessingMode.BATCH),
                // maxRecordingTime: 60 and minRecordingTime: 1 are hardcoded in ProcessingPipeline
                autoCopy: (process.env.AUTO_COPY === 'true') || fileConfig.app?.autoCopy !== false,
                useLocalWhisper: process.env.USE_LOCAL_WHISPER === 'false' ? false : (fileConfig.app?.useLocalWhisper ?? true),
                debug: (process.env.DEBUG === 'true') || fileConfig.app?.debug === true,
            },
            audio: {
                sampleRate: parseInt(process.env.AUDIO_SAMPLE_RATE || '16000') || fileConfig.audio?.sampleRate || 16000,
                channels: parseInt(process.env.AUDIO_CHANNELS || '1') || fileConfig.audio?.channels || 1,
                encoding: process.env.AUDIO_ENCODING || fileConfig.audio?.encoding || 'signed-integer',
            },
            whisper: {
                modelSize: process.env.WHISPER_MODEL_SIZE || fileConfig.whisper?.modelSize || 'small',
                useGPU: (process.env.WHISPER_USE_GPU === 'true') || fileConfig.whisper?.useGPU !== false,
                language: process.env.WHISPER_LANGUAGE || fileConfig.whisper?.language || 'en',
            },
            ui: {
                theme: process.env.UI_THEME || fileConfig.ui?.theme || 'auto',
                showWaveform: (process.env.SHOW_WAVEFORM !== 'false') && (fileConfig.ui?.showWaveform !== false),
                showProgress: (process.env.SHOW_PROGRESS !== 'false') && (fileConfig.ui?.showProgress !== false),
                refreshRate: parseInt(process.env.UI_REFRESH_RATE || '30') || fileConfig.ui?.refreshRate || 30,
            },
        };
        return defaultConfig;
    }
    validate(config) {
        const errors = [];
        const warnings = [];
        // Validate Azure OpenAI configuration
        if (!config.azureOpenAI.apiKey) {
            errors.push({
                field: 'azureOpenAI.apiKey',
                message: 'Azure OpenAI API key is required',
                code: 'MISSING_API_KEY',
            });
        }
        if (!config.azureOpenAI.endpoint) {
            errors.push({
                field: 'azureOpenAI.endpoint',
                message: 'Azure OpenAI endpoint is required',
                code: 'MISSING_ENDPOINT',
            });
        }
        else {
            try {
                new URL(config.azureOpenAI.endpoint);
            }
            catch {
                errors.push({
                    field: 'azureOpenAI.endpoint',
                    message: 'Azure OpenAI endpoint must be a valid URL',
                    code: 'INVALID_ENDPOINT_URL',
                });
            }
        }
        if (!config.azureOpenAI.whisperDeployment) {
            errors.push({
                field: 'azureOpenAI.whisperDeployment',
                message: 'Whisper deployment name is required',
                code: 'MISSING_WHISPER_DEPLOYMENT',
            });
        }
        if (!config.azureOpenAI.gptDeployment) {
            errors.push({
                field: 'azureOpenAI.gptDeployment',
                message: 'GPT deployment name is required',
                code: 'MISSING_GPT_DEPLOYMENT',
            });
        }
        // Authentication is always available (hardcoded Supabase values)
        // No validation needed for auth settings
        // Recording times are hardcoded: min=1s, max=60s (no validation needed)
        // Validate audio settings
        if (![8000, 16000, 22050, 44100, 48000].includes(config.audio.sampleRate)) {
            warnings.push({
                field: 'audio.sampleRate',
                message: 'Unusual sample rate, recommended values are 16000 or 44100',
                suggestion: 'Use 16000 Hz for speech recognition optimal performance',
            });
        }
        if (config.audio.channels !== 1 && config.audio.channels !== 2) {
            errors.push({
                field: 'audio.channels',
                message: 'Audio channels must be 1 (mono) or 2 (stereo)',
                code: 'INVALID_AUDIO_CHANNELS',
            });
        }
        // Validate Whisper settings
        const validModelSizes = ['tiny', 'tiny.en', 'base', 'base.en', 'small', 'small.en', 'medium', 'medium.en'];
        if (!validModelSizes.includes(config.whisper.modelSize)) {
            errors.push({
                field: 'whisper.modelSize',
                message: `Invalid Whisper model size: ${config.whisper.modelSize}. Must be one of: ${validModelSizes.join(', ')}`,
                code: 'INVALID_WHISPER_MODEL_SIZE',
            });
        }
        // Warn about large model sizes
        const largeModels = ['medium', 'medium.en'];
        if (largeModels.includes(config.whisper.modelSize)) {
            warnings.push({
                field: 'whisper.modelSize',
                message: `Large model size '${config.whisper.modelSize}' requires significant RAM (2.6GB+ for medium)`,
                suggestion: 'Consider using "small" or "base" for better performance on typical systems',
            });
        }
        // Validate Whisper language setting
        const validLanguages = ['en', 'no', 'da', 'fi'];
        if (!validLanguages.includes(config.whisper.language)) {
            errors.push({
                field: 'whisper.language',
                message: `Invalid Whisper language: ${config.whisper.language}. Must be one of: ${validLanguages.join(', ')}`,
                code: 'INVALID_WHISPER_LANGUAGE',
            });
        }
        // Security check: Non-English languages require proper permissions
        // This prevents users from bypassing subscription restrictions via config files
        if (config.whisper.language !== 'en') {
            warnings.push({
                field: 'whisper.language',
                message: `Non-English language '${config.whisper.language}' requires authentication and active subscription. Will default to English if permissions are insufficient.`,
                suggestion: 'Set WHISPER_LANGUAGE=en for unrestricted access, or login with a Professional subscription for multilingual support.',
            });
        }
        // Validate UI settings
        if (config.ui.refreshRate < 1 || config.ui.refreshRate > 60) {
            warnings.push({
                field: 'ui.refreshRate',
                message: 'UI refresh rate should be between 1 and 60 FPS',
                suggestion: 'Use 30 FPS for optimal balance of smoothness and performance',
            });
        }
        return {
            valid: errors.length === 0,
            errors,
            warnings,
        };
    }
    get(key) {
        if (!this.configuration) {
            throw new AppError('Configuration not loaded', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        const keys = key.split('.');
        let value = this.configuration;
        for (const k of keys) {
            if (value && typeof value === 'object' && value !== null && k in value) {
                value = value[k];
            }
            else {
                return undefined;
            }
        }
        return value;
    }
    set(key, value) {
        if (!this.configuration) {
            throw new AppError('Configuration not loaded', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        const keys = key.split('.');
        let target = this.configuration;
        for (let i = 0; i < keys.length - 1; i++) {
            const k = keys[i];
            if (!target[k] || typeof target[k] !== 'object') {
                target[k] = {};
            }
            target = target[k];
        }
        target[keys[keys.length - 1]] = value;
    }
    async save() {
        if (!this.configuration) {
            throw new AppError('No configuration to save', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        try {
            // Ensure config directory exists
            const configDir = path.dirname(this.configPath);
            try {
                await fs.access(configDir);
            }
            catch {
                await fs.mkdir(configDir, { recursive: true });
            }
            // Create a sanitized version without sensitive data for file storage
            const sanitizedConfig = this.sanitizeConfigForStorage(this.configuration);
            await fs.writeFile(this.configPath, JSON.stringify(sanitizedConfig, null, 2), 'utf-8');
            return true;
        }
        catch (error) {
            throw new AppError('Failed to save configuration', ErrorCode.FILE_OPERATION_ERROR, { configPath: this.configPath, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    sanitizeConfigForStorage(config) {
        // Don't save sensitive information like API keys to file
        // These should come from environment variables
        return {
            app: config.app,
            audio: config.audio,
            ui: config.ui,
            // Omit azureOpenAI credentials - these should be in environment variables
        };
    }
    /**
     * Get the configuration file path
     */
    getConfigPath() {
        return this.configPath;
    }
    /**
     * Check if configuration is loaded
     */
    isConfigLoaded() {
        return this.isLoaded && this.configuration !== null;
    }
    /**
     * Get the current configuration (read-only)
     */
    getConfiguration() {
        return this.configuration ? { ...this.configuration } : null;
    }
    /**
     * Reload configuration from file and environment
     */
    async reload() {
        this.configuration = null;
        this.isLoaded = false;
        return await this.load();
    }
    /**
     * Create a sample configuration file with documentation
     */
    async createSampleConfig() {
        const sampleConfig = {
            $schema: 'Twhisper CLI Configuration',
            $description: 'Configuration file for Twhisper CLI. Sensitive values (API keys) should be set via environment variables.',
            app: {
                defaultMode: 'default',
                // maxRecordingTime: 60 and minRecordingTime: 1 are hardcoded
                autoCopy: true,
                debug: false,
            },
            audio: {
                sampleRate: 16000,
                channels: 1,
                encoding: 'signed-integer',
            },
            ui: {
                theme: 'auto',
                showWaveform: true,
                showProgress: true,
                refreshRate: 30,
            },
            $envVars: {
                $description: 'These values should be set as environment variables:',
                AZURE_OPENAI_API_KEY: 'your-azure-openai-api-key',
                AZURE_OPENAI_ENDPOINT: 'https://your-resource.openai.azure.com/',
                AZURE_OPENAI_API_VERSION: '2024-02-15-preview',
                AZURE_OPENAI_WHISPER_DEPLOYMENT: 'whisper',
                AZURE_OPENAI_GPT_DEPLOYMENT: 'gpt-4.1',
            }
        };
        const samplePath = path.join(path.dirname(this.configPath), 'config.sample.json');
        await fs.writeFile(samplePath, JSON.stringify(sampleConfig, null, 2), 'utf-8');
        return samplePath;
    }
    /**
     * Get configuration update runtime validation
     */
    async validateConfigurationUpdate(updates) {
        if (!this.configuration) {
            throw new AppError('Configuration not loaded', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        // Create a temporary merged configuration for validation
        const testConfig = {
            ...this.configuration,
            ...updates,
            // Deep merge nested objects
            ...(updates.audio && { audio: { ...this.configuration.audio, ...updates.audio } }),
            ...(updates.ui && { ui: { ...this.configuration.ui, ...updates.ui } }),
            ...(updates.app && { app: { ...this.configuration.app, ...updates.app } }),
        };
        return this.validate(testConfig);
    }
    /**
     * Check if this is a first-run scenario based on validation errors
     */
    isFirstRunScenario(errors) {
        // Check if we have the core Azure OpenAI configuration errors that would indicate first run
        const coreErrors = ['MISSING_API_KEY', 'MISSING_ENDPOINT', 'MISSING_WHISPER_DEPLOYMENT', 'MISSING_GPT_DEPLOYMENT'];
        const errorCodes = errors.map(e => e.code);
        return coreErrors.some(code => errorCodes.includes(code));
    }
    /**
     * Create default configuration file with all possible settings
     */
    async createDefaultConfigFile(twhisperConfigPath) {
        try {
            const defaultConfigContent = this.generateDefaultConfigContent();
            // Ensure directory structure exists
            const configDir = path.dirname(twhisperConfigPath);
            try {
                await fs.access(configDir);
            }
            catch {
                await fs.mkdir(configDir, { recursive: true });
            }
            await fs.writeFile(twhisperConfigPath, defaultConfigContent, 'utf-8');
            console.log(`✅ Created default configuration file: ${twhisperConfigPath}`);
        }
        catch (error) {
            console.warn(`⚠️  Could not create default config file: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Generate default configuration file content with all settings
     */
    /**
     * Generate unified config content with optional overrides
     */
    generateConfigContent(options = {}) {
        const { mode = 'pro-casual', processingMode = ProcessingMode.BATCH, language = 'en' } = options;
        const lines = [
            '# Twhisper CLI Configuration',
            '# This file was automatically created to persist your settings',
            '# Edit these values to customize your Twhisper experience',
            '',
            '# ===== AZURE OPENAI CONFIGURATION (REQUIRED) =====',
            '# Get these values from your Azure OpenAI resource',
            'AZURE_OPENAI_API_KEY=your-azure-openai-api-key',
            'AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/',
            'AZURE_OPENAI_API_VERSION=2024-02-15-preview',
            'AZURE_OPENAI_WHISPER_DEPLOYMENT=whisper',
            'AZURE_OPENAI_GPT_DEPLOYMENT=gpt-4',
            '',
            '# ===== APPLICATION SETTINGS =====',
            '# Default formatting mode (default, email, code, message, slack, pro-casual)',
            `DEFAULT_MODE=${mode}`,
        ];
        // Add processing mode line only if it's not the default
        if (processingMode !== ProcessingMode.BATCH) {
            lines.push('', '# Processing mode setting (batch or streaming)', `DEFAULT_PROCESSING_MODE=${processingMode.toLowerCase()}`);
        }
        lines.push('', '# Use local whisper.cpp for batch mode (true) or Azure OpenAI (false)', 'USE_LOCAL_WHISPER=true', 'WHISPER_MODEL_SIZE=small', `WHISPER_LANGUAGE=${language}`, '', '# Enable debug output', 'DEBUG=false', '', '# ===== AUDIO SETTINGS =====', '# Audio recording parameters', 'AUDIO_SAMPLE_RATE=16000', 'AUDIO_CHANNELS=1', 'AUDIO_ENCODING=signed-integer', 'AUDIO_THRESHOLD_START=0.01', 'AUDIO_THRESHOLD_END=0.005', '', '# ===== WHISPER MODEL SETTINGS =====', '# Model size for local Whisper (tiny, base, small, medium)', 'WHISPER_MODEL_SIZE=small', '', '# Use GPU acceleration for Whisper (if available)', 'WHISPER_USE_GPU=true', '', '# ===== UI SETTINGS =====', '# UI theme (light, dark, auto)', 'UI_THEME=auto', '', '# Show audio waveform visualization', 'SHOW_WAVEFORM=true', '', '# Show progress indicators', 'SHOW_PROGRESS=true', '', '# UI refresh rate (1-60 FPS)', 'UI_REFRESH_RATE=30', '', '# ===== INSTRUCTIONS =====', '# 1. Replace the Azure OpenAI values above with your actual credentials', '# 2. Adjust settings as needed for your use case', '# 3. Run Twhisper again to test your configuration', '# 4. For more help: https://github.com/svenmalvik/Twhisper#configuration');
        return lines.join('\n') + '\n';
    }
    /**
     * Legacy method for backwards compatibility
     */
    generateDefaultConfigContent() {
        return this.generateConfigContent();
    }
    /**
     * Persist processing mode change to config file
     */
    async persistProcessingMode(mode) {
        try {
            // Get the path to the config file (prefer ~/.twhisper/config)
            const twhisperConfigPath = path.join(homedir(), '.twhisper', 'config');
            let configContent = '';
            let configExists = false;
            // Try to read existing config file
            try {
                configContent = await fs.readFile(twhisperConfigPath, 'utf-8');
                configExists = true;
            }
            catch (error) {
                // Config file doesn't exist, we'll create it
                configExists = false;
            }
            if (configExists) {
                // Update existing config file
                const lines = configContent.split('\n');
                let modeLineFound = false;
                // Find and update the DEFAULT_PROCESSING_MODE line
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].startsWith('DEFAULT_PROCESSING_MODE=')) {
                        lines[i] = `DEFAULT_PROCESSING_MODE=${mode.toLowerCase()}`;
                        modeLineFound = true;
                        break;
                    }
                }
                // If the line doesn't exist, add it after DEFAULT_MODE if it exists
                if (!modeLineFound) {
                    let insertIndex = -1;
                    for (let i = 0; i < lines.length; i++) {
                        if (lines[i].startsWith('DEFAULT_MODE=')) {
                            insertIndex = i + 1;
                            break;
                        }
                    }
                    const newLine = `DEFAULT_PROCESSING_MODE=${mode.toLowerCase()}`;
                    if (insertIndex >= 0) {
                        lines.splice(insertIndex, 0, newLine);
                    }
                    else {
                        // If DEFAULT_MODE not found, add at the end of the app settings section
                        lines.push('');
                        lines.push('# Processing mode setting (batch or streaming)');
                        lines.push(newLine);
                    }
                }
                configContent = lines.join('\n');
            }
            else {
                // Create new config file with the processing mode setting
                const configDir = path.dirname(twhisperConfigPath);
                try {
                    await fs.access(configDir);
                }
                catch {
                    await fs.mkdir(configDir, { recursive: true });
                }
                configContent = this.generateConfigContent({ processingMode: mode });
            }
            // Write the updated config
            await fs.writeFile(twhisperConfigPath, configContent, 'utf-8');
            // Update the in-memory configuration as well
            if (this.configuration) {
                this.configuration.app.defaultProcessingMode = mode;
            }
            utilDebugLog(`✅ [ConfigurationService] Persisted processing mode change to: ${mode}`);
        }
        catch (error) {
            console.warn(`⚠️  Failed to persist processing mode to config file: ${error instanceof Error ? error.message : 'Unknown error'}`);
            throw new AppError('Failed to persist processing mode to config file', ErrorCode.FILE_OPERATION_ERROR, { mode, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Persist language change to config file
     */
    async persistLanguage(language) {
        try {
            // Get the path to the config file (prefer ~/.twhisper/config)
            const twhisperConfigPath = path.join(homedir(), '.twhisper', 'config');
            let configContent = '';
            let configExists = false;
            // Try to read existing config file
            try {
                configContent = await fs.readFile(twhisperConfigPath, 'utf-8');
                configExists = true;
            }
            catch (error) {
                // Config file doesn't exist, we'll create it
                configExists = false;
            }
            if (configExists) {
                // Update existing config file
                const lines = configContent.split('\n');
                let languageLineFound = false;
                // Find and update the WHISPER_LANGUAGE line
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].startsWith('WHISPER_LANGUAGE=')) {
                        lines[i] = `WHISPER_LANGUAGE=${language}`;
                        languageLineFound = true;
                        break;
                    }
                }
                // If the line doesn't exist, add it after WHISPER_MODEL_SIZE if it exists
                if (!languageLineFound) {
                    let insertIndex = -1;
                    for (let i = 0; i < lines.length; i++) {
                        if (lines[i].startsWith('WHISPER_MODEL_SIZE=')) {
                            insertIndex = i + 1;
                            break;
                        }
                    }
                    const newLine = `WHISPER_LANGUAGE=${language}`;
                    if (insertIndex >= 0) {
                        lines.splice(insertIndex, 0, newLine);
                    }
                    else {
                        // If WHISPER_MODEL_SIZE not found, add at the end of the app settings section
                        lines.push('');
                        lines.push('# Whisper language setting (en, no, da, fi)');
                        lines.push(newLine);
                    }
                }
                configContent = lines.join('\n');
            }
            else {
                // Create new config file with the language setting
                const configDir = path.dirname(twhisperConfigPath);
                try {
                    await fs.access(configDir);
                }
                catch {
                    await fs.mkdir(configDir, { recursive: true });
                }
                configContent = this.generateConfigContent({ language });
            }
            // Write the updated config
            await fs.writeFile(twhisperConfigPath, configContent, 'utf-8');
            // Update the in-memory configuration as well
            if (this.configuration) {
                this.configuration.whisper.language = language;
            }
            utilDebugLog(`✅ [ConfigurationService] Persisted language change to: ${language}`);
        }
        catch (error) {
            console.warn(`⚠️  Failed to persist language to config file: ${error instanceof Error ? error.message : 'Unknown error'}`);
            throw new AppError('Failed to persist language to config file', ErrorCode.FILE_OPERATION_ERROR, { language, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Generate config content with processing mode
     */
    /**
     * Persist formatting mode change to config file
     */
    async persistMode(mode) {
        try {
            // Get the path to the config file (prefer ~/.twhisper/config)
            const twhisperConfigPath = path.join(homedir(), '.twhisper', 'config');
            let configContent = '';
            let configExists = false;
            // Try to read existing config file
            try {
                configContent = await fs.readFile(twhisperConfigPath, 'utf-8');
                configExists = true;
            }
            catch (error) {
                // Config file doesn't exist, we'll create it
                configExists = false;
            }
            if (configExists) {
                // Update existing config file
                const lines = configContent.split('\n');
                let modeLineFound = false;
                // Find and update the DEFAULT_MODE line
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].startsWith('DEFAULT_MODE=')) {
                        lines[i] = `DEFAULT_MODE=${mode}`;
                        modeLineFound = true;
                        break;
                    }
                }
                // If the line doesn't exist, add it after the Azure OpenAI section
                if (!modeLineFound) {
                    let insertIndex = -1;
                    for (let i = 0; i < lines.length; i++) {
                        if (lines[i].startsWith('AZURE_OPENAI_GPT_DEPLOYMENT=')) {
                            insertIndex = i + 1;
                            break;
                        }
                    }
                    const newLine = `DEFAULT_MODE=${mode}`;
                    if (insertIndex >= 0) {
                        // Add empty line and comment before the setting
                        lines.splice(insertIndex, 0, '', '# Default formatting mode (default, email, code, message, slack, pro-casual)', newLine);
                    }
                    else {
                        // If Azure section not found, add at the end
                        lines.push('');
                        lines.push('# Default formatting mode (default, email, code, message, slack, pro-casual)');
                        lines.push(newLine);
                    }
                }
                configContent = lines.join('\n');
            }
            else {
                // Create new config file with the mode setting
                const configDir = path.dirname(twhisperConfigPath);
                try {
                    await fs.access(configDir);
                }
                catch {
                    await fs.mkdir(configDir, { recursive: true });
                }
                configContent = this.generateConfigContent({ mode });
            }
            // Write the updated config
            await fs.writeFile(twhisperConfigPath, configContent, 'utf-8');
            // Update the in-memory configuration as well
            if (this.configuration) {
                this.configuration.app.defaultMode = mode;
            }
            utilDebugLog(`✅ [ConfigurationService] Persisted formatting mode change to: ${mode}`);
        }
        catch (error) {
            console.warn(`⚠️  Failed to persist formatting mode to config file: ${error instanceof Error ? error.message : 'Unknown error'}`);
            throw new AppError('Failed to persist formatting mode to config file', ErrorCode.FILE_OPERATION_ERROR, { mode, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Generate config content with language setting
     */
    /**
     * Show welcome message for first-run users
     */
    showFirstRunWelcome(twhisperConfigPath) {
        console.log('\n🚀 Welcome to Twhisper!\n');
        console.log(`📝 A default configuration file has been created at:`);
        console.log(`   ${twhisperConfigPath}\n`);
        console.log('🔧 To get started:');
        console.log('1. Edit the configuration file above');
        console.log('2. Replace the Azure OpenAI placeholder values with your actual credentials:');
        console.log('   - AZURE_OPENAI_API_KEY=your_actual_api_key');
        console.log('   - AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com');
        console.log('   - AZURE_OPENAI_WHISPER_DEPLOYMENT=your-whisper-deployment');
        console.log('   - AZURE_OPENAI_GPT_DEPLOYMENT=your-gpt-deployment');
        console.log('3. Adjust other settings as needed for your use case');
        console.log('4. Run Twhisper again to test your configuration\n');
        console.log('🌍 Alternative: You can also set these as environment variables instead');
        console.log('📚 For more help: https://github.com/svenmalvik/Twhisper#configuration\n');
    }
}
//# sourceMappingURL=ConfigurationService.js.map