import { promises as fs } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
export class AuthenticationService {
    constructor(configService) {
        this.configService = configService;
        // Get config directory from environment or default to ~/.twhisper/auth
        this.configDir = process.env.AUTH_CONFIG_DIR?.replace('~', homedir()) ||
            join(homedir(), '.twhisper', 'auth');
        this.configFile = join(this.configDir, 'config.json');
    }
    getAuthConfig() {
        const config = this.configService.getConfiguration();
        if (!config) {
            throw new Error('Configuration not loaded. Please run twhisper with proper configuration.');
        }
        if (!config.auth.enabled) {
            throw new Error('Authentication is disabled in configuration.');
        }
        return {
            supabaseUrl: config.auth.supabaseUrl,
            anonKey: config.auth.supabaseAnonKey
        };
    }
    async ensureConfigDir() {
        try {
            // Check if the path exists and handle conflicts
            const parentDir = join(homedir(), '.twhisper');
            try {
                const stats = await fs.stat(parentDir);
                if (stats.isFile()) {
                    // Move existing .twhisper file into the new directory structure
                    const tempPath = parentDir + '.temp';
                    await fs.rename(parentDir, tempPath);
                    // Create the directory structure
                    await fs.mkdir(this.configDir, { recursive: true });
                    // Move the old config file to the new location as config.json
                    await fs.rename(tempPath, join(parentDir, 'config.json'));
                    console.log('✅ Migrated existing .twhisper config file to ~/.twhisper/config.json');
                }
                else {
                    // Directory already exists, just ensure auth subdirectory
                    await fs.mkdir(this.configDir, { recursive: true });
                }
            }
            catch {
                // Path doesn't exist, create the directory structure
                await fs.mkdir(this.configDir, { recursive: true });
            }
        }
        catch (error) {
            throw new Error(`Failed to create config directory: ${error}`);
        }
    }
    async saveConfig(config) {
        await this.ensureConfigDir();
        try {
            await fs.writeFile(this.configFile, JSON.stringify(config, null, 2), 'utf-8');
        }
        catch (error) {
            throw new Error(`Failed to save auth config: ${error}`);
        }
    }
    async loadConfig() {
        try {
            const content = await fs.readFile(this.configFile, 'utf-8');
            return JSON.parse(content);
        }
        catch {
            // Config file doesn't exist or is invalid
            return null;
        }
    }
    async clearConfig() {
        try {
            await fs.unlink(this.configFile);
        }
        catch {
            // File doesn't exist, ignore
        }
    }
    async isAuthenticated() {
        const config = await this.loadConfig();
        if (!config?.sessionToken || !config?.expiresAt) {
            return false;
        }
        // Check if session is expired locally first (quick check)
        const expiresAt = new Date(config.expiresAt);
        if (expiresAt <= new Date()) {
            await this.clearConfig();
            return false;
        }
        // Perform server-side session validation
        try {
            const { supabaseUrl } = this.getAuthConfig();
            const response = await fetch(`${supabaseUrl}/functions/v1/validate-session`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                    // Note: No Authorization header needed since function uses --no-verify-jwt
                },
                body: JSON.stringify({
                    session_token: config.sessionToken
                })
            });
            const result = await response.json();
            if (!result.success) {
                // Only clear config if server explicitly says the token is invalid
                // Don't clear on network errors or server issues
                if (result.error?.code === 'invalid_token' || result.error?.code === 'user_not_found') {
                    await this.clearConfig();
                    return false;
                }
                // For other errors, fall back to local validation but log the issue
                console.warn('Server validation failed, falling back to local validation:', result.error);
                return true;
            }
            // If session was renewed, update local config
            if (result.data?.renewed_token) {
                const updatedConfig = {
                    ...config,
                    sessionToken: result.data.renewed_token,
                    expiresAt: result.data.session.expires_at
                };
                await this.saveConfig(updatedConfig);
            }
            return true;
        }
        catch (error) {
            // Network error or server unavailable - fall back to local validation
            // This allows offline usage and prevents clearing valid tokens due to network issues
            console.warn('Unable to validate session with server, using local validation:', error);
            return true;
        }
    }
    async initiateDeviceFlow() {
        try {
            const { supabaseUrl, anonKey } = this.getAuthConfig();
            const response = await fetch(`${supabaseUrl}/functions/v1/auth`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${anonKey}`
                },
                body: JSON.stringify({})
            });
            const data = await response.json();
            return data;
        }
        catch (error) {
            return {
                success: false,
                error: {
                    code: 'network_error',
                    message: `Network error: ${error}`
                }
            };
        }
    }
    async pollForToken(deviceCode) {
        try {
            const { supabaseUrl, anonKey } = this.getAuthConfig();
            const response = await fetch(`${supabaseUrl}/functions/v1/auth`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${anonKey}`
                },
                body: JSON.stringify({
                    poll: true,
                    device_code: deviceCode
                })
            });
            const data = await response.json();
            return data;
        }
        catch (error) {
            return {
                success: false,
                error: {
                    code: 'network_error',
                    message: `Network error: ${error}`
                }
            };
        }
    }
    async logout() {
        const config = await this.loadConfig();
        if (!config?.sessionToken) {
            return {
                success: false,
                error: {
                    code: 'not_authenticated',
                    message: 'No active session found'
                }
            };
        }
        try {
            const { supabaseUrl, anonKey } = this.getAuthConfig();
            const response = await fetch(`${supabaseUrl}/functions/v1/logout`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${anonKey}`
                },
                body: JSON.stringify({
                    session_token: config.sessionToken
                })
            });
            const data = await response.json();
            // Clear local config regardless of server response
            await this.clearConfig();
            return data;
        }
        catch (error) {
            // Clear local config even if network request failed
            await this.clearConfig();
            return {
                success: false,
                error: {
                    code: 'network_error',
                    message: `Network error: ${error}`
                }
            };
        }
    }
    async getCurrentUser() {
        const config = await this.loadConfig();
        if (!config || !await this.isAuthenticated()) {
            return null;
        }
        return config;
    }
}
//# sourceMappingURL=AuthenticationService.js.map