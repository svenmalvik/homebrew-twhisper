import { ITranscriptionService, TranscriptionOptions, TranscriptionResult } from '../interfaces/interfaces.js';
import { IFileService } from '../interfaces/interfaces.js';
export declare class TranscriptionService extends ITranscriptionService {
    private apiKey;
    private endpoint;
    private apiVersion;
    private whisperDeployment;
    private fileService;
    private isInitialized;
    private configuration?;
    constructor(apiKey: string, endpoint: string, apiVersion: string, whisperDeployment: string, fileService: IFileService, configuration?: {
        whisper?: {
            language?: string;
        };
    });
    private extractResourceName;
    private callWhisperAPI;
    transcribe(audioBuffer: Buffer, options?: TranscriptionOptions): Promise<TranscriptionResult>;
    private createTempAudioFile;
    private handleTranscriptionError;
    checkAvailability(): Promise<boolean>;
    getSupportedFormats(): string[];
    /**
     * Implement retry logic for transcription with exponential backoff
     */
    transcribeWithRetry(audioBuffer: Buffer, options?: TranscriptionOptions, maxRetries?: number): Promise<TranscriptionResult>;
}
//# sourceMappingURL=TranscriptionService.d.ts.map