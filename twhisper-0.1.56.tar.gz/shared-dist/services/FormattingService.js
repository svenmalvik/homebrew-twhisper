import { IFormattingService } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
export class FormattingService extends IFormattingService {
    constructor(apiKey, endpoint, apiVersion, gptDeployment) {
        super();
        this.gptDeployment = gptDeployment;
        this.isInitialized = false;
        if (!apiKey || !endpoint || !apiVersion || !gptDeployment) {
            throw new AppError('Missing required Azure OpenAI configuration for formatting', ErrorCode.CONFIGURATION_ERROR, { apiKey: !!apiKey, endpoint: !!endpoint, apiVersion: !!apiVersion, deployment: !!gptDeployment });
        }
        this.apiKey = apiKey;
        this.endpoint = endpoint;
        this.apiVersion = apiVersion;
        this.resourceName = this.extractResourceName(endpoint);
        this.isInitialized = true;
    }
    extractResourceName(endpoint) {
        try {
            const url = new URL(endpoint);
            return url.hostname.split('.')[0];
        }
        catch (error) {
            throw new AppError('Invalid Azure OpenAI endpoint URL', ErrorCode.CONFIGURATION_ERROR, { endpoint, error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    async format(text, mode, options = {}) {
        if (!this.isInitialized) {
            throw new AppError('FormattingService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        if (!text || text.trim().length === 0) {
            throw new AppError('No text provided for formatting', ErrorCode.INVALID_INPUT);
        }
        const startTime = Date.now();
        this.emit('formatting:started', { text: text.substring(0, 100), mode: mode.name });
        try {
            this.emit('formatting:progress', { stage: 'processing', progress: 0.5 });
            // Create messages for GPT chat completion
            const messages = [
                {
                    role: "system",
                    content: mode.systemPrompt
                },
                {
                    role: "user",
                    content: `Here is the transcribed text to format:\n\n"${text}"\n\nPlease provide only the formatted text without any additional commentary or explanations.`
                }
            ];
            // Construct API URL
            const apiUrl = `https://${this.resourceName}.openai.azure.com/openai/deployments/${this.gptDeployment}/chat/completions?api-version=${this.apiVersion}`;
            // Make request to Azure OpenAI
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': this.apiKey,
                },
                body: JSON.stringify({
                    messages,
                    temperature: options.temperature || 0.3,
                    max_tokens: options.maxTokens || 1000,
                }),
            });
            if (!response.ok) {
                const errorText = await response.text();
                let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
                try {
                    const errorJson = JSON.parse(errorText);
                    if (errorJson.error && errorJson.error.message) {
                        errorMessage = errorJson.error.message;
                    }
                }
                catch {
                    // Keep the HTTP status message if JSON parsing fails
                }
                throw new Error(errorMessage);
            }
            const result = await response.json();
            this.emit('formatting:progress', { stage: 'completed', progress: 1.0 });
            const processingTime = Date.now() - startTime;
            // Extract the formatted text from the response
            const formattedText = result.choices?.[0]?.message?.content?.trim() || '';
            const tokensUsed = result.usage?.total_tokens || 0;
            const formattingResult = {
                formattedText,
                originalText: text,
                mode: mode.name,
                tokensUsed,
                model: this.gptDeployment,
                processingTime,
            };
            this.emit('formatting:completed', formattingResult);
            return formattingResult;
        }
        catch (error) {
            const appError = this.handleFormattingError(error);
            this.emit('formatting:error', appError);
            throw appError;
        }
    }
    getModePrompt(mode, text, options) {
        const basePrompt = options.customPrompt || mode.systemPrompt;
        return `${basePrompt}

Here is the transcribed text to format:

"${text}"

Please provide only the formatted text without any additional commentary or explanations.`;
    }
    handleFormattingError(error) {
        if (error instanceof AppError) {
            return error;
        }
        if (error instanceof Error) {
            // Check for specific Azure OpenAI errors
            if (error.message.includes('401') || error.message.includes('unauthorized')) {
                return new AppError('Invalid Azure OpenAI API key or insufficient permissions', ErrorCode.AUTHENTICATION_ERROR, { originalError: error.message });
            }
            if (error.message.includes('404') || error.message.includes('not found')) {
                return new AppError('Azure OpenAI GPT deployment not found', ErrorCode.SERVICE_UNAVAILABLE, { deployment: this.gptDeployment, originalError: error.message });
            }
            if (error.message.includes('429') || error.message.includes('rate limit')) {
                return new AppError('Azure OpenAI rate limit exceeded', ErrorCode.RATE_LIMIT_EXCEEDED, { originalError: error.message });
            }
            if (error.message.includes('timeout') || error.message.includes('network')) {
                return new AppError('Network error during text formatting', ErrorCode.NETWORK_ERROR, { originalError: error.message });
            }
            if (error.message.includes('content_filter') || error.message.includes('content policy')) {
                return new AppError('Text formatting blocked by content policy', ErrorCode.CONTENT_POLICY_VIOLATION, { originalError: error.message });
            }
        }
        return new AppError('Text formatting failed', ErrorCode.FORMATTING_FAILED, { originalError: error instanceof Error ? error.message : 'Unknown error' });
    }
    async checkAvailability() {
        if (!this.isInitialized) {
            return false;
        }
        try {
            // Test with a minimal formatting request
            const testMode = {
                name: 'test',
                description: 'Test mode',
                systemPrompt: 'Please return the text exactly as provided.',
                examples: []
            };
            const result = await this.format('test', testMode, { maxTokens: 10, temperature: 0 });
            return result.formattedText.length > 0;
        }
        catch (error) {
            this.emit('availability:check:failed', error);
            return false;
        }
    }
    getAvailableModels() {
        // Return common Azure OpenAI GPT model deployments
        return ['gpt-4.1'];
    }
    /**
     * Format text with retry logic and exponential backoff
     */
    async formatWithRetry(text, mode, options = {}, maxRetries = 3) {
        let lastError;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return await this.format(text, mode, options);
            }
            catch (error) {
                lastError = error instanceof AppError ? error : new AppError('Formatting attempt failed', ErrorCode.FORMATTING_FAILED, { attempt, error: error instanceof Error ? error.message : 'Unknown error' });
                // Don't retry on authentication, configuration, or content policy errors
                if (lastError.code === ErrorCode.AUTHENTICATION_ERROR ||
                    lastError.code === ErrorCode.CONFIGURATION_ERROR ||
                    lastError.code === ErrorCode.SERVICE_NOT_INITIALIZED ||
                    lastError.code === ErrorCode.CONTENT_POLICY_VIOLATION) {
                    throw lastError;
                }
                // Wait before retry with exponential backoff
                if (attempt < maxRetries) {
                    const delay = Math.min(1000 * Math.pow(2, attempt - 1), 10000);
                    this.emit('formatting:retry', { attempt, delay, error: lastError });
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError || new AppError('All formatting attempts failed', ErrorCode.FORMATTING_FAILED, { maxRetries });
    }
    /**
     * Get formatting statistics for monitoring
     */
    getFormattingStats() {
        // This would typically be implemented with proper metrics collection
        // For now, return placeholder values
        return {
            totalRequests: 0,
            successRate: 1.0,
            averageProcessingTime: 0,
            totalTokensUsed: 0,
        };
    }
}
//# sourceMappingURL=FormattingService.js.map