import { ITranscriptionService, TranscriptionOptions, TranscriptionResult } from '../interfaces/interfaces.js';
/**
 * Local transcription service for batch mode using whisper.cpp
 * Provides offline transcription without requiring Azure OpenAI
 */
export declare class LocalTranscriptionService extends ITranscriptionService {
    private localWhisper;
    private isInitialized;
    constructor();
    transcribe(audioBuffer: Buffer, options?: TranscriptionOptions): Promise<TranscriptionResult>;
    private handleTranscriptionError;
    checkAvailability(): Promise<boolean>;
    getSupportedFormats(): string[];
    /**
     * Implement retry logic for transcription with exponential backoff
     */
    transcribeWithRetry(audioBuffer: Buffer, options?: TranscriptionOptions, maxRetries?: number): Promise<TranscriptionResult>;
    /**
     * Get model information
     */
    getModelInfo(): {
        name: string;
        type: string;
        local: boolean;
        gpu: boolean;
        size: string;
    };
}
//# sourceMappingURL=LocalTranscriptionService.d.ts.map