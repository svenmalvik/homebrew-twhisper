import { AppError, ErrorCode } from '../../types/index.js';
import { spawn } from 'child_process';
import fs from 'fs/promises';
import path from 'path';
import os from 'os';
import { debugLog } from '../../utils/debug.js';
/**
 * Local Whisper transcription service using whisper.cpp
 * Optimized for Apple Silicon with GPU acceleration
 * Provides fast, offline transcription for streaming mode
 */
export class LocalWhisperService {
    constructor(configuration) {
        this.whisperPath = null;
        this.modelPath = null;
        this.isInitialized = false;
        this.instanceId = Math.random().toString(36).substring(7); // Add instance tracking
        this.initializationPromise = null;
        this.initializationFailed = false;
        this.activeProcesses = new Set();
        this.concurrencyQueue = [];
        this.maxConcurrentProcesses = 1; // Use single process for streaming to avoid resource contention
        this.configuration = null;
        this.configuration = configuration || null;
        this.tempDir = path.join(os.tmpdir(), 'twhisper-local');
        debugLog(`🏗️ [LocalWhisper] [${this.instanceId}] New LocalWhisperService instance created`);
        // Don't initialize automatically - only when actually needed
    }
    /**
     * Initialize the local Whisper model
     */
    async initializeModel() {
        // If already initialized successfully, return immediately
        if (this.isInitialized) {
            return;
        }
        // If there's an ongoing initialization, wait for it
        if (this.initializationPromise) {
            return this.initializationPromise;
        }
        // If previous initialization failed, reset and try again
        if (this.initializationFailed) {
            debugLog('⚠️ [LocalWhisper] Previous initialization failed, retrying...');
            this.initializationFailed = false;
        }
        this.initializationPromise = this.doInitializeModel();
        return this.initializationPromise;
    }
    async doInitializeModel() {
        try {
            debugLog(`🤖 [LocalWhisper] [${this.instanceId}] Initializing whisper.cpp for streaming mode...`);
            // Create temp directory
            debugLog('📁 [LocalWhisper] Creating temp directory:', this.tempDir);
            await fs.mkdir(this.tempDir, { recursive: true });
            // Check for whisper.cpp installation
            debugLog('🔍 [LocalWhisper] Finding whisper binary...');
            await this.findWhisperBinary();
            debugLog('🔍 [LocalWhisper] Finding whisper model...');
            await this.findOrDownloadModel();
            this.isInitialized = true;
            this.initializationPromise = null; // Clear promise after success
            debugLog('✅ [LocalWhisper] whisper.cpp initialized with Apple Silicon GPU acceleration');
        }
        catch (error) {
            console.error('❌ [LocalWhisper] Failed to initialize:', error);
            // Mark initialization as failed and clear promise so retries are possible
            this.initializationFailed = true;
            this.initializationPromise = null;
            // Create a more helpful error message
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            let installInstructions = '';
            if (errorMessage.includes('whisper.cpp not found')) {
                installInstructions = '\n\nTo enable streaming mode:\n1. Install whisper.cpp: brew install whisper-cpp\n2. Download model: mkdir -p ~/.whisper && curl -L "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin" -o ~/.whisper/ggml-tiny.en.bin';
            }
            else if (errorMessage.includes('Whisper model not found')) {
                installInstructions = '\n\nTo enable streaming mode:\n1. Download model: mkdir -p ~/.whisper && curl -L "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin" -o ~/.whisper/ggml-tiny.en.bin';
            }
            throw new AppError(`Streaming mode unavailable: ${errorMessage}${installInstructions}`, ErrorCode.SERVICE_NOT_INITIALIZED, { error: errorMessage, mode: 'streaming' });
        }
    }
    /**
     * Find whisper.cpp binary (not Python whisper)
     */
    async findWhisperBinary() {
        // Try whisper-cpp specific binaries first
        const possiblePaths = [
            '/opt/homebrew/bin/whisper-cli', // Homebrew whisper-cpp on Apple Silicon (new)
            '/usr/local/bin/whisper-cli', // Homebrew whisper-cpp on Intel (new)
            '/opt/homebrew/bin/whisper-cpp', // Homebrew whisper-cpp on Apple Silicon (deprecated)
            '/usr/local/bin/whisper-cpp', // Homebrew whisper-cpp on Intel (deprecated)
            '/opt/homebrew/bin/main', // whisper.cpp main binary on Apple Silicon
            '/usr/local/bin/main', // whisper.cpp main binary on Intel
            './main', // Local whisper.cpp build
            './whisper-cli', // Alternative name
            './whisper-cpp', // Alternative name
            'whisper-cli', // In PATH (new)
            'whisper-cpp' // In PATH (deprecated)
        ];
        for (const whisperPath of possiblePaths) {
            try {
                debugLog(`🔍 [LocalWhisper] Testing binary: ${whisperPath}`);
                await this.testWhisperCppBinary(whisperPath);
                this.whisperPath = whisperPath;
                debugLog(`✅ [LocalWhisper] Found whisper.cpp at: ${whisperPath}`);
                return;
            }
            catch (error) {
                debugLog(`❌ [LocalWhisper] Binary test failed for ${whisperPath}:`, error instanceof Error ? error.message : error);
                continue;
            }
        }
        throw new AppError('whisper.cpp not found. Please install with: brew install whisper-cpp', ErrorCode.SERVICE_NOT_INITIALIZED, {
            suggestion: 'Install whisper.cpp with: brew install whisper-cpp',
            possiblePaths,
            note: 'Make sure to install whisper.cpp (C++ version), not Python whisper'
        });
    }
    /**
     * Test if whisper.cpp binary works (not Python whisper)
     */
    async testWhisperCppBinary(binaryPath) {
        return new Promise((resolve, reject) => {
            const child = spawn(binaryPath, ['--help'], { stdio: 'pipe' });
            let stdout = '';
            let stderr = '';
            child.stdout?.on('data', (data) => {
                stdout += data.toString();
            });
            child.stderr?.on('data', (data) => {
                stderr += data.toString();
            });
            child.on('error', reject);
            child.on('close', (code) => {
                const output = stdout + stderr; // Combine both outputs
                // Check if this is whisper.cpp (should mention model file or have specific whisper.cpp help format)
                if (code === 0 && (output.includes('--model') || output.includes('whisper-cli') || output.includes('supported audio formats'))) {
                    resolve();
                }
                else if (output.includes('openai-whisper') || output.includes('--output_format')) {
                    // This is Python whisper, not whisper.cpp
                    reject(new Error(`Found Python whisper instead of whisper.cpp at ${binaryPath}`));
                }
                else {
                    reject(new Error(`whisper.cpp binary test failed with code ${code}. stdout: ${stdout}, stderr: ${stderr}`));
                }
            });
        });
    }
    /**
     * Find or download Whisper model based on configuration
     */
    async findOrDownloadModel() {
        // Get preferred model size from configuration, default to 'small'
        const preferredSize = this.configuration?.whisper?.modelSize || 'small';
        debugLog(`🔍 [LocalWhisper] Looking for models with preference: ${preferredSize}`);
        // First, try to find the EXACT preferred model
        if (await this.findSpecificModel(preferredSize)) {
            return; // Found exact match, we're done
        }
        // If preferred model not found, try to download it first before falling back
        debugLog(`📦 [LocalWhisper] Preferred model '${preferredSize}' not found, attempting download...`);
        try {
            await this.downloadDefaultModel(preferredSize);
            return; // Download successful
        }
        catch (error) {
            debugLog(`⚠️ [LocalWhisper] Failed to download preferred model '${preferredSize}':`, error);
            // Continue to fallback logic
        }
        // Fallback: Try to find other models as backup
        debugLog(`🔄 [LocalWhisper] Trying fallback models...`);
        const fallbackSizes = ['small', 'tiny', 'base', 'medium'].filter(size => size !== preferredSize);
        for (const size of fallbackSizes) {
            if (await this.findSpecificModel(size)) {
                debugLog(`⚠️ [LocalWhisper] Using fallback model '${size}' instead of preferred '${preferredSize}'`);
                return;
            }
        }
        // No model found at all, download tiny as last resort
        debugLog(`📦 [LocalWhisper] No models found, downloading tiny as last resort...`);
        await this.downloadDefaultModel('tiny');
    }
    /**
     * Try to find a specific model size - EXACT match only
     */
    async findSpecificModel(modelSize) {
        // Only look for the exact model requested, no fallbacks
        const possibleModelPaths = [
            `/opt/homebrew/share/whisper.cpp/ggml-${modelSize}.bin`, // Homebrew Apple Silicon
            `/usr/local/share/whisper.cpp/ggml-${modelSize}.bin`, // Homebrew Intel
            `./models/ggml-${modelSize}.bin`, // Local models directory
            path.join(os.homedir(), `.whisper/ggml-${modelSize}.bin`) // User directory
        ];
        for (const modelPath of possibleModelPaths) {
            try {
                await fs.access(modelPath);
                this.modelPath = modelPath;
                const fileStats = await fs.stat(modelPath);
                const sizeInMB = (fileStats.size / (1024 * 1024)).toFixed(0);
                debugLog(`✅ [LocalWhisper] Found exact ${modelSize} model at: ${modelPath} (${sizeInMB}MB)`);
                return true;
            }
            catch {
                continue;
            }
        }
        debugLog(`❌ [LocalWhisper] Exact model ${modelSize} not found`);
        return false;
    }
    /**
     * Download the specified model to ~/.whisper directory
     */
    async downloadDefaultModel(modelSize = 'tiny') {
        // Use exact model name as specified, don't force .en suffix
        const modelName = modelSize.includes('.') ? modelSize : modelSize; // Keep as-is
        const defaultModelUrl = `https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-${modelName}.bin`;
        const whisperDir = path.join(os.homedir(), '.whisper');
        const modelPath = path.join(whisperDir, `ggml-${modelName}.bin`);
        try {
            // Create ~/.whisper directory if it doesn't exist
            debugLog('📁 [LocalWhisper] Creating ~/.whisper directory...');
            await fs.mkdir(whisperDir, { recursive: true });
            // Show user feedback for download start
            console.log(`\n📦 Downloading Whisper model: ${modelName}`);
            console.log(`🌐 Source: ${defaultModelUrl}`);
            console.log(`📁 Destination: ${modelPath}`);
            debugLog(`⬇️ [LocalWhisper] Downloading model from: ${defaultModelUrl}`);
            debugLog(`📍 [LocalWhisper] Saving to: ${modelPath}`);
            // Use fetch to download the model
            const response = await fetch(defaultModelUrl);
            if (!response.ok) {
                throw new Error(`Failed to download model: HTTP ${response.status} ${response.statusText}`);
            }
            if (!response.body) {
                throw new Error('No response body received');
            }
            // Get content length for progress tracking
            const contentLength = response.headers.get('content-length');
            const totalSize = contentLength ? parseInt(contentLength, 10) : 0;
            let downloadedSize = 0;
            // Show download size info to user
            if (totalSize > 0) {
                console.log(`📊 Model size: ${Math.round(totalSize / 1024 / 1024)}MB`);
                console.log(`⏳ Download starting...`);
            }
            else {
                console.log(`⏳ Download starting (unknown size)...`);
            }
            debugLog(`📦 [LocalWhisper] Starting download (${totalSize > 0 ? `${Math.round(totalSize / 1024 / 1024)}MB` : 'unknown size'})...`);
            // Create write stream
            const fileHandle = await fs.open(modelPath, 'w');
            const writeStream = fileHandle.createWriteStream();
            // Track download progress
            const reader = response.body.getReader();
            let lastProgressLog = 0;
            try {
                let done = false;
                while (!done) {
                    const result = await reader.read();
                    done = result.done;
                    const value = result.value;
                    if (done)
                        break;
                    await new Promise((resolve, reject) => {
                        writeStream.write(value, (error) => {
                            if (error)
                                reject(error);
                            else
                                resolve();
                        });
                    });
                    downloadedSize += value.length;
                    // Show progress to user every 5MB or 10% progress, whichever is more frequent
                    const progressInterval = Math.min(10 * 1024 * 1024, totalSize * 0.1); // 10MB or 10%
                    if (totalSize > 0 && (downloadedSize - lastProgressLog > progressInterval || downloadedSize >= totalSize)) {
                        const progress = Math.round((downloadedSize / totalSize) * 100);
                        const downloadedMB = Math.round(downloadedSize / 1024 / 1024);
                        const totalMB = Math.round(totalSize / 1024 / 1024);
                        // Use process.stdout.write for same-line updates
                        process.stdout.write(`\r⏬ Progress: ${progress}% (${downloadedMB}MB/${totalMB}MB)`);
                        // Debug log (less frequent)
                        if (downloadedSize - lastProgressLog > 10 * 1024 * 1024 || downloadedSize >= totalSize) {
                            debugLog(`📊 [LocalWhisper] Download progress: ${progress}% (${downloadedMB}MB/${totalMB}MB)`);
                        }
                        lastProgressLog = downloadedSize;
                    }
                }
            }
            finally {
                writeStream.end();
                await fileHandle.close();
            }
            // Verify the downloaded file
            const stats = await fs.stat(modelPath);
            // Clear the progress line and show completion message
            process.stdout.write('\r'); // Clear current line
            console.log(`✅ Download completed successfully!`);
            console.log(`📏 Final size: ${Math.round(stats.size / 1024 / 1024)}MB`);
            console.log(`📂 Model saved to: ${modelPath}\n`);
            debugLog(`✅ [LocalWhisper] Model downloaded successfully: ${Math.round(stats.size / 1024 / 1024)}MB`);
            // Set the model path
            this.modelPath = modelPath;
        }
        catch (error) {
            // Clear progress line and show error
            process.stdout.write('\r'); // Clear current line
            console.log(`❌ Download failed!`);
            // Clean up partial download
            try {
                await fs.unlink(modelPath);
                console.log(`🗑️ Cleaned up partial download`);
            }
            catch {
                // Ignore cleanup errors
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            console.log(`💡 Error: ${errorMessage}`);
            console.log(`💡 You can try downloading manually:`);
            console.log(`   mkdir -p ~/.whisper`);
            console.log(`   curl -L "${defaultModelUrl}" -o "${modelPath}"`);
            console.log('');
            debugLog(`❌ [LocalWhisper] Failed to download model: ${errorMessage}`);
            throw new AppError(`Failed to download Whisper model: ${errorMessage}`, ErrorCode.SERVICE_NOT_INITIALIZED, {
                suggestion: 'Check your internet connection and try again',
                manual: `Or download manually: mkdir -p ~/.whisper && curl -L "${defaultModelUrl}" -o "${modelPath}"`,
                downloadUrl: defaultModelUrl,
                targetPath: modelPath
            });
        }
    }
    /**
     * Transcribe audio buffer using local Whisper model
     */
    async transcribe(audioBuffer, options = {}) {
        const chunkId = Math.random().toString(36).substring(7);
        debugLog(`🎤 [LocalWhisper] [${this.instanceId}:${chunkId}] Starting transcription...`);
        debugLog(`🔍 [LocalWhisper] [${this.instanceId}:${chunkId}] Instance state - initialized: ${this.isInitialized}, failed: ${this.initializationFailed}`);
        // Handle empty or invalid buffers
        if (!audioBuffer || audioBuffer.length === 0) {
            debugLog(`⚠️ [LocalWhisper] [${chunkId}] Empty audio buffer, returning blank result`);
            return {
                text: '',
                confidence: 0,
                duration: 0,
                wordCount: 0,
                language: options.language || 'en'
            };
        }
        try {
            // Ensure model is initialized - handle concurrent initialization properly
            if (!this.isInitialized && !this.initializationFailed) {
                debugLog(`🔄 [LocalWhisper] [${chunkId}] Initializing model...`);
                await this.initializeModel();
            }
            else if (this.initializationFailed) {
                debugLog(`❌ [LocalWhisper] [${chunkId}] Service previously failed to initialize`);
                throw new AppError('Local whisper service previously failed to initialize', ErrorCode.SERVICE_NOT_INITIALIZED);
            }
            if (!this.whisperPath || !this.modelPath) {
                debugLog(`❌ [LocalWhisper] [${chunkId}] Missing whisperPath or modelPath:`, { whisperPath: this.whisperPath, modelPath: this.modelPath });
                throw new AppError('Whisper not properly initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
            }
            debugLog(`✅ [LocalWhisper] [${chunkId}] Using whisper at:`, this.whisperPath);
            debugLog(`✅ [LocalWhisper] [${chunkId}] Using model at:`, this.modelPath);
            const startTime = Date.now();
            // Write audio buffer to temporary WAV file
            const tempAudioFile = path.join(this.tempDir, `audio_${chunkId}_${Date.now()}.wav`);
            debugLog(`💾 [LocalWhisper] [${chunkId}] STORING AUDIO: Writing ${audioBuffer.length} bytes to ${tempAudioFile}`);
            await this.writeBufferAsWav(audioBuffer, tempAudioFile);
            debugLog(`✅ [LocalWhisper] [${chunkId}] AUDIO STORED: File written successfully`);
            // Check if file exists and get size
            try {
                const stats = await fs.stat(tempAudioFile);
                debugLog(`📊 [LocalWhisper] [${chunkId}] WAV file size: ${stats.size} bytes`);
            }
            catch {
                debugLog(`❌ [LocalWhisper] [${chunkId}] ERROR: Could not stat WAV file`);
            }
            // Run whisper.cpp with concurrency control
            const transcriptionText = await this.runWhisperWithConcurrencyControl(tempAudioFile, options, chunkId);
            // Clean up temp file
            debugLog(`🗑️ [LocalWhisper] [${chunkId}] DELETING AUDIO: Removing ${tempAudioFile}`);
            await fs.unlink(tempAudioFile).catch((err) => {
                debugLog(`⚠️ [LocalWhisper] [${chunkId}] CLEANUP WARNING: Could not delete temp file:`, err.message);
            });
            debugLog(`✅ [LocalWhisper] [${chunkId}] AUDIO DELETED: Temp file cleaned up`);
            debugLog(`📝 [LocalWhisper] [${chunkId}] TRANSCRIPTION RESULT: "${transcriptionText}"`);
            debugLog(`📝 [LocalWhisper] [${chunkId}] TEXT LENGTH: ${transcriptionText.length} characters`);
            const endTime = Date.now();
            const duration = endTime - startTime;
            // Format result
            const transcriptionResult = {
                text: transcriptionText.trim(),
                confidence: this.estimateConfidence(transcriptionText.trim()),
                duration,
                wordCount: transcriptionText.trim().split(/\s+/).filter(word => word.length > 0).length,
                language: options.language || 'en'
            };
            debugLog(`✅ [LocalWhisper] [${chunkId}] Transcription completed in ${duration}ms`);
            return transcriptionResult;
        }
        catch (error) {
            console.error(`❌ [LocalWhisper] [${chunkId}] Transcription failed:`, error);
            throw new AppError('Local Whisper transcription failed', ErrorCode.RECORDING_ERROR, // Use existing error code
            {
                error: error instanceof Error ? error.message : 'Unknown error',
                options,
                chunkId
            });
        }
    }
    /**
     * Run whisper with concurrency control
     */
    async runWhisperWithConcurrencyControl(audioFile, options, chunkId) {
        // Wait for available slot if we're at max concurrency
        while (this.concurrencyQueue.length >= this.maxConcurrentProcesses) {
            debugLog(`🚦 [LocalWhisper] [${chunkId}] Waiting for available slot (${this.concurrencyQueue.length}/${this.maxConcurrentProcesses} active)`);
            await Promise.race(this.concurrencyQueue);
        }
        // Create the transcription promise and add to queue
        const transcriptionPromise = this.runWhisper(audioFile, options, chunkId);
        this.concurrencyQueue.push(transcriptionPromise);
        try {
            const result = await transcriptionPromise;
            return result;
        }
        finally {
            // Remove from queue when done
            const index = this.concurrencyQueue.indexOf(transcriptionPromise);
            if (index > -1) {
                this.concurrencyQueue.splice(index, 1);
            }
        }
    }
    /**
     * Run whisper-cli with optimized settings for Apple Silicon
     */
    async runWhisper(audioFile, options, chunkId = 'unknown') {
        return new Promise((resolve, reject) => {
            // Get language from configuration, fallback to options, then default to 'en'
            const configLanguage = this.configuration?.whisper?.language;
            const language = configLanguage || options.language || 'en';
            const args = [
                '-m', this.modelPath, // Model path
                '-l', language, // Language (en, no, da, fi)
                '-nt', // No timestamps for streaming
                '-t', '4', // Use 4 threads
                '-p', '1', // Single processor for consistency
                '-np', // No prints (quiet output)
                '--output-txt', // Output as text to stdout
                audioFile // Audio file as positional argument
            ];
            // Add Apple Silicon GPU optimization if available (disable no-gpu)
            if (process.arch === 'arm64' && process.platform === 'darwin') {
                // Don't add --no-gpu to enable GPU acceleration on Apple Silicon
                debugLog(`🚀 [LocalWhisper] [${chunkId}] Using Apple Silicon GPU acceleration`);
            }
            else {
                args.push('--no-gpu'); // Disable GPU on non-Apple Silicon
            }
            debugLog(`🚀 [LocalWhisper] [${chunkId}] Running command:`, this.whisperPath, args.join(' '));
            const child = spawn(this.whisperPath, args, {
                stdio: ['pipe', 'pipe', 'pipe'],
                cwd: this.tempDir
            });
            // Track active process
            this.activeProcesses.add(child);
            let stdout = '';
            let stderr = '';
            child.stdout?.on('data', (data) => {
                const output = data.toString();
                stdout += output;
                debugLog(`📤 [LocalWhisper] [${chunkId}] stdout:`, output.trim());
            });
            child.stderr?.on('data', (data) => {
                const output = data.toString();
                stderr += output;
                debugLog(`📤 [LocalWhisper] [${chunkId}] stderr:`, output.trim());
            });
            child.on('error', (error) => {
                this.activeProcesses.delete(child);
                console.error(`❌ [LocalWhisper] [${chunkId}] Spawn error:`, error.message);
                reject(new Error(`Failed to spawn whisper.cpp: ${error.message}`));
            });
            child.on('close', async (code) => {
                // Remove from active processes when complete
                this.activeProcesses.delete(child);
                debugLog(`🏁 [LocalWhisper] [${chunkId}] Process closed with code:`, code);
                debugLog(`📝 [LocalWhisper] [${chunkId}] Final stdout:`, stdout.trim());
                debugLog(`📝 [LocalWhisper] [${chunkId}] Final stderr:`, stderr.trim());
                if (code === 0) {
                    try {
                        // Read the output text file created by whisper-cli
                        const textFilePath = audioFile + '.txt';
                        debugLog(`📄 [LocalWhisper] [${chunkId}] Reading output file:`, textFilePath);
                        const text = await fs.readFile(textFilePath, 'utf-8');
                        // Clean up the text file
                        await fs.unlink(textFilePath).catch(() => { });
                        debugLog(`✅ [LocalWhisper] [${chunkId}] Transcription successful:`, text.substring(0, 100) + '...');
                        resolve(text.trim());
                    }
                    catch (error) {
                        console.error(`❌ [LocalWhisper] [${chunkId}] Failed to read output file:`, error);
                        reject(new Error(`Failed to read whisper output file: ${error instanceof Error ? error.message : 'Unknown error'}`));
                    }
                }
                else {
                    console.error(`❌ [LocalWhisper] [${chunkId}] Process failed with code:`, code);
                    reject(new Error(`whisper.cpp failed with code ${code}: ${stderr}`));
                }
            });
            // Timeout after 10 seconds for streaming (faster feedback)
            setTimeout(() => {
                this.activeProcesses.delete(child);
                child.kill();
                reject(new Error('Whisper transcription timeout'));
            }, 10000);
        });
    }
    /**
     * Write audio buffer as WAV file
     */
    async writeBufferAsWav(buffer, filename) {
        // Ensure temp directory exists (in case it was cleaned up)
        await fs.mkdir(this.tempDir, { recursive: true });
        // Create a simple WAV header for 16kHz, 16-bit, mono PCM
        const sampleRate = 16000;
        const bitsPerSample = 16;
        const channels = 1;
        const wavHeader = Buffer.alloc(44);
        // WAV header
        wavHeader.write('RIFF', 0); // ChunkID
        wavHeader.writeUInt32LE(36 + buffer.length, 4); // ChunkSize
        wavHeader.write('WAVE', 8); // Format
        wavHeader.write('fmt ', 12); // Subchunk1ID
        wavHeader.writeUInt32LE(16, 16); // Subchunk1Size (PCM)
        wavHeader.writeUInt16LE(1, 20); // AudioFormat (PCM)
        wavHeader.writeUInt16LE(channels, 22); // NumChannels
        wavHeader.writeUInt32LE(sampleRate, 24); // SampleRate
        wavHeader.writeUInt32LE(sampleRate * channels * bitsPerSample / 8, 28); // ByteRate
        wavHeader.writeUInt16LE(channels * bitsPerSample / 8, 32); // BlockAlign
        wavHeader.writeUInt16LE(bitsPerSample, 34); // BitsPerSample
        wavHeader.write('data', 36); // Subchunk2ID
        wavHeader.writeUInt32LE(buffer.length, 40); // Subchunk2Size
        // Combine header and audio data
        const wavFile = Buffer.concat([wavHeader, buffer]);
        await fs.writeFile(filename, wavFile);
    }
    /**
     * Estimate confidence based on text quality (simplified heuristic)
     */
    estimateConfidence(text) {
        if (!text || text.trim().length === 0) {
            return 0.0;
        }
        // Simple heuristics for confidence estimation
        const wordCount = text.split(/\s+/).length;
        const hasCapitalization = /[A-Z]/.test(text);
        const hasPunctuation = /[.!?]/.test(text);
        const hasCommonWords = /\b(the|and|is|in|to|of|a|that|it|with|for|as|was|on|are|you|they|be|at|one|have|this|from|or|had|by|but|not|what|all|can|her|were|there|we|when|your|said)\b/i.test(text);
        let confidence = Math.min(0.9, 0.3 + (wordCount * 0.05));
        if (hasCapitalization)
            confidence += 0.1;
        if (hasPunctuation)
            confidence += 0.1;
        if (hasCommonWords)
            confidence += 0.2;
        return Math.max(0.1, Math.min(0.95, confidence));
    }
    /**
     * Check if the service is ready
     */
    isReady() {
        return this.isInitialized && !!this.whisperPath && !!this.modelPath;
    }
    /**
     * Get model info
     */
    getModelInfo() {
        if (!this.modelPath) {
            return {
                name: 'unknown',
                type: 'whisper.cpp',
                local: true,
                gpu: process.arch === 'arm64' && process.platform === 'darwin',
                size: 'unknown'
            };
        }
        // Extract the actual model name from the path
        const fileName = path.basename(this.modelPath);
        const modelName = fileName.replace('.bin', ''); // Remove .bin extension
        // Extract size for backward compatibility
        const modelSize = modelName.includes('medium') ? 'medium' :
            modelName.includes('small') ? 'small' :
                modelName.includes('base') ? 'base' :
                    modelName.includes('tiny') ? 'tiny' : 'unknown';
        return {
            name: modelName, // Use actual model name (e.g., "ggml-small" or "ggml-small.en")
            type: 'whisper.cpp',
            local: true,
            gpu: process.arch === 'arm64' && process.platform === 'darwin', // Apple Silicon GPU
            size: modelSize
        };
    }
    /**
     * Clean up temporary files
     */
    async cleanup() {
        debugLog('🧹 [LocalWhisper] Cleaning up, terminating', this.activeProcesses.size, 'active processes');
        // Kill all active processes
        for (const process of this.activeProcesses) {
            try {
                process.kill('SIGTERM');
                debugLog('🔫 [LocalWhisper] Terminated process:', process.pid);
            }
            catch (error) {
                console.warn('⚠️ [LocalWhisper] Failed to kill process:', error);
            }
        }
        this.activeProcesses.clear();
        // Clean up temp directory
        try {
            await fs.rm(this.tempDir, { recursive: true, force: true });
            debugLog('🧹 [LocalWhisper] Temp directory cleaned up:', this.tempDir);
        }
        catch {
            // Ignore cleanup errors
        }
    }
}
//# sourceMappingURL=LocalWhisperService.js.map