import { EventEmitter } from 'events';
// Service status enum
export var ServiceStatus;
(function (ServiceStatus) {
    ServiceStatus["Stopped"] = "stopped";
    ServiceStatus["Starting"] = "starting";
    ServiceStatus["Running"] = "running";
    ServiceStatus["Error"] = "error";
})(ServiceStatus || (ServiceStatus = {}));
// Abstract interface for audio recording service
export class IRecordingService extends EventEmitter {
}
// Processing modes
export var ProcessingMode;
(function (ProcessingMode) {
    ProcessingMode["BATCH"] = "batch";
    ProcessingMode["STREAMING"] = "streaming";
})(ProcessingMode || (ProcessingMode = {}));
// Enhanced recording service interface for streaming support
export class IEnhancedRecordingService extends IRecordingService {
}
// Abstract interface for transcription service
export class ITranscriptionService extends EventEmitter {
}
// Enhanced streaming transcription service interface
export class IStreamingTranscriptionService extends ITranscriptionService {
}
// Abstract interface for formatting service
export class IFormattingService extends EventEmitter {
}
// Abstract interface for clipboard service
export class IClipboardService {
}
// Abstract interface for configuration service
export class IConfigurationService {
}
// Abstract interface for file management service
export class IFileService {
}
// Application service manager
export class IServiceManager {
}
//# sourceMappingURL=interfaces.js.map