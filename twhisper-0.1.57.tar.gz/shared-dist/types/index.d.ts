export declare enum AppState {
    IDLE = "idle",
    RECORDING = "recording",
    TRANSCRIBING = "transcribing",
    FORMATTING = "formatting",
    COMPLETE = "complete",
    ERROR = "error",
    STREAMING = "streaming",
    STREAMING_PAUSED = "streaming_paused",
    STREAMING_STOPPING = "streaming_stopping",
    PROCESSING_CHUNK = "processing_chunk"
}
export interface AppContext {
    state: AppState;
    currentMode: string;
    error: string | null;
    isProcessing: boolean;
    recordingDuration: number;
    audioLevel: number;
    lastResult?: ProcessingResult;
}
export interface ProcessingResult {
    transcription: string;
    formattedText: string;
    mode: string;
    duration: number;
    timestamp: Date;
    success: boolean;
    error?: string;
    wordCount: number;
}
export interface AudioData {
    buffer: Buffer;
    duration: number;
    sampleRate: number;
    channels: number;
    levels: number[];
}
export declare enum ErrorCode {
    UNKNOWN_ERROR = "unknown_error",
    INVALID_INPUT = "invalid_input",
    SERVICE_NOT_INITIALIZED = "service_not_initialized",
    CONFIGURATION_ERROR = "configuration_error",
    AUTHENTICATION_ERROR = "authentication_error",
    STREAMING_AUTHENTICATION_REQUIRED = "streaming_authentication_required",
    NETWORK_ERROR = "network_error",
    SERVICE_UNAVAILABLE = "service_unavailable",
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded",
    RECORDING_ERROR = "recording_error",
    MICROPHONE_ACCESS_DENIED = "microphone_access_denied",
    TRANSCRIPTION_FAILED = "transcription_failed",
    INVALID_AUDIO_FORMAT = "invalid_audio_format",
    FORMATTING_FAILED = "formatting_failed",
    CONTENT_POLICY_VIOLATION = "content_policy_violation",
    FILE_OPERATION_ERROR = "file_operation_error",
    TEMP_FILE_CREATION_FAILED = "temp_file_creation_failed",
    CLIPBOARD_ERROR = "clipboard_error",
    CLIPBOARD_ACCESS_DENIED = "clipboard_access_denied",
    STREAMING_SESSION_NOT_FOUND = "streaming_session_not_found",
    STREAMING_CONTEXT_ERROR = "streaming_context_error",
    SUBSCRIPTION_ERROR = "subscription_error",
    SUBSCRIPTION_REQUIRED = "subscription_required",
    AUTHENTICATION_REQUIRED = "authentication_required",
    SERVICE_INITIALIZATION_FAILED = "service_initialization_failed"
}
export declare enum ErrorType {
    RECORDING_ERROR = "recording_error",
    TRANSCRIPTION_ERROR = "transcription_error",
    FORMATTING_ERROR = "formatting_error",
    CLIPBOARD_ERROR = "clipboard_error",
    NETWORK_ERROR = "network_error",
    CONFIGURATION_ERROR = "configuration_error",
    VALIDATION_ERROR = "validation_error"
}
export declare class AppError extends Error {
    readonly code: ErrorCode;
    readonly details?: Record<string, unknown>;
    readonly timestamp: Date;
    constructor(message: string, code: ErrorCode, details?: Record<string, unknown>);
    toJSON(): {
        name: string;
        message: string;
        code: ErrorCode;
        details: Record<string, unknown> | undefined;
        timestamp: Date;
        stack: string | undefined;
    };
}
export interface AppErrorLegacy {
    type: ErrorType;
    message: string;
    details?: Record<string, unknown>;
    timestamp: Date;
    recoverable: boolean;
}
export type AudioEvent = {
    type: 'audioData';
    data: {
        chunk: Buffer;
        level: number;
        duration: number;
    };
} | {
    type: 'recordingStarted';
} | {
    type: 'recordingStopped';
    data: {
        audioData: Buffer;
        duration: number;
        audioLevels: number[];
    };
} | {
    type: 'recordingCancelled';
} | {
    type: 'error';
    data: Error;
} | {
    type: 'maxDurationReached';
};
export type TranscriptionEvent = {
    type: 'transcriptionStarted';
} | {
    type: 'transcriptionProgress';
    data: {
        progress: number;
        stage: string;
    };
} | {
    type: 'transcriptionComplete';
    data: {
        transcription: string;
        confidence?: number;
    };
} | {
    type: 'transcriptionError';
    data: Error;
};
export type FormattingEvent = {
    type: 'formattingStarted';
} | {
    type: 'formattingProgress';
    data: {
        progress: number;
        stage: string;
    };
} | {
    type: 'formattingComplete';
    data: {
        formattedText: string;
        originalText: string;
        mode: string;
    };
} | {
    type: 'formattingError';
    data: Error;
};
//# sourceMappingURL=index.d.ts.map