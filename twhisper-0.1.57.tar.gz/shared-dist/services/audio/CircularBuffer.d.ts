import { AudioChunk } from '../../interfaces/interfaces.js';
export interface CircularBufferOptions {
    maxSizeSeconds: number;
    chunkSizeBytes: number;
    sampleRate: number;
    channels: number;
    autoResize?: boolean;
}
export interface BufferStatus {
    bufferSize: number;
    utilization: number;
    overflowCount: number;
    totalChunks: number;
    totalBytesProcessed: number;
    averageChunkSize: number;
    oldestTimestamp: number | null;
    newestTimestamp: number | null;
}
export declare class CircularBuffer {
    private buffer;
    private maxSize;
    private writeIndex;
    private overflowCount;
    private totalChunksProcessed;
    private totalBytesProcessed;
    private options;
    constructor(options: CircularBufferOptions);
    /**
     * Calculate maximum buffer size based on duration and audio parameters
     */
    private calculateMaxSize;
    /**
     * Add an audio chunk to the circular buffer
     */
    push(chunk: AudioChunk): boolean;
    /**
     * Get the most recent N chunks from the buffer
     */
    getRecentChunks(count: number): AudioChunk[];
    /**
     * Get all chunks within a time range (in milliseconds)
     */
    getChunksInTimeRange(startTime: number, endTime: number): AudioChunk[];
    /**
     * Get all valid chunks in chronological order
     */
    getAllChunks(): AudioChunk[];
    /**
     * Get audio data as a concatenated buffer from recent chunks
     */
    getAudioBuffer(chunkCount?: number): Buffer;
    /**
     * Clear the buffer and reset counters
     */
    clear(): void;
    /**
     * Get buffer status and statistics
     */
    getStatus(): BufferStatus;
    /**
     * Configure buffer parameters (can only be done when buffer is empty)
     */
    configure(options: Partial<CircularBufferOptions>): boolean;
    /**
     * Resize the buffer (preserving existing data if possible)
     */
    resize(newMaxSize: number): boolean;
    /**
     * Check if buffer is full
     */
    isFull(): boolean;
    /**
     * Get current number of chunks in buffer
     */
    size(): number;
    /**
     * Get maximum buffer capacity
     */
    capacity(): number;
    /**
     * Check if buffer is empty
     */
    isEmpty(): boolean;
    /**
     * Get buffer configuration
     */
    getOptions(): Required<CircularBufferOptions>;
    /**
     * Estimate memory usage in bytes
     */
    getMemoryUsage(): number;
}
//# sourceMappingURL=CircularBuffer.d.ts.map