import { EventEmitter } from 'events';
/**
 * Sequential Streaming Recorder
 * Records audio in sequential chunks of fixed duration (e.g., 10 seconds)
 * Each chunk is emitted when complete for transcription
 */
export class SequentialStreamingRecorder extends EventEmitter {
    constructor(options = {}) {
        super();
        this.recorder = null;
        this.currentChunkBuffer = [];
        this.chunkNumber = 0;
        this.chunkStartTime = 0;
        this.isRecording = false;
        this.chunkTimer = null;
        this.options = {
            chunkDuration: options.chunkDuration || 10000, // Default 10 seconds
            sampleRate: options.sampleRate || 16000,
            channels: options.channels || 1,
            audioType: options.audioType || 'wav'
        };
    }
    /**
     * Start recording sequential chunks
     */
    async start() {
        if (this.isRecording) {
            return;
        }
        this.isRecording = true;
        this.chunkNumber = 0;
        await this.startNewChunk();
    }
    /**
     * Start recording a new chunk
     */
    async startNewChunk() {
        if (!this.isRecording) {
            return;
        }
        // Reset chunk buffer
        this.currentChunkBuffer = [];
        this.chunkStartTime = Date.now();
        this.chunkNumber++;
        // Create recorder if not exists
        if (!this.recorder) {
            // Dynamic import for node-record-lpcm16
            const { createRequire } = await import('module');
            const require = createRequire(import.meta.url);
            const record = require('node-record-lpcm16');
            this.recorder = record.record({
                sampleRate: this.options.sampleRate,
                channels: this.options.channels,
                audioType: this.options.audioType,
                recorder: process.platform === 'darwin' ? 'sox' : 'rec',
                silence: '0.0' // Don't stop on silence
            });
            // Collect audio data
            if (this.recorder) {
                this.recorder.stream().on('data', (chunk) => {
                    if (this.isRecording) {
                        this.currentChunkBuffer.push(chunk);
                    }
                });
                this.recorder.stream().on('error', (error) => {
                    console.error('❌ [SequentialRecorder] Recording error:', error);
                    this.emit('error', error);
                });
            }
        }
        // Set timer to complete this chunk
        this.chunkTimer = setTimeout(() => {
            this.completeCurrentChunk();
        }, this.options.chunkDuration);
    }
    /**
     * Complete the current chunk and start the next one
     * @param forceEmit - If true, emit the chunk even if recording has stopped (for partial chunks)
     */
    async completeCurrentChunk(forceEmit = false) {
        if (!this.isRecording && !forceEmit) {
            return;
        }
        if (this.currentChunkBuffer.length === 0) {
            // Still start next chunk in case audio starts working
            await this.startNewChunk();
            return;
        }
        const chunkEndTime = Date.now();
        const chunkData = Buffer.concat(this.currentChunkBuffer);
        // Emit the completed chunk
        const chunk = {
            data: chunkData,
            chunkNumber: this.chunkNumber,
            startTime: this.chunkStartTime,
            endTime: chunkEndTime,
            duration: chunkEndTime - this.chunkStartTime
        };
        this.emit('chunk', chunk);
        // Start the next chunk immediately (only if still recording)
        if (this.isRecording) {
            await this.startNewChunk();
        }
    }
    /**
     * Stop recording
     */
    async stop() {
        if (!this.isRecording) {
            return;
        }
        this.isRecording = false;
        // Clear chunk timer
        if (this.chunkTimer) {
            clearTimeout(this.chunkTimer);
            this.chunkTimer = null;
        }
        // Complete any remaining chunk data (partial chunk)
        if (this.currentChunkBuffer.length > 0) {
            this.completeCurrentChunk(true); // Force emit the partial chunk
        }
        // Stop the recorder
        if (this.recorder) {
            this.recorder.stop();
            this.recorder = null;
        }
        this.emit('stopped', { totalChunks: this.chunkNumber });
    }
    /**
     * Check if currently recording
     */
    getIsRecording() {
        return this.isRecording;
    }
    /**
     * Get current chunk number
     */
    getCurrentChunkNumber() {
        return this.chunkNumber;
    }
}
//# sourceMappingURL=SequentialStreamingRecorder.js.map