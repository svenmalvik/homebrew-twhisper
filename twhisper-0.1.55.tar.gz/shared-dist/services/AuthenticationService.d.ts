import { IConfigurationService } from '../interfaces/interfaces.js';
export interface AuthConfig {
    sessionToken?: string;
    expiresAt?: string;
    user?: {
        id: string;
        email: string;
        name: string;
    };
}
export interface DeviceFlowResponse {
    success: boolean;
    data?: {
        device_code: string;
        user_code: string;
        verification_uri: string;
        expires_in: number;
        interval: number;
    };
    error?: {
        code: string;
        message: string;
    };
}
export interface LoginResponse {
    success: boolean;
    data?: {
        session_token: string;
        user: {
            id: string;
            email: string;
            name: string;
            login_count: number;
        };
    };
    error?: {
        code: string;
        message: string;
    };
}
export interface LogoutResponse {
    success: boolean;
    data?: {
        session_duration: string;
        message: string;
    };
    error?: {
        code: string;
        message: string;
    };
}
export interface ValidationResponse {
    success: boolean;
    data?: {
        valid: boolean;
        user: {
            id: string;
            email: string;
            name: string;
        };
        session: {
            id: string;
            expires_at: string;
            created_at: string;
        };
        renewed_token?: string;
    };
    error?: {
        code: string;
        message: string;
        status?: number;
    };
}
export declare class AuthenticationService {
    private configDir;
    private configFile;
    private configService;
    constructor(configService: IConfigurationService);
    private getAuthConfig;
    private ensureConfigDir;
    saveConfig(config: AuthConfig): Promise<void>;
    loadConfig(): Promise<AuthConfig | null>;
    clearConfig(): Promise<void>;
    isAuthenticated(): Promise<boolean>;
    initiateDeviceFlow(): Promise<DeviceFlowResponse>;
    pollForToken(deviceCode: string): Promise<LoginResponse>;
    logout(): Promise<LogoutResponse>;
    getCurrentUser(): Promise<AuthConfig | null>;
}
//# sourceMappingURL=AuthenticationService.d.ts.map