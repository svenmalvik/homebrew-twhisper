import { IClipboardService } from '../interfaces/interfaces.js';
import { AppError, ErrorCode } from '../types/index.js';
import clipboardy from 'clipboardy';
import fs from 'fs/promises';
import path from 'path';
import os from 'os';
export class ClipboardService extends IClipboardService {
    constructor() {
        super();
        this.isInitialized = false;
        this.storeDirectory = path.join(os.homedir(), '.twhisper', 'clipboards');
        this.isInitialized = true;
    }
    async ensureStoreDirectory() {
        try {
            await fs.access(this.storeDirectory);
        }
        catch {
            await fs.mkdir(this.storeDirectory, { recursive: true });
        }
    }
    async archiveClipboardContent(text) {
        try {
            await this.ensureStoreDirectory();
            const now = new Date();
            const timestamp = now.getFullYear() + '-' +
                String(now.getMonth() + 1).padStart(2, '0') + '-' +
                String(now.getDate()).padStart(2, '0') + 'T' +
                String(now.getHours()).padStart(2, '0') + '-' +
                String(now.getMinutes()).padStart(2, '0') + '-' +
                String(now.getSeconds()).padStart(2, '0');
            const filename = `clipboard-${timestamp}.txt`;
            const filepath = path.join(this.storeDirectory, filename);
            await fs.writeFile(filepath, text, 'utf8');
        }
        catch (error) {
            // Log the error but don't fail the clipboard operation
            console.warn('Failed to archive clipboard content:', error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async write(text) {
        if (!this.isInitialized) {
            throw new AppError('ClipboardService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        if (!text) {
            throw new AppError('No text provided to write to clipboard', ErrorCode.INVALID_INPUT);
        }
        try {
            await clipboardy.write(text);
            // Archive the clipboard content after successful write
            await this.archiveClipboardContent(text);
            return true;
        }
        catch (error) {
            throw new AppError('Failed to write to clipboard', ErrorCode.CLIPBOARD_ERROR, {
                textLength: text.length,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    async read() {
        if (!this.isInitialized) {
            throw new AppError('ClipboardService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        try {
            return await clipboardy.read();
        }
        catch (error) {
            throw new AppError('Failed to read from clipboard', ErrorCode.CLIPBOARD_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    async isAvailable() {
        if (!this.isInitialized) {
            return false;
        }
        try {
            // Test clipboard access by trying to read
            await clipboardy.read();
            return true;
        }
        catch {
            return false;
        }
    }
    async clear() {
        if (!this.isInitialized) {
            throw new AppError('ClipboardService not initialized', ErrorCode.SERVICE_NOT_INITIALIZED);
        }
        try {
            await clipboardy.write('');
            return true;
        }
        catch (error) {
            throw new AppError('Failed to clear clipboard', ErrorCode.CLIPBOARD_ERROR, { error: error instanceof Error ? error.message : 'Unknown error' });
        }
    }
    /**
     * Write text to clipboard with confirmation and retry logic
     */
    async writeWithConfirmation(text, maxRetries = 3) {
        let lastError;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await this.write(text);
                // Verify the write by reading back
                const readBack = await this.read();
                if (readBack === text) {
                    return {
                        success: true,
                        wordCount: text.split(/\s+/).filter(word => word.length > 0).length,
                        preview: text.length > 100 ? text.substring(0, 100) + '...' : text
                    };
                }
                else {
                    throw new AppError('Clipboard verification failed - written text does not match', ErrorCode.CLIPBOARD_ERROR, { expected: text.substring(0, 50), actual: readBack.substring(0, 50) });
                }
            }
            catch (error) {
                lastError = error instanceof AppError ? error : new AppError('Clipboard write attempt failed', ErrorCode.CLIPBOARD_ERROR, { attempt, error: error instanceof Error ? error.message : 'Unknown error' });
                // Wait before retry with exponential backoff
                if (attempt < maxRetries) {
                    const delay = Math.min(100 * Math.pow(2, attempt - 1), 1000);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError || new AppError('All clipboard write attempts failed', ErrorCode.CLIPBOARD_ERROR, { maxRetries });
    }
    /**
     * Get clipboard statistics for monitoring
     */
    getClipboardStats() {
        // This would typically be implemented with proper metrics collection
        // For now, return placeholder values
        return {
            totalWrites: 0,
            successRate: 1.0,
            averageTextLength: 0,
            lastWriteTime: null,
        };
    }
}
//# sourceMappingURL=ClipboardService.js.map